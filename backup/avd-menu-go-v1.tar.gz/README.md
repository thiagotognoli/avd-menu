# AVD Menu

Gerenciador de emuladores Android para Linux e macOS — o **Device Manager + SDK Manager do Android Studio** num único binário, **sem Java, sem Python e sem instalar dependências**.

Abre numa janela própria, lista seus emuladores, inicia/para com um clique, cria dispositivos novos (escolhendo aparelho e versão do Android), baixa as imagens direto do Google e cria o **atalho no menu de aplicativos** (GNOME, KDE…) com ícone e ações de clique-direito.

> *English TL;DR:* a dependency-free Android emulator manager for Linux & macOS. Single static Go binary (AppImage / DMG), talks to Google's SDK repository directly (no Java, no `sdkmanager`), creates AVDs the same way Android Studio does, and adds launcher shortcuts to your desktop menu. The UI is bilingual (pt-BR / en).

## Instalação

**Linux (qualquer distribuição x86_64)** — uma linha:

```sh
curl -fsSL https://raw.githubusercontent.com/thiagotognoli/avd-menu/main/install.sh | sh
```

Ou baixe o `AVD-Menu-*-x86_64.AppImage` em [Releases](https://github.com/thiagotognoli/avd-menu/releases), dê permissão de execução e abra. Também há o binário puro (`avd-menu-*-linux-amd64.tar.gz`, estático, roda em qualquer distro).

**macOS (Intel e Apple Silicon)** — baixe o `AVD-Menu-*-macos.dmg`, arraste para *Aplicativos*. O app não é notarizado pela Apple; na primeira vez use **botão direito → Abrir** (ou `xattr -dr com.apple.quarantine "/Applications/AVD Menu.app"`). O `install.sh` acima também funciona no macOS e já remove a quarentena.

Para aparecer no menu de aplicativos do Linux: *Configurações (engrenagem) → Adicionar ao menu*, ou `avd-menu install`.

## Primeiro uso

1. Abra o AVD Menu. Se não houver Android SDK, ele mostra um cartão **“Vamos preparar o Android SDK”**: um clique baixa o *Android Emulator* e o *Platform-Tools* (≈ 330 MB) para `~/Android/Sdk` (ou use o SDK do Android Studio — ele é detectado sozinho).
2. **Criar dispositivo** → escolha o aparelho (Pixel 10, Pixel Fold, tablets, Wear OS, TV, Automotive…) → escolha a versão do Android (as imagens não instaladas têm botão *Baixar*) → ajuste as opções e *Concluir*.
3. **Iniciar**. Pelo menu `⋮` há *cold boot*, *apagar dados*, *GPU dedicada*, *sem janela*, editar, duplicar, log, **criar atalho no menu**, excluir.

## O que tem

| | |
|---|---|
| **Device Manager** | lista com estado em tempo real (rodando/parado, porta adb), iniciar/parar, cold boot, wipe data, duplicar, editar (RAM, heap, CPUs, armazenamento, cartão SD, câmeras, rede, gráficos, teclado, moldura), editor de `config.ini`, argumentos extras do emulador por AVD, log da execução |
| **Criar dispositivo** | ~95 perfis de hardware oficiais (gerados das mesmas definições do Android Studio) + perfis próprios; imagens *Recomendadas / Todas compatíveis / Outras* filtradas pelo tipo de aparelho e pela arquitetura do computador |
| **SDK Manager** | plataformas, imagens de sistema, emulador, platform-tools, build-tools, cmdline-tools, NDK, CMake… instalar/atualizar/remover com download retomável, checagem SHA-1 e licenças |
| **Atalhos** | Linux: `.desktop` com `StartupWMClass` (a janela do emulador se vincula ao ícone na dock), ações *cold boot / apagar dados / GPU dedicada*, ícone próprio, fixar na dock do GNOME. macOS: `.app` em `~/Applications` |
| **Diagnóstico** | KVM/Hypervisor, bibliotecas faltando (com o comando do `apt`/`dnf`/`pacman`), GPUs, espaço em disco |
| **Compatível com o Android Studio** | usa `~/.android/avd`, grava os mesmos `package.xml` e `licenses/` — AVDs e SDK criados aqui aparecem no Studio e no `sdkmanager`, e vice-versa |

## Linha de comando

```sh
avd-menu                         # abre a interface
avd-menu list                    # lista os AVDs
avd-menu start Pixel_9 --cold    # inicia (--wipe, --dgpu, --headless, --arg ...)
avd-menu stop  Pixel_9
avd-menu create Meu_Pixel --device pixel_9 --image "system-images;android-36;google_apis;x86_64"
avd-menu shortcut Pixel_9 --name "Meu Pixel" --icon ~/icone.png --pin
avd-menu sdk list --all          # tudo que o Google publica
avd-menu sdk install "system-images;android-36;google_apis_playstore;x86_64"
avd-menu doctor                  # diagnóstico
```

Compatível com o antigo `avd-menu.sh`: `avd-menu NOME` cria o atalho, `--ui`, `--list`, `--remove`, `install` continuam funcionando.

## Como funciona

- **Sem Java**: o AVD Menu lê os manifestos públicos do Google (`dl.google.com/android/repository`), baixa os `.zip`, confere o SHA-1, extrai e grava o `package.xml` — exatamente o que o `sdkmanager` faz. O hash das licenças usa o mesmo algoritmo do sdklib, então o aceite vale para o Studio também.
- **AVDs sem `avdmanager`**: o `config.ini` é montado com as mesmas chaves que o `avdmanager` gera para cada aparelho (tabela extraída do próprio `avdmanager`; ver `tools/gen_devices.py`).
- **Interface**: servidor HTTP local (só `127.0.0.1`, com token de sessão e checagem de `Host`/`Origin`) + HTML/JS sem etapa de build, aberta em modo “aplicativo” do Chrome/Chromium/Edge/Brave se existir (janela própria, sem barra de endereço), senão no navegador padrão. Ao fechar a janela o programa encerra sozinho; os emuladores continuam rodando.
- **Estático**: `CGO_ENABLED=0`, sem bibliotecas dinâmicas — o mesmo binário roda em qualquer distro.

### Requisitos

- Linux x86_64 (o Google não publica o emulador para Linux ARM) ou macOS 11+.
- Linux: acesso ao KVM (`ls -l /dev/kvm`; se faltar: `sudo usermod -aG kvm $USER` e relogar). A aba **Diagnóstico** diz o que falta.
- AppImage: precisa de FUSE (`libfuse2`/`fuse3`); sem ele rode com `--appimage-extract-and-run`.

## Desenvolvimento

```sh
make            # compila ./avd-menu  (baixa o Go para .tools/go se não houver Go instalado)
make run        # compila e abre a interface
make test       # go vet + go test
make dist       # dist/: AppImage + tar.gz + SHA256SUMS (Linux)
make macos      # no macOS: dist/*.dmg (binário universal + ícone .icns)
```

```
main.go               CLI
internal/sdk          manifestos, download/instalação, licenças (substitui o sdkmanager)
internal/avd          ler/criar/editar/duplicar AVDs (substitui o avdmanager)
internal/devices      perfis de hardware (devices.json gerado por tools/gen_devices.py)
internal/emu          iniciar/parar/detectar emuladores, diagnóstico, GPU dedicada
internal/shortcut     atalhos do menu (.desktop / .app), ícones, .icns
internal/server       API HTTP + SSE (tarefas em tempo real)
internal/launcher     abre a janela da interface
ui/                   interface (HTML/CSS/JS puro, embutida no binário)
packaging/            AppImage, .app/.dmg, download do Go
```

Para regenerar a lista de aparelhos quando o Google lançar novos: `python3 tools/gen_devices.py --sdk ~/Android/Sdk` (usa o `avdmanager` como referência).

### Publicar uma release

O workflow `.github/workflows/release.yml` compila tudo e cria a release:

```sh
git tag v1.0.0 && git push origin v1.0.0
```

Saem: `AVD-Menu-v1.0.0-x86_64.AppImage`, `avd-menu-v1.0.0-linux-amd64.tar.gz`, `AVD-Menu-v1.0.0-macos.dmg` (+ `.zip`) e `SHA256SUMS`.

## Problemas comuns

| Sintoma | Solução |
|---|---|
| “Aceleração por hardware indisponível” | `sudo usermod -aG kvm $USER` e relogar; confira VT-x/AMD-V na BIOS |
| O emulador fecha logo ao iniciar | *Ver log* no menu `⋮` do dispositivo (ou aba Diagnóstico → bibliotecas faltando) |
| Notebook com 2 GPUs lento | menu `⋮` → *Iniciar com GPU dedicada*, ou use o atalho do menu (tem a mesma ação) |
| Janela abre numa aba do Firefox | instale Chrome/Chromium/Edge/Brave para o modo janela própria — funciona igual |

## Créditos e licenças

- As definições de dispositivos vêm do AOSP/Android Studio (Apache License 2.0). “Android” e o robô são marcas do Google; o ícone do projeto é do SVG Repo.
- O AVD Menu não redistribui nada do SDK: tudo é baixado do Google na hora, mediante aceite das licenças.
