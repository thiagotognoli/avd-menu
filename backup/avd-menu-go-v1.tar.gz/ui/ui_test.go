package ui

import (
	"io/fs"
	"regexp"
	"strings"
	"testing"
)

var (
	keyUse   = regexp.MustCompile(`\bt\('([a-zA-Z0-9_.-]+)'\s*[,)]`)
	dynUse   = regexp.MustCompile(`\bt\('([a-zA-Z0-9_.-]+\.)' \+`)
	dictLine = regexp.MustCompile(`'([a-zA-Z0-9_.-]+)': \[`)
	dictBare = regexp.MustCompile(`(?m)(?:^|\s)([a-zA-Z0-9_]+): \[`)
)

// TestI18nCoverage garante que toda chave t('...') usada na interface existe no
// dicionário, em português e inglês.
func TestI18nCoverage(t *testing.T) {
	b, err := Files.ReadFile("js/i18n.js")
	if err != nil {
		t.Fatal(err)
	}
	src := string(b)
	dict := map[string]bool{}
	for _, m := range dictLine.FindAllStringSubmatch(src, -1) {
		dict[m[1]] = true
	}
	for _, m := range dictBare.FindAllStringSubmatch(src, -1) {
		dict[m[1]] = true
	}
	if len(dict) < 200 {
		t.Fatalf("dicionário pequeno demais (%d chaves) — o regex quebrou?", len(dict))
	}
	var prefixes []string
	_ = fs.WalkDir(Files, "js", func(p string, d fs.DirEntry, err error) error {
		if err != nil || d.IsDir() || !strings.HasSuffix(p, ".js") || p == "js/i18n.js" {
			return nil
		}
		code, _ := Files.ReadFile(p)
		for _, m := range keyUse.FindAllStringSubmatch(string(code), -1) {
			if !dict[m[1]] {
				t.Errorf("%s: chave sem tradução: %q", p, m[1])
			}
		}
		for _, m := range dynUse.FindAllStringSubmatch(string(code), -1) {
			prefixes = append(prefixes, m[1])
		}
		return nil
	})
	// chaves montadas dinamicamente
	need := map[string][]string{
		"cat.":       {"phone", "tablet", "wear", "tv", "automotive", "desktop", "xr"},
		"phase.":     {"download", "verify", "extract", "finalize", "remove"},
		"sdk.group.": {"emulator", "platform-tools", "cmdline-tools", "build-tools", "ndk", "cmake", "extras", "sources", "other"},
	}
	for _, p := range prefixes {
		sufs, ok := need[p]
		if !ok {
			t.Errorf("prefixo dinâmico desconhecido %q — liste-o neste teste", p)
			continue
		}
		for _, s := range sufs {
			if !dict[p+s] {
				t.Errorf("chave dinâmica sem tradução: %s%s", p, s)
			}
		}
	}
	// diagnóstico: cada Check do Go precisa ter título
	for _, k := range []string{
		"diag.sdk.ok", "diag.sdk.warn", "diag.emulator.ok", "diag.emulator.warn", "diag.adb.ok", "diag.adb.warn",
		"diag.arch.error", "diag.accel.ok", "diag.accel.error", "diag.libs.ok", "diag.libs.error",
		"diag.gpu.info", "diag.session.info", "diag.disk.ok", "diag.disk.warn",
	} {
		if !dict[k] {
			t.Errorf("faltou %s", k)
		}
	}
	// todo par tem as duas línguas preenchidas
	pair := regexp.MustCompile(`'[a-zA-Z0-9_.-]+': \[\s*'((?:[^'\\]|\\.)*)',\s*'((?:[^'\\]|\\.)*)'\s*\]`)
	for _, m := range pair.FindAllStringSubmatch(src, -1) {
		if strings.TrimSpace(m[1]) == "" || strings.TrimSpace(m[2]) == "" {
			t.Errorf("tradução vazia: %q", m[0])
		}
	}
}
