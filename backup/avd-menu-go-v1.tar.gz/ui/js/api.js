// Cliente da API local + fluxo de eventos (SSE).

export class ApiError extends Error {
  constructor(message, status, data) {
    super(message);
    this.status = status;
    this.data = data;
  }
}

export async function api(method, path, body) {
  const opt = { method, headers: {} };
  if (body !== undefined) {
    opt.headers['Content-Type'] = 'application/json';
    opt.body = JSON.stringify(body);
  }
  let res;
  try {
    res = await fetch(path, opt);
  } catch (e) {
    throw new ApiError('offline', 0);
  }
  let data = null;
  const text = await res.text();
  if (text) { try { data = JSON.parse(text); } catch (_) { data = { error: text }; } }
  if (!res.ok) throw new ApiError((data && data.error) || res.statusText, res.status, data && data.data);
  return data;
}

export const get = (p) => api('GET', p);
export const post = (p, b) => api('POST', p, b ?? {});
export const put = (p, b) => api('PUT', p, b ?? {});
export const del = (p) => api('DELETE', p);

/** Conecta ao fluxo de eventos; reconecta sozinho. */
export function connectEvents(handlers) {
  let es;
  const open = () => {
    es = new EventSource('/api/events');
    for (const [name, fn] of Object.entries(handlers)) {
      es.addEventListener(name, (e) => { try { fn(JSON.parse(e.data)); } catch (_) {} });
    }
    es.onerror = () => { if (handlers._status) handlers._status(false); };
    es.onopen = () => { if (handlers._status) handlers._status(true); };
  };
  open();
  return () => es && es.close();
}
