// Package ui embute a interface web (HTML/CSS/JS sem etapa de build).
package ui

import "embed"

// Files contém index.html, style.css, o logotipo e os módulos em js/.
//
//go:embed index.html style.css logo.svg js
var Files embed.FS
