#!/usr/bin/env python3
"""Gera internal/devices/devices.json a partir do Android SDK.

O Android Studio e o avdmanager usam as definições de dispositivos que vêm
dentro do sdklib (nexus.xml, wear.xml, tv.xml, ...). Este script:

  1. extrai esses XMLs do jar do cmdline-tools;
  2. roda o avdmanager de verdade uma vez por dispositivo (num AVD_HOME
     temporário) e guarda o config.ini resultante — é o "oráculo" de quais
     chaves hw.* cada aparelho recebe (sensores, dobradiças, heap da VM, ...);
  3. grava um JSON compacto: metadados do dispositivo + só as chaves do
     config.ini que diferem do padrão.

Só precisa ser re-executado quando o Google lançar aparelhos novos:

    python3 tools/gen_devices.py --sdk ~/Android/Sdk

Requer JDK (para o avdmanager) e pelo menos uma imagem de sistema instalada.
As definições de dispositivos são do AOSP (Apache License 2.0).
"""
import argparse
import collections
import glob
import json
import os
import re
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile

# Chaves que dependem da imagem de sistema escolhida, não do aparelho.
IMAGE_KEYS = {
    "PlayStore.enabled", "abi.type", "hw.cpu.arch", "image.sysdir.1", "target",
    "tag.display", "tag.displaynames", "tag.id", "tag.ids", "avd.id", "avd.name",
    "avd.ini.encoding", "hw.device.name", "disk.dataPartition.path",
}

FILES = {
    "nexus.xml": None, "devices.xml": None, "wear.xml": "wear", "tv.xml": "tv",
    "automotive.xml": "automotive", "desktop.xml": "desktop", "xr.xml": "xr",
}


def find_jar(sdk):
    hits = glob.glob(os.path.join(sdk, "cmdline-tools", "*", "lib", "**", "sdklib*.jar"), recursive=True)
    hits += glob.glob(os.path.join(sdk, "cmdline-tools", "*", "lib", "**", "tools.sdklib.jar"), recursive=True)
    for h in hits:
        with zipfile.ZipFile(h) as z:
            if any(n.endswith("devices/nexus.xml") for n in z.namelist()):
                return h
    sys.exit("não achei o jar do sdklib com nexus.xml em %s" % sdk)


def text(el, path, ns):
    e = el.find(path, ns)
    return e.text.strip() if e is not None and e.text else None


def parse_devices(jar):
    devices = []
    with zipfile.ZipFile(jar) as z:
        for name, forced in FILES.items():
            member = [n for n in z.namelist() if n.endswith("sdklib/devices/" + name)]
            if not member:
                continue
            root = ET.fromstring(z.read(member[0]))
            uri = root.tag[1:root.tag.index("}")]
            ns = {"d": uri}
            for dev in root:
                name_ = text(dev, "d:name", ns)
                did = text(dev, "d:id", ns) or name_
                hw = dev.find("d:hardware", ns)
                scr = hw.find("d:screen", ns)
                tags = [e.text.strip() for e in dev.iter("{%s}tag-id" % uri) if e.text]
                sensors = (text(hw, "d:sensors", ns) or "").split()
                cams = {text(c, "d:location", ns) for c in hw.findall("d:camera", ns)}
                diag = float(text(scr, "d:diagonal-length", ns) or 0) if scr is not None else 0
                w = h = 0
                density = 0
                if scr is not None:
                    w = int(text(scr, "d:dimensions/d:x-dimension", ns) or 0)
                    h = int(text(scr, "d:dimensions/d:y-dimension", ns) or 0)
                fold = scr is not None and scr.find("d:foldable-region", ns) is not None
                fold = fold or hw.find("d:hinge", ns) is not None
                ram = hw.find("d:ram", ns)
                ram_mib = int(float(ram.text)) if ram is not None and ram.text else 0
                if ram is not None and ram.get("unit") == "GiB":
                    ram_mib *= 1024
                abis = (text(hw, "d:abis", ns) or "").split()
                devices.append({
                    "id": did, "name": name_,
                    "manufacturer": text(dev, "d:manufacturer", ns) or "Generic",
                    "file": name, "forced": forced, "tags": tags,
                    "deprecated": dev.get("deprecated") == "true",
                    "playstore": text(dev, "d:playstore-enabled", ns) == "true",
                    "diag": diag, "w": w, "h": h, "density": density,
                    "densityName": text(scr, "d:pixel-density", ns) if scr is not None else None,
                    "ram": ram_mib, "sensors": sensors,
                    "front": "front" in cams, "back": "back" in cams,
                    "foldable": fold, "skin": text(hw, "d:skin", ns),
                    "abis": abis,
                    "round": "round" in did or "Round" in (name_ or ""),
                })
    return devices


def oracle_name(did):
    return "o_" + re.sub(r"[ /()]", "_", did)


def run_oracle(sdk, devices, outdir):
    avdm = os.path.join(sdk, "cmdline-tools", "latest", "bin", "avdmanager")
    imgs = glob.glob(os.path.join(sdk, "system-images", "*", "*", "*", "package.xml"))
    if not imgs:
        sys.exit("instale alguma imagem de sistema antes (ex.: system-images;android-36;google_apis;x86_64)")
    rel = os.path.relpath(os.path.dirname(imgs[0]), os.path.join(sdk, "system-images")).split(os.sep)
    pkg = "system-images;" + ";".join(rel)
    env = dict(os.environ, ANDROID_SDK_ROOT=sdk, ANDROID_AVD_HOME=outdir)
    os.makedirs(outdir, exist_ok=True)
    for d in devices:
        if os.path.exists(os.path.join(outdir, oracle_name(d["id"]) + ".avd", "config.ini")):
            continue
        print("avdmanager:", d["id"], file=sys.stderr)
        subprocess.run([avdm, "create", "avd", "-n", oracle_name(d["id"]), "-k", pkg, "-d", d["id"], "--force"],
                       stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=env)


def read_ini(path):
    kv = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\n")
            if "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                kv[k] = v
    return kv


DENSITY_NAMES = {"ldpi": 120, "mdpi": 160, "tvdpi": 213, "hdpi": 240, "xhdpi": 320, "xxhdpi": 480, "xxxhdpi": 640}


def category(d):
    tags = d["tags"]
    if d["forced"]:
        return d["forced"]
    if any("wear" in t for t in tags):
        return "wear"
    if d["foldable"] and d["diag"] < 14:
        return "phone"
    big = d["diag"] >= 7.0
    if d["id"] in ("resizable", "13.5in Freeform"):
        return "phone" if d["id"] == "resizable" else "desktop"
    if big:
        return "tablet"
    return "phone"


def sort_key(d):
    order = {"phone": 0, "tablet": 1, "wear": 2, "tv": 3, "automotive": 4, "desktop": 5, "xr": 6}
    m = re.match(r"pixel_(\d+)", d["id"])
    pix = -int(m.group(1)) if m else 0
    return (order.get(d["category"], 9), d["deprecated"], 0 if d["manufacturer"] == "Google" else 1, pix, d["id"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sdk", required=True)
    ap.add_argument("--oracle-dir", default=None)
    ap.add_argument("--out", default=os.path.join(os.path.dirname(__file__), "..", "internal", "devices", "devices.json"))
    a = ap.parse_args()
    sdk = os.path.expanduser(a.sdk)
    devices = parse_devices(find_jar(sdk))
    oracle = a.oracle_dir or tempfile.mkdtemp(prefix="avd-oracle-")
    run_oracle(sdk, devices, oracle)

    cfgs = {}
    for d in devices:
        p = os.path.join(oracle, oracle_name(d["id"]) + ".avd", "config.ini")
        if not os.path.exists(p):
            print("sem config para", d["id"], file=sys.stderr)
            continue
        cfgs[d["id"]] = {k: v for k, v in read_ini(p).items() if k not in IMAGE_KEYS}

    keys = set()
    for c in cfgs.values():
        keys |= set(c)
    defaults = {}
    for k in sorted(keys):
        cnt = collections.Counter(c.get(k) for c in cfgs.values())
        defaults[k] = cnt.most_common(1)[0][0]
    defaults = {k: v for k, v in defaults.items() if v is not None}

    out = []
    for d in devices:
        c = cfgs.get(d["id"])
        if c is None:
            continue
        diff = {}
        for k in keys:
            v = c.get(k)
            if v != defaults.get(k):
                diff[k] = v  # None => ausente neste aparelho
        d["category"] = category(d)
        d["density"] = int(c.get("hw.lcd.density", 0) or 0)
        d["w"] = int(c.get("hw.lcd.width", d["w"]) or 0)
        d["h"] = int(c.get("hw.lcd.height", d["h"]) or 0)
        ramv = c.get("hw.ramSize", "0")
        d["ramMB"] = int(ramv[:-1]) * 1024 if ramv.endswith("G") else int(re.sub(r"\D", "", ramv) or 0)
        d["deviceRamMB"] = d.pop("ram")
        d["cfg"] = dict(sorted(diff.items()))
        for k in ("file", "forced", "densityName"):
            d.pop(k, None)
        out.append(d)
    out.sort(key=sort_key)
    doc = {"defaults": dict(sorted(defaults.items())), "devices": out}
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(doc, f, ensure_ascii=False, separators=(",", ":"))
    print("gravado %s: %d dispositivos, %d chaves padrão" % (a.out, len(out), len(defaults)), file=sys.stderr)


if __name__ == "__main__":
    main()
