module avdmenu

go 1.25
