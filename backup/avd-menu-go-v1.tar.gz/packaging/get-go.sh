#!/usr/bin/env bash
# Baixa o toolchain do Go para .tools/go (dentro do projeto), com verificação
# de SHA-256. Usado pelo Makefile quando o Go não está instalado.
#
#   packaging/get-go.sh [versão]      ex.: packaging/get-go.sh 1.27.1
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEST="$ROOT/.tools"
VERSION="${1:-}"

case "$(uname -s)" in
    Linux)  OS=linux ;;
    Darwin) OS=darwin ;;
    *) echo "Sistema não suportado: $(uname -s)" >&2; exit 1 ;;
esac
case "$(uname -m)" in
    x86_64|amd64)  ARCH=amd64 ;;
    aarch64|arm64) ARCH=arm64 ;;
    *) echo "Arquitetura não suportada: $(uname -m)" >&2; exit 1 ;;
esac

fetch() { if command -v curl >/dev/null 2>&1; then curl -fsSL "$1"; else wget -qO- "$1"; fi; }

JSON="$(fetch 'https://go.dev/dl/?mode=json')"
if [ -z "$VERSION" ]; then
    # primeira entrada = versão estável mais recente
    VERSION="$(printf '%s' "$JSON" | grep -o '"version": *"go[0-9.]*"' | head -1 | grep -o 'go[0-9.]*' | sed 's/^go//')"
fi
FILE="go${VERSION}.${OS}-${ARCH}.tar.gz"

# sha256 oficial do arquivo, direto da lista do go.dev
SUM="$(printf '%s' "$JSON" | tr -d '\n ' | grep -o "\"filename\":\"${FILE}\"[^}]*" | grep -o '"sha256":"[0-9a-f]*"' | head -1 | cut -d'"' -f4)"
if [ -z "$SUM" ]; then
    echo "Não achei ${FILE} na lista do go.dev (versão ${VERSION})." >&2
    exit 1
fi

if [ -x "$DEST/go/bin/go" ] && "$DEST/go/bin/go" version | grep -q "go${VERSION} "; then
    echo "Go ${VERSION} já está em $DEST/go"
    exit 0
fi

mkdir -p "$DEST"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
echo "Baixando ${FILE} …"
fetch "https://go.dev/dl/${FILE}" > "$TMP/go.tgz"

if command -v sha256sum >/dev/null 2>&1; then
    GOT="$(sha256sum "$TMP/go.tgz" | cut -d' ' -f1)"
else
    GOT="$(shasum -a 256 "$TMP/go.tgz" | cut -d' ' -f1)"
fi
if [ "$GOT" != "$SUM" ]; then
    echo "SHA-256 não confere (esperado $SUM, obtido $GOT)" >&2
    exit 1
fi

rm -rf "$DEST/go"
tar -xzf "$TMP/go.tgz" -C "$DEST"
echo "Go ${VERSION} instalado em $DEST/go"
