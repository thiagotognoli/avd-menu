#!/usr/bin/env bash
# Monta "AVD Menu.app" e o .dmg (macOS). Precisa rodar no macOS para gerar o
# .dmg (usa hdiutil) e o binário universal (usa lipo).
#
#   packaging/build-macos.sh VERSAO [SAIDA_DIR]
#
# Variáveis: GO (caminho do go), CODESIGN_IDENTITY ("-" = assinatura ad-hoc).
set -euo pipefail

VERSION="${1:?uso: build-macos.sh VERSAO [SAIDA_DIR]}"
OUT="${2:-dist}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GO="${GO:-go}"
IDENTITY="${CODESIGN_IDENTITY:--}"
mkdir -p "$OUT"; OUT="$(cd "$OUT" && pwd)"

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

LDFLAGS="-s -w -X avdmenu/internal/platform.Version=${VERSION}"
cd "$ROOT"
for arch in amd64 arm64; do
    CGO_ENABLED=0 GOOS=darwin GOARCH=$arch "$GO" build -trimpath -ldflags "$LDFLAGS" -o "$WORK/avd-menu-$arch" .
done

APP="$WORK/AVD Menu.app"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
if command -v lipo >/dev/null 2>&1; then
    lipo -create -output "$APP/Contents/MacOS/avd-menu" "$WORK/avd-menu-amd64" "$WORK/avd-menu-arm64"
else
    echo "lipo não encontrado: usando só o binário do host"
    case "$(uname -m)" in arm64|aarch64) cp "$WORK/avd-menu-arm64" "$APP/Contents/MacOS/avd-menu" ;; *) cp "$WORK/avd-menu-amd64" "$APP/Contents/MacOS/avd-menu" ;; esac
fi
chmod +x "$APP/Contents/MacOS/avd-menu"

# ícone .icns gerado pelo próprio programa (host = onde estamos rodando)
HOSTBIN="$WORK/avd-menu-host"
CGO_ENABLED=0 "$GO" build -trimpath -ldflags "$LDFLAGS" -o "$HOSTBIN" .
"$HOSTBIN" _icon icns "$APP/Contents/Resources/AppIcon.icns"

SHORT="${VERSION#v}"
case "$SHORT" in [0-9]*) ;; *) SHORT="0.0.0" ;; esac
cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>AVD Menu</string>
  <key>CFBundleDisplayName</key><string>AVD Menu</string>
  <key>CFBundleIdentifier</key><string>app.avdmenu.AVDMenu</string>
  <key>CFBundleExecutable</key><string>avd-menu</string>
  <key>CFBundleIconFile</key><string>AppIcon</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>${SHORT}</string>
  <key>CFBundleVersion</key><string>${SHORT}</string>
  <key>LSMinimumSystemVersion</key><string>11.0</string>
  <key>LSApplicationCategoryType</key><string>public.app-category.developer-tools</string>
  <key>NSHighResolutionCapable</key><true/>
</dict></plist>
PLIST

if command -v codesign >/dev/null 2>&1; then
    codesign --force --deep --sign "$IDENTITY" "$APP"
fi

# .zip do app (útil para o auto-instalador e para quem prefere não usar .dmg)
if command -v ditto >/dev/null 2>&1; then
    ditto -c -k --keepParent "$APP" "$OUT/AVD-Menu-${VERSION}-macos.zip"
fi

if command -v hdiutil >/dev/null 2>&1; then
    STAGE="$WORK/dmg"
    mkdir -p "$STAGE"
    cp -R "$APP" "$STAGE/"
    ln -s /Applications "$STAGE/Applications"
    DMG="$OUT/AVD-Menu-${VERSION}-macos.dmg"
    rm -f "$DMG"
    hdiutil create -volname "AVD Menu" -srcfolder "$STAGE" -ov -format UDZO "$DMG"
    echo "Gerado: $DMG"
else
    echo "hdiutil indisponível (não é macOS): o .dmg não foi gerado."
fi
