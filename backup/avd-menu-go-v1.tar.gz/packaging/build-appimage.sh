#!/usr/bin/env bash
# Gera o AppImage do AVD Menu (Linux x86_64) a partir do binário já compilado.
#
#   packaging/build-appimage.sh BINARIO VERSAO [SAIDA_DIR]
#
# Baixa o appimagetool (se preciso) para .tools/ e roda com
# --appimage-extract-and-run, então não exige FUSE na máquina de build.
set -euo pipefail

BIN="${1:?uso: build-appimage.sh BINARIO VERSAO [SAIDA_DIR]}"
VERSION="${2:?informe a versão}"
OUT="${3:-dist}"
ARCH="${ARCH:-x86_64}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

mkdir -p "$OUT" "$ROOT/.tools"
OUT="$(cd "$OUT" && pwd)"
BIN="$(cd "$(dirname "$BIN")" && pwd)/$(basename "$BIN")"

TOOL="$ROOT/.tools/appimagetool-$ARCH.AppImage"
if [ ! -x "$TOOL" ]; then
    echo "Baixando appimagetool ($ARCH) …"
    curl -fsSL -o "$TOOL" "https://github.com/AppImage/appimagetool/releases/download/continuous/appimagetool-$ARCH.AppImage"
    chmod +x "$TOOL"
fi

APPDIR="$(mktemp -d)/AVD_Menu.AppDir"
trap 'rm -rf "$(dirname "$APPDIR")"' EXIT
mkdir -p "$APPDIR/usr/bin" "$APPDIR/usr/share/icons/hicolor/256x256/apps" "$APPDIR/usr/share/icons/hicolor/scalable/apps" "$APPDIR/usr/share/applications"

install -m 0755 "$BIN" "$APPDIR/usr/bin/avd-menu"
"$BIN" _icon 256 "$APPDIR/usr/share/icons/hicolor/256x256/apps/avd-menu.png"
cp "$APPDIR/usr/share/icons/hicolor/256x256/apps/avd-menu.png" "$APPDIR/avd-menu.png"
cp "$APPDIR/avd-menu.png" "$APPDIR/.DirIcon"
cp "$ROOT/android-icon.svg" "$APPDIR/usr/share/icons/hicolor/scalable/apps/avd-menu.svg"

cat > "$APPDIR/avd-menu.desktop" <<'DESK'
[Desktop Entry]
Type=Application
Name=AVD Menu
GenericName=Android Virtual Devices
Comment=Create, start and manage Android emulators
Comment[pt_BR]=Crie, inicie e gerencie emuladores Android
Exec=avd-menu ui
Icon=avd-menu
Terminal=false
Categories=Development;IDE;
Keywords=android;emulator;avd;sdk;emulador;
StartupWMClass=AvdMenu
DESK
cp "$APPDIR/avd-menu.desktop" "$APPDIR/usr/share/applications/avd-menu.desktop"

cat > "$APPDIR/AppRun" <<'RUN'
#!/bin/sh
HERE="$(dirname "$(readlink -f "$0")")"
exec "$HERE/usr/bin/avd-menu" "$@"
RUN
chmod +x "$APPDIR/AppRun"

FILE="$OUT/AVD-Menu-${VERSION}-${ARCH}.AppImage"
ARCH="$ARCH" "$TOOL" --appimage-extract-and-run --no-appstream "$APPDIR" "$FILE"
chmod +x "$FILE"
echo "Gerado: $FILE"
