// AVD Menu — gerenciador de emuladores Android (Device Manager + SDK Manager)
// em um único binário, sem Java e sem dependências.
package main

import (
	"bufio"
	"bytes"
	"context"
	"flag"
	"fmt"
	"image/png"
	"os"
	"os/signal"
	"sort"
	"strings"
	"syscall"
	"text/tabwriter"

	"avdmenu/internal/assets"
	"avdmenu/internal/avd"
	"avdmenu/internal/emu"
	"avdmenu/internal/launcher"
	"avdmenu/internal/platform"
	"avdmenu/internal/sdk"
	"avdmenu/internal/server"
	"avdmenu/internal/shortcut"
)

// tr escolhe o texto pelo idioma do sistema (LANG/LC_ALL).
func tr(pt, en string) string {
	for _, k := range []string{"LC_ALL", "LC_MESSAGES", "LANG"} {
		if v := os.Getenv(k); v != "" {
			if strings.HasPrefix(strings.ToLower(v), "pt") {
				return pt
			}
			return en
		}
	}
	return en
}

func fail(format string, a ...any) {
	fmt.Fprintf(os.Stderr, tr("Erro: ", "Error: ")+format+"\n", a...)
	os.Exit(1)
}

func usage() {
	fmt.Fprintf(os.Stderr, tr(`AVD Menu %s — gerenciador de emuladores Android

USO:
  avd-menu [ui]                      Abre a interface gráfica (padrão)
  avd-menu list [--json]             Lista os AVDs
  avd-menu create NOME --device ID --image PACOTE [--ram MB] [--cores N]
                                     Cria um AVD (a imagem precisa estar instalada)
  avd-menu start NOME [opções]       Inicia um emulador
        --cold  cold boot   --wipe  apaga os dados   --dgpu  GPU dedicada   --headless  sem janela
        --arg X  argumento extra do emulador (repetível)
  avd-menu stop NOME                 Para um emulador
  avd-menu shortcut NOME [opções]    Cria o atalho no menu de aplicativos
        --name TEXTO  nome no menu   --icon ARQUIVO  ícone (png/svg/jpg)   --pin  fixa na dock (GNOME)
  avd-menu unshortcut NOME           Remove o atalho
  avd-menu install                   Adiciona o AVD Menu ao menu de aplicativos (Linux)
  avd-menu uninstall                 Remove o AVD Menu do menu de aplicativos
  avd-menu sdk list [--all]          Lista pacotes instalados (ou todos os disponíveis)
  avd-menu sdk install PACOTE...     Instala pacotes (ex.: "system-images;android-36;google_apis;x86_64")
  avd-menu sdk uninstall PACOTE...   Remove pacotes
  avd-menu doctor                    Verifica o ambiente (KVM, bibliotecas, espaço)
  avd-menu version                   Mostra a versão

OPÇÕES GLOBAIS:
  --sdk CAMINHO    Usa este Android SDK (padrão: detecta ou ~/Android/Sdk)

Sem argumentos o programa abre a interface numa janela própria.
`, `AVD Menu %s — Android emulator manager

USAGE:
  avd-menu [ui]                      Open the graphical interface (default)
  avd-menu list [--json]             List AVDs
  avd-menu create NAME --device ID --image PACKAGE [--ram MB] [--cores N]
                                     Create an AVD (the image must be installed)
  avd-menu start NAME [options]      Start an emulator
        --cold  cold boot   --wipe  wipe data   --dgpu  dedicated GPU   --headless  no window
        --arg X  extra emulator argument (repeatable)
  avd-menu stop NAME                 Stop an emulator
  avd-menu shortcut NAME [options]   Create the app-menu shortcut
        --name TEXT  menu label   --icon FILE  icon (png/svg/jpg)   --pin  pin to dock (GNOME)
  avd-menu unshortcut NAME           Remove the shortcut
  avd-menu install                   Add AVD Menu to the application menu (Linux)
  avd-menu uninstall                 Remove AVD Menu from the application menu
  avd-menu sdk list [--all]          List installed packages (or everything available)
  avd-menu sdk install PACKAGE...    Install packages (e.g. "system-images;android-36;google_apis;x86_64")
  avd-menu sdk uninstall PACKAGE...  Remove packages
  avd-menu doctor                    Check the environment (KVM, libraries, disk space)
  avd-menu version                   Print the version

GLOBAL OPTIONS:
  --sdk PATH       Use this Android SDK (default: auto-detect or ~/Android/Sdk)

Without arguments the program opens the interface in its own window.
`), platform.Version)
}

func main() {
	args := os.Args[1:]
	// compatibilidade com o avd-menu.sh antigo
	args = legacyArgs(args)

	// --sdk pode aparecer em qualquer posição
	var rest []string
	for i := 0; i < len(args); i++ {
		if args[i] == "--sdk" && i+1 < len(args) {
			os.Setenv("ANDROID_SDK_ROOT", args[i+1])
			if _, err := platform.UpdateConfig(func(c *platform.Config) { c.SDKRoot = args[i+1] }); err != nil {
				fail("%v", err)
			}
			i++
			continue
		}
		rest = append(rest, args[i])
	}
	args = rest

	cmd := "ui"
	if len(args) > 0 {
		cmd, args = args[0], args[1:]
	}
	switch cmd {
	case "ui", "gui":
		cmdUI(args)
	case "list", "ls":
		cmdList(args)
	case "start", "run":
		cmdStart(args)
	case "stop":
		cmdStop(args)
	case "create":
		cmdCreate(args)
	case "shortcut":
		cmdShortcut(args)
	case "unshortcut":
		cmdUnshortcut(args)
	case "install":
		res, err := shortcut.InstallSelf()
		if err != nil {
			fail("%v", err)
		}
		fmt.Printf(tr("\"AVD Menu\" adicionado ao menu de aplicativos.\n  Arquivo: %s\n", "\"AVD Menu\" added to the application menu.\n  File: %s\n"), res.Path)
	case "uninstall":
		if err := shortcut.UninstallSelf(); err != nil {
			fail("%v", err)
		}
		fmt.Println(tr("Atalho removido.", "Shortcut removed."))
	case "sdk":
		cmdSDK(args)
	case "doctor":
		cmdDoctor()
	case "version", "--version", "-v":
		fmt.Println("avd-menu " + platform.Version)
	case "help", "--help", "-h":
		usage()
	case "_icon": // uso interno do empacotamento: avd-menu _icon TAMANHO SAIDA.png
		cmdIcon(args)
	default:
		// "avd-menu NOME" (como o script antigo): cria o atalho do AVD.
		if !strings.HasPrefix(cmd, "-") {
			cmdShortcut(append([]string{cmd}, args...))
			return
		}
		usage()
		os.Exit(2)
	}
}

// legacyArgs traduz as opções do avd-menu.sh para os subcomandos novos.
func legacyArgs(args []string) []string {
	if len(args) == 0 {
		return args
	}
	switch args[0] {
	case "--ui", "-u":
		return append([]string{"ui"}, args[1:]...)
	case "--list", "-l":
		return append([]string{"list"}, args[1:]...)
	case "--install":
		return append([]string{"install"}, args[1:]...)
	case "--uninstall":
		return append([]string{"uninstall"}, args[1:]...)
	case "--remove", "-r":
		return append([]string{"unshortcut"}, args[1:]...)
	}
	return args
}

func currentSDK() sdk.SDK { return sdk.Detect(platform.LoadConfig().SDKRoot) }

// ---- ui ----------------------------------------------------------------------

func cmdUI(args []string) {
	fs := flag.NewFlagSet("ui", flag.ExitOnError)
	port := fs.Int("port", 0, tr("porta (0 = aleatória)", "port (0 = random)"))
	noBrowser := fs.Bool("no-browser", false, tr("não abre a janela automaticamente", "do not open the window automatically"))
	keep := fs.Bool("keep-alive", false, tr("continua rodando quando a janela fecha", "keep running when the window closes"))
	newInst := fs.Bool("new", false, tr("não reaproveita uma instância já aberta", "do not reuse an already-open instance"))
	_ = fs.Parse(args)
	opts := server.Options{
		Port: *port, KeepAlive: *keep || *noBrowser, NewWindow: *newInst,
		Open: launcher.Open,
		Logf: func(format string, a ...any) { fmt.Fprintf(os.Stderr, format+"\n", a...) },
	}
	if *noBrowser {
		opts.Open = func(u string) (string, error) { fmt.Println(u); return "none", nil }
	}
	if err := server.Run(opts); err != nil {
		fail("%v", err)
	}
}

// ---- list / start / stop ---------------------------------------------------------

func cmdList(args []string) {
	fs := flag.NewFlagSet("list", flag.ExitOnError)
	asJSON := fs.Bool("json", false, tr("saída em JSON", "JSON output"))
	_ = fs.Parse(args)
	sd := currentSDK()
	list := avd.List(sd)
	running := emu.Running()
	if *asJSON {
		fmt.Print("[")
		for i, a := range list {
			if i > 0 {
				fmt.Print(",")
			}
			_, run := running[a.Name]
			fmt.Printf(`{"name":%q,"displayName":%q,"api":%q,"abi":%q,"device":%q,"running":%v}`, a.Name, a.DisplayName, a.API, a.ABI, a.DeviceName, run)
		}
		fmt.Println("]")
		return
	}
	if len(list) == 0 {
		fmt.Println(tr("Nenhum AVD encontrado. Abra a interface (avd-menu) para criar um.", "No AVDs found. Open the interface (avd-menu) to create one."))
		return
	}
	tw := tabwriter.NewWriter(os.Stdout, 0, 4, 2, ' ', 0)
	fmt.Fprintln(tw, tr("NOME\tDISPOSITIVO\tAPI\tABI\tESTADO", "NAME\tDEVICE\tAPI\tABI\tSTATE"))
	for _, a := range list {
		state := ""
		if _, ok := running[a.Name]; ok {
			state = tr("rodando", "running")
		}
		if a.Problem != "" {
			state = "⚠ " + a.Problem
		}
		fmt.Fprintf(tw, "%s\t%s\t%s\t%s\t%s\n", a.Name, a.DeviceName, a.API, a.ABI, state)
	}
	tw.Flush()
}

func cmdStart(args []string) {
	fs := flag.NewFlagSet("start", flag.ExitOnError)
	cold := fs.Bool("cold", false, "cold boot")
	wipe := fs.Bool("wipe", false, "wipe data")
	dgpu := fs.Bool("dgpu", false, tr("GPU dedicada", "dedicated GPU"))
	headless := fs.Bool("headless", false, tr("sem janela", "no window"))
	var extra multiFlag
	fs.Var(&extra, "arg", tr("argumento extra para o emulador (repetível)", "extra emulator argument (repeatable)"))
	name, rest := splitName(args)
	_ = fs.Parse(rest)
	if name == "" {
		fail(tr("informe o nome do AVD", "give the AVD name"))
	}
	opt := emu.StartOptions{Headless: *headless, ExtraArgs: extra}
	switch {
	case *wipe:
		opt.Mode = "wipe"
	case *cold:
		opt.Mode = "cold"
	}
	if *dgpu {
		opt.GPU = "dedicated"
	}
	pid, err := emu.Start(currentSDK(), name, opt)
	if err != nil {
		fail("%v", err)
	}
	fmt.Printf(tr("Emulador %s iniciado (PID %d). Log: %s\n", "Emulator %s started (PID %d). Log: %s\n"), name, pid, emu.LogPath(name))
}

func cmdStop(args []string) {
	if len(args) == 0 {
		fail(tr("informe o nome do AVD", "give the AVD name"))
	}
	if err := emu.Stop(currentSDK(), args[0]); err != nil {
		fail("%v", err)
	}
	fmt.Println(tr("Emulador parado.", "Emulator stopped."))
}

// multiFlag permite repetir uma opção (--arg a --arg b).
type multiFlag []string

func (m *multiFlag) String() string     { return strings.Join(*m, " ") }
func (m *multiFlag) Set(v string) error { *m = append(*m, v); return nil }

// splitName separa o nome do AVD (primeiro argumento que não é opção) das
// opções, para aceitar "start NOME --cold" e "start --cold NOME".
func splitName(args []string) (string, []string) {
	var name string
	var rest []string
	for _, a := range args {
		if name == "" && !strings.HasPrefix(a, "-") {
			name = a
			continue
		}
		rest = append(rest, a)
	}
	return name, rest
}

func cmdCreate(args []string) {
	fs := flag.NewFlagSet("create", flag.ExitOnError)
	device := fs.String("device", "pixel_9", tr("id do perfil de hardware", "hardware profile id"))
	image := fs.String("image", "", tr("pacote da imagem de sistema", "system image package"))
	display := fs.String("display-name", "", tr("nome de exibição", "display name"))
	ram := fs.Int("ram", 0, tr("RAM em MB", "RAM in MB"))
	cores := fs.Int("cores", 0, tr("núcleos de CPU", "CPU cores"))
	name, rest := splitName(args)
	_ = fs.Parse(rest)
	if name == "" || *image == "" {
		fail(tr("uso: avd-menu create NOME --device ID --image PACOTE", "usage: avd-menu create NAME --device ID --image PACKAGE"))
	}
	spec := avd.CreateSpec{Name: name, DeviceID: *device, ImagePkg: *image}
	if *display != "" {
		spec.DisplayName = display
	}
	if *ram > 0 {
		spec.RAMMB = ram
	}
	if *cores > 0 {
		spec.Cores = cores
	}
	a, err := avd.Create(currentSDK(), spec)
	if err != nil {
		fail("%v", err)
	}
	fmt.Printf(tr("AVD criado: %s (%s, API %s)\n  %s\n", "AVD created: %s (%s, API %s)\n  %s\n"), a.Name, a.DeviceName, a.API, a.Dir)
}

// ---- atalhos ------------------------------------------------------------------------

func cmdShortcut(args []string) {
	fs := flag.NewFlagSet("shortcut", flag.ExitOnError)
	label := fs.String("name", "", tr("nome no menu", "menu label"))
	fs.StringVar(label, "n", "", tr("nome no menu", "menu label"))
	icon := fs.String("icon", "", tr("ícone", "icon"))
	fs.StringVar(icon, "i", "", tr("ícone", "icon"))
	pin := fs.Bool("pin", false, tr("fixar na dock", "pin to the dock"))
	name, rest := splitName(args)
	_ = fs.Parse(rest)
	if name == "" {
		list := avd.List(currentSDK())
		var names []string
		for _, a := range list {
			names = append(names, a.Name)
		}
		fail(tr("informe o nome do AVD. Disponíveis: %s", "give the AVD name. Available: %s"), strings.Join(names, ", "))
	}
	res, err := shortcut.Create(currentSDK(), shortcut.Options{AVD: name, DisplayName: *label, IconPath: *icon, Pin: *pin})
	if err != nil {
		fail("%v", err)
	}
	fmt.Printf(tr("Atalho criado.\n  AVD:     %s\n  Nome:    %s\n  Arquivo: %s\n", "Shortcut created.\n  AVD:   %s\n  Label: %s\n  File:  %s\n"), name, res.DisplayName, res.Path)
	if res.GPUAction {
		fmt.Println(tr("  GPU:     ação \"Iniciar com placa de vídeo dedicada\" disponível (clique direito no ícone)", "  GPU:     \"Start with dedicated GPU\" action available (right-click the icon)"))
	}
}

func cmdUnshortcut(args []string) {
	if len(args) == 0 {
		fail(tr("informe o nome do AVD", "give the AVD name"))
	}
	if err := shortcut.Remove(args[0]); err != nil {
		fail("%v", err)
	}
	fmt.Println(tr("Atalho removido.", "Shortcut removed."))
}

// ---- sdk -----------------------------------------------------------------------------

func cmdSDK(args []string) {
	if len(args) == 0 {
		usage()
		os.Exit(2)
	}
	sd := currentSDK()
	cfg := platform.LoadConfig()
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	switch args[0] {
	case "list":
		fs := flag.NewFlagSet("sdk list", flag.ExitOnError)
		all := fs.Bool("all", false, tr("todos os pacotes disponíveis", "all available packages"))
		_ = fs.Parse(args[1:])
		fmt.Printf("SDK: %s\n", sd.Root)
		inst := sd.InstalledMap()
		if !*all {
			keys := make([]string, 0, len(inst))
			for k := range inst {
				keys = append(keys, k)
			}
			sort.Strings(keys)
			for _, k := range keys {
				fmt.Printf("  %-55s %-12s %s\n", k, inst[k].Rev, inst[k].Name)
			}
			return
		}
		cat, err := sdk.FetchCatalog(ctx, false)
		if err != nil {
			fail("%v", err)
		}
		for _, r := range cat.Latest(cfg.ShowPreview) {
			mark := " "
			if _, ok := inst[r.Path]; ok {
				mark = "✓"
			}
			fmt.Printf("%s %-60s %-10s %s\n", mark, r.Path, r.Revision, r.Name)
		}
	case "install":
		fs := flag.NewFlagSet("sdk install", flag.ExitOnError)
		yes := fs.Bool("accept-licenses", false, tr("aceita as licenças sem perguntar", "accept licenses without asking"))
		fs.BoolVar(yes, "y", false, tr("aceita as licenças sem perguntar", "accept licenses without asking"))
		names, flags := splitAll(args[1:])
		_ = fs.Parse(flags)
		if len(names) == 0 {
			fail(tr("informe os pacotes", "give the packages"))
		}
		cat, err := sdk.FetchCatalog(ctx, false)
		if err != nil {
			fail("%v", err)
		}
		plan := sd.PlanInstall(cat, names, cfg.ShowPreview, false)
		if len(plan.Missing) > 0 {
			fail(tr("pacote indisponível: %s", "package unavailable: %s"), strings.Join(plan.Missing, ", "))
		}
		if len(plan.Install) == 0 {
			fmt.Println(tr("Nada a fazer: já instalado.", "Nothing to do: already installed."))
			return
		}
		fmt.Println(tr("Serão instalados:", "Will install:"))
		for _, p := range plan.Install {
			a := p.ArchiveFor(platform.HostOS(), platform.HostArch())
			fmt.Printf("  %s (%s)\n", p.Name, sdk.HumanBytes(a.Size))
		}
		for _, l := range plan.Licenses {
			if !*yes {
				fmt.Printf("\n%s\n\n", l.Text)
				fmt.Printf(tr("Aceita a licença %q? [s/N] ", "Accept license %q? [y/N] "), l.ID)
				ans, _ := bufio.NewReader(os.Stdin).ReadString('\n')
				ans = strings.ToLower(strings.TrimSpace(ans))
				if ans != "s" && ans != "y" && ans != "sim" && ans != "yes" {
					fail(tr("licença não aceita", "license not accepted"))
				}
			}
			if err := sd.Accept(l); err != nil {
				fail("%v", err)
			}
		}
		last := ""
		err = sd.Install(ctx, cat, plan, func(p sdk.Progress) {
			line := fmt.Sprintf("\r[%d/%d] %-8s %5.1f%%  %s", p.Index, p.Count, p.Phase, p.Overall*100, p.Name)
			if line != last {
				fmt.Fprintf(os.Stderr, "%-100s", line)
				last = line
			}
		}, func(f string, a ...any) { fmt.Fprintf(os.Stderr, "\n"+f+"\n", a...) })
		fmt.Fprintln(os.Stderr)
		if err != nil {
			fail("%v", err)
		}
		fmt.Println(tr("Concluído.", "Done."))
	case "uninstall":
		if len(args) < 2 {
			fail(tr("informe os pacotes", "give the packages"))
		}
		if err := sd.Uninstall(args[1:]); err != nil {
			fail("%v", err)
		}
		fmt.Println(tr("Removido.", "Removed."))
	default:
		usage()
		os.Exit(2)
	}
}

func splitAll(args []string) (names, flags []string) {
	for _, a := range args {
		if strings.HasPrefix(a, "-") {
			flags = append(flags, a)
		} else {
			names = append(names, a)
		}
	}
	return
}

// ---- doctor --------------------------------------------------------------------------

func cmdDoctor() {
	sd := currentSDK()
	fmt.Printf("SDK: %s\nAVD home: %s\n\n", sd.Root, avd.Home())
	icons := map[string]string{"ok": "✓", "warn": "!", "error": "✗", "info": "i"}
	for _, c := range emu.Diagnose(sd) {
		fmt.Printf(" %s %s", icons[c.Level], c.ID)
		var parts []string
		for k, v := range c.Args {
			parts = append(parts, k+"="+v)
		}
		sort.Strings(parts)
		if len(parts) > 0 {
			fmt.Printf("  (%s)", strings.Join(parts, ", "))
		}
		fmt.Println()
		if c.Fix != "" {
			fmt.Printf("     → %s\n", c.Fix)
		}
	}
}

// cmdIcon gera arquivos do ícone padrão (usado pelo empacotamento):
//
//	avd-menu _icon 256 saida.png     PNG no tamanho pedido
//	avd-menu _icon icns saida.icns   ícone do macOS (16 a 1024 px)
func cmdIcon(args []string) {
	if len(args) != 2 {
		fail("uso: avd-menu _icon TAMANHO|icns SAIDA")
	}
	if args[0] == "icns" {
		data, err := shortcut.ICNS(assets.IconPNG)
		if err != nil {
			fail("%v", err)
		}
		if err := os.WriteFile(args[1], data, 0o644); err != nil {
			fail("%v", err)
		}
		return
	}
	var size int
	fmt.Sscanf(args[0], "%d", &size)
	if size < 16 || size > 1024 {
		fail(tr("tamanho inválido", "invalid size"))
	}
	src, err := png.Decode(bytes.NewReader(assets.IconPNG))
	if err != nil {
		fail("%v", err)
	}
	f, err := os.Create(args[1])
	if err != nil {
		fail("%v", err)
	}
	defer f.Close()
	if err := png.Encode(f, shortcut.Resize(src, size)); err != nil {
		fail("%v", err)
	}
}
