package platform

import "testing"

func TestSlugify(t *testing.T) {
	for in, want := range map[string]string{
		"Pixel_9 API.36": "pixel-9-api-36", "DEV": "dev", "--a--b--": "a-b", "": "", "Ação 2": "a-o-2",
	} {
		if got := Slugify(in); got != want {
			t.Errorf("Slugify(%q) = %q, quer %q", in, got, want)
		}
	}
}

func TestConfigRoundTrip(t *testing.T) {
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	t.Setenv("HOME", t.TempDir())
	if c := LoadConfig(); c.SDKRoot != "" {
		t.Fatalf("config vazia esperada: %+v", c)
	}
	if _, err := UpdateConfig(func(c *Config) { c.SDKRoot = "/x"; c.Lang = "pt" }); err != nil {
		t.Fatal(err)
	}
	if c := LoadConfig(); c.SDKRoot != "/x" || c.Lang != "pt" {
		t.Errorf("config: %+v", c)
	}
}

func TestTrUsesRuntimeLang(t *testing.T) {
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	SetRuntimeLang("en")
	if Tr("oi", "hi") != "hi" {
		t.Error("deveria usar inglês")
	}
	SetRuntimeLang("pt")
	if Tr("oi", "hi") != "oi" {
		t.Error("deveria usar português")
	}
	if got := Trf("a %d", "b %d", 3); got != "a 3" {
		t.Errorf("Trf = %q", got)
	}
}

func TestCleanEnvDropsAppImageVars(t *testing.T) {
	t.Setenv("APPIMAGE", "/x.AppImage")
	t.Setenv("APPDIR", "/tmp/mnt")
	for _, kv := range CleanEnv("FOO=1") {
		if kv == "APPIMAGE=/x.AppImage" || kv == "APPDIR=/tmp/mnt" {
			t.Errorf("variável do AppImage vazou: %s", kv)
		}
	}
}
