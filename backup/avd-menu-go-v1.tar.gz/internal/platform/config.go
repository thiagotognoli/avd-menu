package platform

import (
	"encoding/json"
	"os"
	"path/filepath"
	"sync"
)

// Config são as preferências persistidas do aplicativo.
type Config struct {
	// SDKRoot é o Android SDK escolhido. Vazio = detectar automaticamente.
	SDKRoot string `json:"sdkRoot,omitempty"`
	// ShowPreview inclui canais beta/dev/canary na lista de pacotes.
	ShowPreview bool `json:"showPreview,omitempty"`
	// Lang força o idioma da interface ("pt", "en"). Vazio = do navegador.
	Lang string `json:"lang,omitempty"`
	// Theme: "", "light" ou "dark".
	Theme string `json:"theme,omitempty"`
	// AVDExtraArgs guarda argumentos extras do emulador por AVD.
	AVDExtraArgs map[string]string `json:"avdExtraArgs,omitempty"`
	// Shortcuts guarda os metadados dos atalhos criados por AVD.
	Shortcuts map[string]ShortcutMeta `json:"shortcuts,omitempty"`
	// UserDevices são os perfis de hardware criados pelo usuário.
	UserDevices []json.RawMessage `json:"userDevices,omitempty"`
}

// ShortcutMeta registra como o atalho de um AVD foi criado.
type ShortcutMeta struct {
	Name string `json:"name,omitempty"`
	Icon string `json:"icon,omitempty"`
}

var (
	cfgMu sync.Mutex
)

func configPath() string { return filepath.Join(ConfigDir(), "config.json") }

// LoadConfig lê as preferências (devolve o padrão se não existirem).
func LoadConfig() Config {
	cfgMu.Lock()
	defer cfgMu.Unlock()
	return loadConfigLocked()
}

func loadConfigLocked() Config {
	var c Config
	b, err := os.ReadFile(configPath())
	if err == nil {
		_ = json.Unmarshal(b, &c)
	}
	return c
}

// UpdateConfig aplica fn sobre as preferências atuais e grava o resultado.
func UpdateConfig(fn func(*Config)) (Config, error) {
	cfgMu.Lock()
	defer cfgMu.Unlock()
	c := loadConfigLocked()
	fn(&c)
	if err := os.MkdirAll(ConfigDir(), 0o755); err != nil {
		return c, err
	}
	b, err := json.MarshalIndent(c, "", "  ")
	if err != nil {
		return c, err
	}
	tmp := configPath() + ".tmp"
	if err := os.WriteFile(tmp, b, 0o644); err != nil {
		return c, err
	}
	return c, os.Rename(tmp, configPath())
}
