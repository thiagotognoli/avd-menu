package platform

import (
	"fmt"
	"os"
	"strings"
	"sync/atomic"
)

var runtimeLang atomic.Value // string: idioma que a interface está usando agora

// SetRuntimeLang registra o idioma efetivo da interface ("pt" ou "en"), para
// que as mensagens geradas aqui no servidor saiam no mesmo idioma.
func SetRuntimeLang(l string) {
	if l == "pt" || l == "en" {
		runtimeLang.Store(l)
	}
}

// Lang devolve "pt" ou "en": o idioma da interface, senão o escolhido nas
// configurações, senão o do sistema (LC_ALL/LC_MESSAGES/LANG).
func Lang() string {
	if v, ok := runtimeLang.Load().(string); ok && v != "" {
		return v
	}
	if l := LoadConfig().Lang; l == "pt" || l == "en" {
		return l
	}
	for _, k := range []string{"LC_ALL", "LC_MESSAGES", "LANG"} {
		if v := os.Getenv(k); v != "" {
			if strings.HasPrefix(strings.ToLower(v), "pt") {
				return "pt"
			}
			return "en"
		}
	}
	return "en"
}

// Tr escolhe o texto pelo idioma atual.
func Tr(pt, en string) string {
	if Lang() == "pt" {
		return pt
	}
	return en
}

// Trf é Tr + Sprintf.
func Trf(pt, en string, a ...any) string { return fmt.Sprintf(Tr(pt, en), a...) }

// Errorf é fmt.Errorf com o formato escolhido pelo idioma (aceita %w).
func Errorf(pt, en string, a ...any) error { return fmt.Errorf(Tr(pt, en), a...) }
