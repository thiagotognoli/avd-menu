// Package platform reúne o que depende do sistema operacional: diretórios do
// aplicativo, identificação do host (nomes usados pelo repositório do Android
// SDK) e utilitários pequenos usados pelo resto do programa.
package platform

import (
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
)

// Version é sobrescrita no build com -ldflags "-X avdmenu/internal/platform.Version=...".
var Version = "dev"

const AppName = "avd-menu"

// HostOS devolve o nome do SO como o repositório do SDK o escreve.
func HostOS() string {
	switch runtime.GOOS {
	case "darwin":
		return "macosx"
	case "windows":
		return "windows"
	default:
		return "linux"
	}
}

// HostArch devolve a arquitetura como o repositório do SDK a escreve.
func HostArch() string {
	switch runtime.GOARCH {
	case "arm64":
		return "aarch64"
	case "amd64":
		return "x64"
	default:
		return runtime.GOARCH
	}
}

// IsMac informa se estamos no macOS.
func IsMac() bool { return runtime.GOOS == "darwin" }

// IsLinux informa se estamos no Linux.
func IsLinux() bool { return runtime.GOOS == "linux" }

// Home é o diretório do usuário.
func Home() string {
	if h, err := os.UserHomeDir(); err == nil && h != "" {
		return h
	}
	return os.Getenv("HOME")
}

// ConfigDir guarda as configurações do aplicativo.
func ConfigDir() string {
	if d, err := os.UserConfigDir(); err == nil && d != "" {
		return filepath.Join(d, AppName)
	}
	return filepath.Join(Home(), ".config", AppName)
}

// CacheDir guarda manifestos baixados e perfis do navegador.
func CacheDir() string {
	if d, err := os.UserCacheDir(); err == nil && d != "" {
		return filepath.Join(d, AppName)
	}
	return filepath.Join(Home(), ".cache", AppName)
}

// StateDir guarda logs e o arquivo de instância única.
func StateDir() string {
	if IsMac() {
		return filepath.Join(Home(), "Library", "Application Support", AppName)
	}
	if d := os.Getenv("XDG_STATE_HOME"); d != "" {
		return filepath.Join(d, AppName)
	}
	return filepath.Join(Home(), ".local", "state", AppName)
}

// DataHome é o XDG_DATA_HOME (atalhos .desktop e ícones).
func DataHome() string {
	if d := os.Getenv("XDG_DATA_HOME"); d != "" {
		return d
	}
	return filepath.Join(Home(), ".local", "share")
}

// Exe devolve o caminho do executável que o usuário iniciou. Dentro de um
// AppImage o executável real fica num ponto de montagem temporário, então o
// caminho útil para atalhos é o do próprio arquivo .AppImage.
func Exe() string {
	if p := os.Getenv("APPIMAGE"); p != "" {
		if _, err := os.Stat(p); err == nil {
			return p
		}
	}
	p, err := os.Executable()
	if err != nil {
		return os.Args[0]
	}
	if r, err := filepath.EvalSymlinks(p); err == nil {
		p = r
	}
	return p
}

// CleanEnv devolve o ambiente sem as variáveis que o AppImage injeta, para que
// programas filhos (emulador, navegador) não herdem o contexto do pacote.
func CleanEnv(extra ...string) []string {
	drop := map[string]bool{"APPDIR": true, "APPIMAGE": true, "ARGV0": true, "OWD": true}
	var out []string
	for _, kv := range os.Environ() {
		k := kv
		if i := strings.IndexByte(kv, '='); i >= 0 {
			k = kv[:i]
		}
		if drop[k] {
			continue
		}
		out = append(out, kv)
	}
	return append(out, extra...)
}

// Which procura um executável no PATH, devolvendo "" se não existir.
func Which(name string) string {
	p, err := exec.LookPath(name)
	if err != nil {
		return ""
	}
	return p
}

// Slugify gera um identificador seguro para nomes de arquivo/ID de atalho.
func Slugify(s string) string {
	var b strings.Builder
	dash := false
	for _, r := range strings.ToLower(s) {
		if (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') {
			b.WriteRune(r)
			dash = false
		} else if !dash && b.Len() > 0 {
			b.WriteByte('-')
			dash = true
		}
	}
	return strings.TrimRight(b.String(), "-")
}

// FileExists informa se o caminho existe e não é diretório.
func FileExists(p string) bool {
	st, err := os.Stat(p)
	return err == nil && !st.IsDir()
}

// DirExists informa se o caminho existe e é diretório.
func DirExists(p string) bool {
	st, err := os.Stat(p)
	return err == nil && st.IsDir()
}

// IsExecutable informa se o caminho é um arquivo executável.
func IsExecutable(p string) bool {
	st, err := os.Stat(p)
	return err == nil && !st.IsDir() && st.Mode()&0o111 != 0
}
