package server

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

type env struct {
	srv    *Server
	ts     *httptest.Server
	client *http.Client
	root   string
}

// newEnv sobe o servidor num ambiente totalmente isolado (HOME, XDG, AVD home e
// um SDK falso com uma imagem de sistema instalada).
func newEnv(t *testing.T) *env {
	t.Helper()
	tmp := t.TempDir()
	t.Setenv("HOME", filepath.Join(tmp, "home"))
	t.Setenv("XDG_CONFIG_HOME", filepath.Join(tmp, "cfg"))
	t.Setenv("XDG_CACHE_HOME", filepath.Join(tmp, "cache"))
	t.Setenv("XDG_STATE_HOME", filepath.Join(tmp, "state"))
	t.Setenv("XDG_DATA_HOME", filepath.Join(tmp, "data"))
	t.Setenv("ANDROID_AVD_HOME", filepath.Join(tmp, "avd"))
	t.Setenv("ANDROID_SDK_ROOT", "")
	t.Setenv("ANDROID_HOME", "")
	t.Setenv("PATH", "/usr/bin:/bin")
	root := filepath.Join(tmp, "sdk")
	img := filepath.Join(root, "system-images", "android-36", "google_apis", "x86_64")
	_ = os.MkdirAll(img, 0o755)
	_ = os.WriteFile(filepath.Join(img, "source.properties"), []byte("SystemImage.TagId=google_apis\nSystemImage.TagDisplay=Google APIs\nSystemImage.Abi=x86_64\nAndroidVersion.ApiLevel=36\n"), 0o644)
	_ = os.MkdirAll(filepath.Join(root, "emulator"), 0o755)
	_ = os.WriteFile(filepath.Join(root, "emulator", "emulator"), []byte("#!/bin/sh\nsleep 30\n"), 0o755)
	_ = os.MkdirAll(filepath.Dir(filepath.Join(tmp, "cfg", "avd-menu", "config.json")), 0o755)
	_ = os.WriteFile(filepath.Join(tmp, "cfg", "avd-menu", "config.json"), []byte(`{"sdkRoot":`+jsonStr(root)+`}`), 0o644)

	ctx, cancel := context.WithCancel(context.Background())
	t.Cleanup(cancel)
	s := newServer(Options{}, cancel)
	ts := httptest.NewUnstartedServer(nil)
	ts.Config.Handler = s.guard(s.routes())
	ts.Start()
	t.Cleanup(ts.Close)
	_ = ctx
	u, _ := url.Parse(ts.URL)
	s.port = mustPort(u.Port())
	jar := &simpleJar{}
	return &env{srv: s, ts: ts, client: &http.Client{Jar: jar, Timeout: 20 * time.Second, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}, root: root}
}

func jsonStr(s string) string { b, _ := json.Marshal(s); return string(b) }
func mustPort(p string) int {
	n := 0
	for _, c := range p {
		n = n*10 + int(c-'0')
	}
	return n
}

type simpleJar struct{ cookies []*http.Cookie }

func (j *simpleJar) SetCookies(_ *url.URL, c []*http.Cookie) { j.cookies = append(j.cookies, c...) }
func (j *simpleJar) Cookies(*url.URL) []*http.Cookie         { return j.cookies }

func (e *env) login(t *testing.T) {
	t.Helper()
	resp, err := e.client.Get(e.ts.URL + "/?t=" + e.srv.token)
	if err != nil {
		t.Fatal(err)
	}
	resp.Body.Close()
	if resp.StatusCode != http.StatusFound {
		t.Fatalf("login: status %d", resp.StatusCode)
	}
}

func (e *env) do(t *testing.T, method, path string, body any, out any) int {
	t.Helper()
	var rd io.Reader
	if body != nil {
		b, _ := json.Marshal(body)
		rd = bytes.NewReader(b)
	}
	req, _ := http.NewRequest(method, e.ts.URL+path, rd)
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	resp, err := e.client.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	if out != nil && len(raw) > 0 {
		if err := json.Unmarshal(raw, out); err != nil {
			t.Fatalf("%s %s: resposta não é JSON: %s", method, path, raw)
		}
	}
	return resp.StatusCode
}

func TestGuard(t *testing.T) {
	e := newEnv(t)
	// sem cookie
	if code := e.do(t, "GET", "/api/state", nil, nil); code != http.StatusUnauthorized {
		t.Errorf("sem cookie: %d", code)
	}
	// token errado
	resp, _ := e.client.Get(e.ts.URL + "/?t=errado")
	resp.Body.Close()
	if resp.StatusCode != http.StatusUnauthorized {
		t.Errorf("token errado: %d", resp.StatusCode)
	}
	// o token na query não vale para a API
	resp, _ = e.client.Get(e.ts.URL + "/api/state?t=" + e.srv.token)
	resp.Body.Close()
	if resp.StatusCode != http.StatusUnauthorized {
		t.Errorf("token na API: %d", resp.StatusCode)
	}
	e.login(t)
	if code := e.do(t, "GET", "/api/state", nil, nil); code != http.StatusOK {
		t.Errorf("com cookie: %d", code)
	}
	// Host de outro site (DNS rebinding)
	req, _ := http.NewRequest("GET", e.ts.URL+"/api/state", nil)
	req.Host = "evil.example.com"
	resp, _ = e.client.Do(req)
	resp.Body.Close()
	if resp.StatusCode != http.StatusForbidden {
		t.Errorf("host inválido: %d", resp.StatusCode)
	}
	// Origin de outro site (CSRF)
	req, _ = http.NewRequest("POST", e.ts.URL+"/api/shutdown", nil)
	req.Header.Set("Origin", "https://evil.example.com")
	resp, _ = e.client.Do(req)
	resp.Body.Close()
	if resp.StatusCode != http.StatusForbidden {
		t.Errorf("origin inválido: %d", resp.StatusCode)
	}
	// a interface é servida
	resp, _ = e.client.Get(e.ts.URL + "/")
	b, _ := io.ReadAll(resp.Body)
	resp.Body.Close()
	if resp.StatusCode != 200 || !strings.Contains(string(b), "AVD Menu") {
		t.Errorf("index: %d", resp.StatusCode)
	}
	resp, _ = e.client.Get(e.ts.URL + "/js/app.js")
	resp.Body.Close()
	if ct := resp.Header.Get("Content-Type"); !strings.Contains(ct, "javascript") {
		t.Errorf("content-type do app.js = %q", ct)
	}
}

func TestStateAndAVDLifecycle(t *testing.T) {
	e := newEnv(t)
	e.login(t)

	var st struct {
		SDK struct {
			Root        string `json:"root"`
			Exists      bool   `json:"exists"`
			HasEmulator bool   `json:"hasEmulator"`
			HasAdb      bool   `json:"hasAdb"`
		} `json:"sdk"`
	}
	if code := e.do(t, "GET", "/api/state", nil, &st); code != 200 || st.SDK.Root != e.root || !st.SDK.HasEmulator || st.SDK.HasAdb {
		t.Fatalf("state: %d %+v", code, st)
	}

	var devs struct {
		Devices []struct{ ID string } `json:"devices"`
	}
	e.do(t, "GET", "/api/devices", nil, &devs)
	if len(devs.Devices) < 80 {
		t.Errorf("dispositivos: %d", len(devs.Devices))
	}

	var prev struct {
		Settings struct {
			RAMMB int `json:"ramMB"`
			Cores int `json:"cores"`
		} `json:"settings"`
	}
	if code := e.do(t, "POST", "/api/avds/preview", map[string]string{"deviceId": "pixel_9", "imagePkg": "system-images;android-36;google_apis;x86_64"}, &prev); code != 200 || prev.Settings.RAMMB != 2048 {
		t.Errorf("preview: %d %+v", code, prev)
	}

	var created struct {
		AVD struct {
			Name        string `json:"name"`
			DisplayName string `json:"displayName"`
		} `json:"avd"`
		Shortcut struct {
			Path string `json:"path"`
		} `json:"shortcut"`
	}
	body := map[string]any{
		"name": "Server_Test", "deviceId": "pixel_9", "imagePkg": "system-images;android-36;google_apis;x86_64",
		"displayName": "Server Test", "ramMB": 3072, "shortcut": map[string]any{"displayName": "Server Test!"},
	}
	if code := e.do(t, "POST", "/api/avds", body, &created); code != 200 || created.AVD.Name != "Server_Test" {
		t.Fatalf("create: %d %+v", code, created)
	}
	if created.Shortcut.Path == "" {
		t.Error("o atalho deveria ter sido criado junto")
	}
	var errResp struct{ Error string }
	if code := e.do(t, "POST", "/api/avds", body, &errResp); code != 400 || errResp.Error == "" {
		t.Errorf("recriar deveria dar 400: %d %v", code, errResp)
	}

	var list struct {
		AVDs []struct {
			Name     string `json:"name"`
			Shortcut struct {
				Exists bool `json:"exists"`
			} `json:"shortcut"`
		} `json:"avds"`
	}
	e.do(t, "GET", "/api/avds", nil, &list)
	if len(list.AVDs) != 1 || list.AVDs[0].Name != "Server_Test" || !list.AVDs[0].Shortcut.Exists {
		t.Fatalf("lista: %+v", list)
	}

	var det struct {
		Settings struct {
			RAMMB int `json:"ramMB"`
		} `json:"settings"`
		Raw string `json:"raw"`
	}
	e.do(t, "GET", "/api/avds/Server_Test", nil, &det)
	if det.Settings.RAMMB != 3072 || !strings.Contains(det.Raw, "image.sysdir.1=") {
		t.Errorf("detalhe: %+v", det.Settings)
	}
	if code := e.do(t, "PUT", "/api/avds/Server_Test", map[string]any{"ramMB": 1024, "gpuMode": "host"}, nil); code != 200 {
		t.Errorf("update: %d", code)
	}
	e.do(t, "GET", "/api/avds/Server_Test", nil, &det)
	if det.Settings.RAMMB != 1024 {
		t.Errorf("RAM após editar = %d", det.Settings.RAMMB)
	}
	if code := e.do(t, "PUT", "/api/avds/Server_Test", map[string]any{"ramMB": 10}, &errResp); code != 400 {
		t.Errorf("RAM inválida deveria dar 400: %d", code)
	}
	if code := e.do(t, "GET", "/api/avds/..%2Fetc", nil, nil); code == 200 {
		t.Error("nome com .. não pode funcionar")
	}
	if code := e.do(t, "GET", "/api/avds/Nao_Existe", nil, nil); code != 404 {
		t.Errorf("AVD inexistente: %d", code)
	}

	if code := e.do(t, "POST", "/api/avds/Server_Test/duplicate", map[string]string{"name": "Server_Copy"}, nil); code != 200 {
		t.Errorf("duplicate: %d", code)
	}
	if code := e.do(t, "POST", "/api/avds/Server_Test/wipe", nil, nil); code != 200 {
		t.Errorf("wipe: %d", code)
	}
	if code := e.do(t, "DELETE", "/api/avds/Server_Copy", nil, nil); code != 200 {
		t.Errorf("delete: %d", code)
	}
	if code := e.do(t, "DELETE", "/api/avds/Server_Test/shortcut", nil, nil); code != 200 {
		t.Errorf("remover atalho: %d", code)
	}
	if code := e.do(t, "DELETE", "/api/avds/Server_Test", nil, nil); code != 200 {
		t.Errorf("delete: %d", code)
	}
	e.do(t, "GET", "/api/avds", nil, &list)
	if len(list.AVDs) != 0 {
		t.Errorf("deveria estar vazio: %+v", list)
	}
}

func TestStartAndStopWithFakeEmulator(t *testing.T) {
	e := newEnv(t)
	e.login(t)
	// o "emulador" falso aceita qualquer argumento e dorme; imita a linha de comando real
	fake := filepath.Join(e.root, "emulator", "emulator")
	_ = os.WriteFile(fake, []byte("#!/bin/bash\nexec -a \"$0 $*\" sleep 30\n"), 0o755)
	e.do(t, "POST", "/api/avds", map[string]any{"name": "Fake", "deviceId": "pixel_9", "imagePkg": "system-images;android-36;google_apis;x86_64"}, nil)

	// processo que "se parece" com o emulador: usa um script cujo nome é emulator
	var out map[string]any
	code := e.do(t, "POST", "/api/avds/Fake/start", map[string]any{"mode": "cold"}, &out)
	if code != 200 {
		t.Fatalf("start: %d %v", code, out)
	}
	t.Cleanup(func() { _ = exec_kill("Fake") })
	var list struct {
		AVDs []struct {
			Name    string         `json:"name"`
			Running map[string]any `json:"running"`
		} `json:"avds"`
	}
	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		e.do(t, "GET", "/api/avds", nil, &list)
		if len(list.AVDs) == 1 && list.AVDs[0].Running != nil {
			break
		}
		time.Sleep(200 * time.Millisecond)
	}
	if len(list.AVDs) != 1 || list.AVDs[0].Running == nil {
		t.Skip("o ambiente de teste não permitiu detectar o processo (ps)")
	}
	if code := e.do(t, "POST", "/api/avds/Fake/start", nil, nil); code == 200 {
		t.Error("iniciar duas vezes deveria falhar")
	}
	if code := e.do(t, "DELETE", "/api/avds/Fake", nil, nil); code != 409 {
		t.Errorf("apagar rodando deveria dar 409: %d", code)
	}
	if code := e.do(t, "POST", "/api/avds/Fake/stop", nil, nil); code != 200 {
		t.Errorf("stop: %d", code)
	}
	deadline = time.Now().Add(15 * time.Second)
	for time.Now().Before(deadline) {
		list.AVDs = nil // o decoder não zera campos ausentes no JSON novo
		e.do(t, "GET", "/api/avds", nil, &list)
		if len(list.AVDs) == 1 && list.AVDs[0].Running == nil {
			return
		}
		time.Sleep(300 * time.Millisecond)
	}
	t.Error("o emulador deveria ter parado")
}

func TestSplitArgs(t *testing.T) {
	got := splitArgs(`-gpu host -dns-server "8.8.8.8" -prop 'a b'  c`)
	want := []string{"-gpu", "host", "-dns-server", "8.8.8.8", "-prop", "a b", "c"}
	if len(got) != len(want) {
		t.Fatalf("got %q", got)
	}
	for i := range want {
		if got[i] != want[i] {
			t.Errorf("arg %d = %q, quer %q", i, got[i], want[i])
		}
	}
}

func TestPackagesOfflineStillListsInstalled(t *testing.T) {
	e := newEnv(t)
	e.login(t)
	t.Setenv("HTTPS_PROXY", "http://127.0.0.1:1") // sem rede
	t.Setenv("https_proxy", "http://127.0.0.1:1")
	var r struct {
		Offline  bool `json:"offline"`
		Packages []struct {
			Path      string `json:"path"`
			Installed bool   `json:"installed"`
		} `json:"packages"`
	}
	// sem cache e sem rede o catálogo falha, mas a resposta continua útil
	if code := e.do(t, "GET", "/api/packages", nil, &r); code != 200 {
		t.Fatalf("status %d", code)
	}
	_ = r
}
