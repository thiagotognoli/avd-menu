package server

import (
	"regexp"
	"sort"
	"strconv"
	"strings"

	"avdmenu/internal/platform"
	"avdmenu/internal/sdk"
)

// PkgView é um pacote do SDK como a interface o vê.
type PkgView struct {
	Path        string `json:"path"`
	Name        string `json:"name"`
	Revision    string `json:"revision"`
	Type        string `json:"type"`
	Channel     string `json:"channel"`
	Installed   bool   `json:"installed"`
	InstalledRv string `json:"installedRevision,omitempty"`
	Update      bool   `json:"update,omitempty"`
	Available   bool   `json:"available"` // existe download para este sistema
	Size        int64  `json:"size"`
	License     string `json:"license,omitempty"`
	Obsolete    bool   `json:"obsolete,omitempty"`

	// Imagens de sistema e plataformas
	API        string `json:"api,omitempty"`
	APIName    string `json:"apiName,omitempty"`
	Ext        string `json:"ext,omitempty"`
	Tag        string `json:"tag,omitempty"`
	TagDisplay string `json:"tagDisplay,omitempty"`
	ABI        string `json:"abi,omitempty"`
	Vendor     string `json:"vendor,omitempty"`
	PlayStore  bool   `json:"playStore,omitempty"`
	Compat     string `json:"compat,omitempty"`  // ok | slow | no
	Allowed    *bool  `json:"allowed,omitempty"` // imagem serve para o dispositivo escolhido
}

func pkgType(path string) string {
	switch {
	case strings.HasPrefix(path, "system-images;"):
		return "sysimg"
	case strings.HasPrefix(path, "platforms;"):
		return "platform"
	case strings.HasPrefix(path, "build-tools;"):
		return "build-tools"
	case strings.HasPrefix(path, "cmdline-tools;"):
		return "cmdline-tools"
	case path == "platform-tools":
		return "platform-tools"
	case path == "emulator":
		return "emulator"
	case strings.HasPrefix(path, "ndk"):
		return "ndk"
	case strings.HasPrefix(path, "cmake;"):
		return "cmake"
	case strings.HasPrefix(path, "sources;"):
		return "sources"
	case strings.HasPrefix(path, "extras;"):
		return "extras"
	}
	return "other"
}

// hostCompat diz se uma imagem (ABI) roda bem neste computador.
func hostCompat(abi string) string {
	arch := platform.HostArch()
	switch abi {
	case "x86_64", "x86":
		if arch == "x64" {
			return "ok"
		}
		return "no"
	case "arm64-v8a":
		if arch == "aarch64" {
			return "ok"
		}
		return "slow"
	case "armeabi-v7a":
		if arch == "aarch64" {
			return "slow"
		}
		return "slow"
	}
	return "ok"
}

// apiSortKey transforma "36.1" / "34x" em algo ordenável.
func apiSortKey(api string) float64 {
	clean := strings.TrimRightFunc(api, func(r rune) bool { return r < '0' || r > '9' })
	f, _ := strconv.ParseFloat(clean, 64)
	return f
}

// packageViews junta catálogo e pacotes instalados numa lista só.
func packageViews(s sdk.SDK, cat *sdk.Catalog, preview bool) []PkgView {
	installed := s.InstalledMap()
	var out []PkgView
	seen := map[string]bool{}
	hostOS, hostArch := platform.HostOS(), platform.HostArch()
	if cat != nil {
		for _, r := range cat.Latest(preview) {
			if !preview && isPreviewPkg(r) {
				continue
			}
			v := PkgView{
				Path: r.Path, Name: r.Name, Revision: r.Revision.String(), Type: pkgType(r.Path),
				Channel: r.Channel, License: r.LicenseID, Obsolete: r.Obsolete,
			}
			if a := r.ArchiveFor(hostOS, hostArch); a != nil {
				v.Available = true
				v.Size = a.Size
			}
			if in, ok := installed[r.Path]; ok {
				v.Installed = true
				v.InstalledRv = in.Rev
				v.Update = in.Revision.Compare(r.Revision) < 0
			}
			if v.Type == "sysimg" || v.Type == "platform" {
				d := r.Details
				v.API = d.APILevel
				if v.Type == "sysimg" {
					if parts := strings.Split(r.Path, ";"); len(parts) == 4 {
						v.API = strings.TrimPrefix(parts[1], "android-")
						v.Tag = parts[2]
						v.ABI = parts[3]
					}
					if len(d.Tags) > 0 {
						v.TagDisplay = d.Tags[0].Display
						if len(d.Tags) > 1 && d.Tags[1].ID != "" {
							v.TagDisplay += " · " + d.Tags[1].Display
						}
					}
					v.Vendor = d.VendorDisp
					v.PlayStore = strings.Contains(v.Tag, "playstore")
					v.Compat = hostCompat(v.ABI)
				} else if strings.HasPrefix(r.Path, "platforms;android-") {
					v.API = strings.TrimPrefix(r.Path, "platforms;android-")
				}
				v.Ext = d.ExtLevel
				v.APIName = sdk.APIName(strings.TrimRight(v.API, "x"), d.Codename)
			}
			seen[r.Path] = true
			out = append(out, v)
		}
	}
	// Instalados que o catálogo não conhece (removidos do repositório, manuais...).
	for p, in := range installed {
		if seen[p] {
			continue
		}
		v := PkgView{Path: p, Name: in.Name, Revision: in.Rev, Type: pkgType(p), Installed: true, InstalledRv: in.Rev, Channel: "stable"}
		if v.Type == "sysimg" {
			if parts := strings.Split(p, ";"); len(parts) == 4 {
				v.API = strings.TrimPrefix(parts[1], "android-")
				v.Tag = parts[2]
				v.ABI = parts[3]
				v.TagDisplay = in.Details.TagDisplay()
				v.PlayStore = strings.Contains(v.Tag, "playstore")
				v.Compat = hostCompat(v.ABI)
				v.APIName = sdk.APIName(v.API, "")
			}
		} else if v.Type == "platform" {
			v.API = strings.TrimPrefix(p, "platforms;android-")
			v.APIName = sdk.APIName(v.API, "")
		}
		out = append(out, v)
	}
	sort.SliceStable(out, func(i, j int) bool {
		a, b := out[i], out[j]
		if a.Type != b.Type {
			return a.Type < b.Type
		}
		if ka, kb := apiSortKey(a.API), apiSortKey(b.API); ka != kb {
			return ka > kb
		}
		return a.Path < b.Path
	})
	return out
}

var previewPathRe = regexp.MustCompile(`-(alpha|beta|rc|dev)\d*(;|$)`)

// isPreviewPkg reconhece pacotes de prévia que o Google publica no canal
// estável (codinome de versão futura, betas de plataforma...).
func isPreviewPkg(r *sdk.Remote) bool {
	return r.Details.Codename != "" || previewPathRe.MatchString(r.Path)
}
