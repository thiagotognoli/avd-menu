package server

import (
	"context"
	"fmt"
	"net/http"
	"strings"

	"avdmenu/internal/avd"
	"avdmenu/internal/devices"
	"avdmenu/internal/platform"
	"avdmenu/internal/sdk"
)

func (s *Server) listPackages(w http.ResponseWriter, r *http.Request) (any, error) {
	force := r.URL.Query().Get("refresh") == "1"
	cfg := platform.LoadConfig()
	sd := s.sdk()
	cat, err := s.catalog(r.Context(), force)
	resp := map[string]any{"sdkRoot": sd.Root}
	if err != nil {
		// Sem rede e sem cache: ainda mostra o que está instalado.
		resp["offline"] = true
		resp["error"] = err.Error()
		resp["packages"] = packageViews(sd, nil, cfg.ShowPreview)
		return resp, nil
	}
	resp["offline"] = cat.Offline
	resp["fetched"] = cat.Fetched
	views := packageViews(sd, cat, cfg.ShowPreview)
	if id := r.URL.Query().Get("device"); id != "" {
		if dev, ok := devices.Get(id); ok {
			for i := range views {
				if views[i].Type == "sysimg" {
					ok := dev.TagAllowed(views[i].Tag)
					views[i].Allowed = &ok
				}
			}
		}
	}
	if views == nil {
		views = []PkgView{}
	}
	resp["packages"] = views
	return resp, nil
}

type pkgReq struct {
	Paths  []string `json:"paths"`
	Accept []string `json:"accept"`
	Force  bool     `json:"force"`
}

type planItem struct {
	Path string `json:"path"`
	Name string `json:"name"`
	Rev  string `json:"revision"`
	Size int64  `json:"size"`
}

func (s *Server) plan(ctx context.Context, req pkgReq) (sdk.SDK, *sdk.Catalog, sdk.Plan, error) {
	sd := s.sdk()
	cat, err := s.catalog(ctx, false)
	if err != nil {
		return sd, nil, sdk.Plan{}, errf(http.StatusBadGateway, "sem acesso à lista de pacotes do Google: %v", "cannot reach Google’s package list: %v", err)
	}
	if len(req.Paths) == 0 {
		return sd, cat, sdk.Plan{}, errf(http.StatusBadRequest, "nenhum pacote informado", "no package given")
	}
	plan := sd.PlanInstall(cat, req.Paths, platform.LoadConfig().ShowPreview, req.Force)
	if len(plan.Missing) > 0 {
		return sd, cat, plan, errf(http.StatusBadRequest, "pacote indisponível para este sistema: %s", "package unavailable for this system: %s", strings.Join(plan.Missing, ", "))
	}
	return sd, cat, plan, nil
}

func (s *Server) planPackages(w http.ResponseWriter, r *http.Request) (any, error) {
	var req pkgReq
	if err := decode(r, &req); err != nil {
		return nil, err
	}
	_, _, plan, err := s.plan(r.Context(), req)
	if err != nil {
		return nil, err
	}
	items := make([]planItem, 0, len(plan.Install))
	for _, p := range plan.Install {
		it := planItem{Path: p.Path, Name: p.Name, Rev: p.Revision.String()}
		if a := p.ArchiveFor(platform.HostOS(), platform.HostArch()); a != nil {
			it.Size = a.Size
		}
		items = append(items, it)
	}
	lics := plan.Licenses
	if lics == nil {
		lics = []sdk.License{}
	}
	return map[string]any{"install": items, "licenses": lics, "size": plan.Size}, nil
}

func (s *Server) installPackages(w http.ResponseWriter, r *http.Request) (any, error) {
	var req pkgReq
	if err := decode(r, &req); err != nil {
		return nil, err
	}
	sd, cat, plan, err := s.plan(r.Context(), req)
	if err != nil {
		return nil, err
	}
	if len(plan.Install) == 0 {
		return map[string]any{"nothing": true}, nil
	}
	accepted := map[string]bool{}
	for _, id := range req.Accept {
		accepted[id] = true
	}
	for _, l := range plan.Licenses {
		if !accepted[l.ID] {
			return nil, &httpError{Code: http.StatusConflict, Msg: platform.Tr("é preciso aceitar as licenças", "licenses must be accepted"), Data: plan.Licenses}
		}
	}
	for _, l := range plan.Licenses {
		if err := sd.Accept(l); err != nil {
			return nil, errf(http.StatusInternalServerError, "não foi possível gravar o aceite da licença: %v", "could not record the license acceptance: %v", err)
		}
	}
	var names []string
	for _, p := range plan.Install {
		names = append(names, p.Name)
	}
	title := strings.Join(names, ", ")
	if len(names) > 2 {
		title = fmt.Sprintf("%s +%d", strings.Join(names[:2], ", "), len(names)-2)
	}
	paths := req.Paths
	force := req.Force
	t := s.tasks.Start("install", title, pathsOf(plan.Install, req.Paths), true, func(ctx context.Context, h *tasksHandle) error {
		// Replaneja já com o lock da fila: tarefas anteriores podem ter
		// instalado parte das dependências.
		sd := s.sdk()
		p := sd.PlanInstall(cat, paths, platform.LoadConfig().ShowPreview, force)
		err := sd.Install(ctx, cat, p, func(pr sdk.Progress) {
			h.Progress(pr.Overall, pr.Phase, pr.Name, pr.Done, pr.Total)
		}, h.Logf)
		s.hub.broadcast("refresh", "packages")
		return err
	})
	_ = sd
	return map[string]any{"task": t}, nil
}

func (s *Server) uninstallPackages(w http.ResponseWriter, r *http.Request) (any, error) {
	var req pkgReq
	if err := decode(r, &req); err != nil {
		return nil, err
	}
	if len(req.Paths) == 0 {
		return nil, errf(http.StatusBadRequest, "nenhum pacote informado", "no package given")
	}
	sd := s.sdk()
	have := sd.InstalledMap()
	for _, p := range req.Paths {
		if _, ok := have[p]; !ok {
			return nil, errf(http.StatusBadRequest, "pacote não instalado: %s", "package not installed: %s", p)
		}
	}
	if !req.Force {
		var users []string
		for _, a := range avd.List(sd) {
			for _, p := range req.Paths {
				if a.ImagePkg == p {
					users = append(users, a.DisplayName)
				}
			}
		}
		if len(users) > 0 {
			return nil, &httpError{Code: http.StatusConflict, Msg: platform.Tr("há AVDs usando esta imagem", "AVDs are using this image"), Data: users}
		}
	}
	var names []string
	for _, p := range req.Paths {
		names = append(names, have[p].Name)
	}
	paths := req.Paths
	t := s.tasks.Start("uninstall", strings.Join(names, ", "), req.Paths, true, func(ctx context.Context, h *tasksHandle) error {
		h.Progress(0.3, "remove", strings.Join(names, ", "), 0, 0)
		if err := sd.Uninstall(paths); err != nil {
			return err
		}
		h.Logf("%s", platform.Trf("removido: %s", "removed: %s", strings.Join(paths, ", ")))
		s.hub.broadcast("refresh", "packages")
		return nil
	})
	return map[string]any{"task": t}, nil
}

// pathsOf junta os pacotes pedidos com os do plano (dependências incluídas).
func pathsOf(plan []*sdk.Remote, asked []string) []string {
	seen := map[string]bool{}
	var out []string
	for _, p := range asked {
		if !seen[p] {
			seen[p] = true
			out = append(out, p)
		}
	}
	for _, r := range plan {
		if !seen[r.Path] {
			seen[r.Path] = true
			out = append(out, r.Path)
		}
	}
	return out
}
