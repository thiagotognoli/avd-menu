package server

import (
	"net/http"
	"strings"

	"avdmenu/internal/avd"
	"avdmenu/internal/devices"
	"avdmenu/internal/emu"
	"avdmenu/internal/platform"
	"avdmenu/internal/shortcut"
)

type avdItem struct {
	avd.AVD
	Running   *emu.Instance `json:"running,omitempty"`
	Shortcut  shortcut.Info `json:"shortcut"`
	ExtraArgs string        `json:"extraArgs,omitempty"`
}

func nameParam(r *http.Request) (string, error) {
	n := r.PathValue("name")
	if !avd.ValidName(n) {
		return "", errf(http.StatusBadRequest, "nome de AVD inválido", "invalid AVD name")
	}
	return n, nil
}

func (s *Server) item(a avd.AVD, running map[string]emu.Instance, cfg platform.Config) avdItem {
	it := avdItem{AVD: a, Shortcut: shortcut.Lookup(a.Name), ExtraArgs: cfg.AVDExtraArgs[a.Name]}
	if inst, ok := running[a.Name]; ok {
		it.Running = &inst
	}
	return it
}

func (s *Server) listAVDs(w http.ResponseWriter, r *http.Request) (any, error) {
	sd := s.sdk()
	running := emu.Running()
	cfg := platform.LoadConfig()
	list := avd.List(sd)
	items := make([]avdItem, 0, len(list))
	for _, a := range list {
		items = append(items, s.item(a, running, cfg))
	}
	return map[string]any{"avds": items, "home": avd.Home()}, nil
}

func (s *Server) getAVD(w http.ResponseWriter, r *http.Request) (any, error) {
	name, err := nameParam(r)
	if err != nil {
		return nil, err
	}
	sd := s.sdk()
	a, lerr := avd.Load(sd, name)
	if lerr != nil && a.Dir == "" {
		return nil, errf(http.StatusNotFound, "o AVD %q não existe", "AVD %q does not exist", name)
	}
	cfgIni, _, cerr := avd.Config(name)
	resp := map[string]any{
		"avd":    s.item(a, emu.Running(), platform.LoadConfig()),
		"pinned": shortcut.Pinned(name),
		"log":    emu.ReadLogTail(name, 200),
	}
	if cerr == nil {
		resp["settings"] = avd.ViewOf(cfgIni, name)
		resp["raw"] = string(cfgIni.Bytes())
	}
	return resp, nil
}

func (s *Server) createAVD(w http.ResponseWriter, r *http.Request) (any, error) {
	var req struct {
		avd.CreateSpec
		Shortcut *struct {
			DisplayName string `json:"displayName"`
			IconData    string `json:"iconData"`
			Pin         bool   `json:"pin"`
		} `json:"shortcut"`
	}
	if err := decode(r, &req); err != nil {
		return nil, err
	}
	sd := s.sdk()
	a, err := avd.Create(sd, req.CreateSpec)
	if err != nil {
		return nil, errv(http.StatusBadRequest, err)
	}
	resp := map[string]any{"avd": a}
	if req.Shortcut != nil {
		res, err := shortcut.Create(sd, shortcut.Options{
			AVD: a.Name, DisplayName: req.Shortcut.DisplayName, IconData: req.Shortcut.IconData, Pin: req.Shortcut.Pin,
		})
		if err != nil {
			resp["shortcutError"] = err.Error()
		} else {
			resp["shortcut"] = res
		}
	}
	return resp, nil
}

// previewAVD devolve os valores padrão que um AVD novo teria (formulário da
// última etapa do assistente).
func (s *Server) previewAVD(w http.ResponseWriter, r *http.Request) (any, error) {
	var req struct {
		DeviceID string `json:"deviceId"`
		ImagePkg string `json:"imagePkg"`
	}
	if err := decode(r, &req); err != nil {
		return nil, err
	}
	dev, ok := devices.Get(req.DeviceID)
	if !ok {
		return nil, errf(http.StatusBadRequest, "dispositivo desconhecido", "unknown device")
	}
	img, ok := s.sdk().ReadSysImage(req.ImagePkg)
	if !ok {
		return nil, errf(http.StatusBadRequest, "a imagem de sistema não está instalada", "the system image is not installed")
	}
	cfg, err := avd.BuildConfig(dev, img, avd.CreateSpec{Name: "preview", DeviceID: req.DeviceID, ImagePkg: req.ImagePkg})
	if err != nil {
		return nil, errv(http.StatusBadRequest, err)
	}
	return map[string]any{"settings": avd.ViewOf(cfg, "preview"), "device": dev, "image": img}, nil
}

func (s *Server) updateAVD(w http.ResponseWriter, r *http.Request) (any, error) {
	name, err := nameParam(r)
	if err != nil {
		return nil, err
	}
	var st avd.Settings
	if err := decode(r, &st); err != nil {
		return nil, err
	}
	if _, ok := emu.Running()[name]; ok {
		return nil, errf(http.StatusConflict, "pare o emulador antes de editar o AVD", "stop the emulator before editing the AVD")
	}
	if err := avd.Update(name, st); err != nil {
		return nil, errv(http.StatusBadRequest, err)
	}
	return nil, nil
}

func (s *Server) deleteAVD(w http.ResponseWriter, r *http.Request) (any, error) {
	name, err := nameParam(r)
	if err != nil {
		return nil, err
	}
	if _, ok := emu.Running()[name]; ok {
		return nil, errf(http.StatusConflict, "pare o emulador antes de apagar o AVD", "stop the emulator before deleting the AVD")
	}
	if shortcut.Lookup(name).Exists {
		_ = shortcut.Remove(name)
	}
	if err := avd.Delete(name); err != nil {
		return nil, errv(http.StatusBadRequest, err)
	}
	_, _ = platform.UpdateConfig(func(c *platform.Config) {
		delete(c.AVDExtraArgs, name)
		delete(c.Shortcuts, name)
	})
	return nil, nil
}

func (s *Server) startAVD(w http.ResponseWriter, r *http.Request) (any, error) {
	name, err := nameParam(r)
	if err != nil {
		return nil, err
	}
	var opt emu.StartOptions
	if err := decode(r, &opt); err != nil {
		return nil, err
	}
	sd := s.sdk()
	if _, err := avd.Load(sd, name); err != nil {
		return nil, errf(http.StatusNotFound, "o AVD %q não existe", "AVD %q does not exist", name)
	}
	if extra := platform.LoadConfig().AVDExtraArgs[name]; extra != "" {
		opt.ExtraArgs = append(splitArgs(extra), opt.ExtraArgs...)
	}
	pid, err := emu.Start(sd, name, opt)
	if err != nil {
		return nil, errv(http.StatusBadRequest, err)
	}
	s.hub.broadcast("running", emu.Running())
	return map[string]any{"pid": pid}, nil
}

func (s *Server) stopAVD(w http.ResponseWriter, r *http.Request) (any, error) {
	name, err := nameParam(r)
	if err != nil {
		return nil, err
	}
	if _, ok := emu.Running()[name]; !ok {
		return nil, errf(http.StatusConflict, "o emulador %q não está em execução", "emulator %q is not running", name)
	}
	sd := s.sdk()
	go func() {
		_ = emu.Stop(sd, name)
		s.hub.broadcast("running", emu.Running())
	}()
	return nil, nil
}

func (s *Server) wipeAVD(w http.ResponseWriter, r *http.Request) (any, error) {
	name, err := nameParam(r)
	if err != nil {
		return nil, err
	}
	if _, ok := emu.Running()[name]; ok {
		return nil, errf(http.StatusConflict, "pare o emulador antes de apagar os dados", "stop the emulator before wiping data")
	}
	if err := avd.WipeData(name); err != nil {
		return nil, errv(http.StatusBadRequest, err)
	}
	return nil, nil
}

func (s *Server) duplicateAVD(w http.ResponseWriter, r *http.Request) (any, error) {
	name, err := nameParam(r)
	if err != nil {
		return nil, err
	}
	var req struct {
		Name        string `json:"name"`
		DisplayName string `json:"displayName"`
	}
	if err := decode(r, &req); err != nil {
		return nil, err
	}
	if _, ok := emu.Running()[name]; ok {
		return nil, errf(http.StatusConflict, "pare o emulador antes de duplicar o AVD", "stop the emulator before duplicating the AVD")
	}
	a, err := avd.Duplicate(s.sdk(), name, req.Name, req.DisplayName)
	if err != nil {
		return nil, errv(http.StatusBadRequest, err)
	}
	return map[string]any{"avd": a}, nil
}

func (s *Server) showAVD(w http.ResponseWriter, r *http.Request) (any, error) {
	name, err := nameParam(r)
	if err != nil {
		return nil, err
	}
	a, lerr := avd.Load(s.sdk(), name)
	if lerr != nil && a.Dir == "" {
		return nil, errf(http.StatusNotFound, "o AVD %q não existe", "AVD %q does not exist", name)
	}
	if err := openPath(a.Dir); err != nil {
		return nil, errv(http.StatusBadRequest, err)
	}
	return nil, nil
}

func (s *Server) putRawConfig(w http.ResponseWriter, r *http.Request) (any, error) {
	name, err := nameParam(r)
	if err != nil {
		return nil, err
	}
	var req struct {
		Content string `json:"content"`
	}
	if err := decode(r, &req); err != nil {
		return nil, err
	}
	if _, ok := emu.Running()[name]; ok {
		return nil, errf(http.StatusConflict, "pare o emulador antes de editar o config.ini", "stop the emulator before editing config.ini")
	}
	if err := avd.WriteRawConfig(name, req.Content); err != nil {
		return nil, errv(http.StatusBadRequest, err)
	}
	return nil, nil
}

func (s *Server) putArgs(w http.ResponseWriter, r *http.Request) (any, error) {
	name, err := nameParam(r)
	if err != nil {
		return nil, err
	}
	var req struct {
		Args string `json:"args"`
	}
	if err := decode(r, &req); err != nil {
		return nil, err
	}
	_, err = platform.UpdateConfig(func(c *platform.Config) {
		if c.AVDExtraArgs == nil {
			c.AVDExtraArgs = map[string]string{}
		}
		if strings.TrimSpace(req.Args) == "" {
			delete(c.AVDExtraArgs, name)
		} else {
			c.AVDExtraArgs[name] = strings.TrimSpace(req.Args)
		}
	})
	return nil, err
}

func (s *Server) getLog(w http.ResponseWriter, r *http.Request) (any, error) {
	name, err := nameParam(r)
	if err != nil {
		return nil, err
	}
	return map[string]any{"text": emu.ReadLogTail(name, 400)}, nil
}

func (s *Server) postShortcut(w http.ResponseWriter, r *http.Request) (any, error) {
	name, err := nameParam(r)
	if err != nil {
		return nil, err
	}
	var req struct {
		DisplayName string `json:"displayName"`
		IconData    string `json:"iconData"`
		Pin         bool   `json:"pin"`
	}
	if err := decode(r, &req); err != nil {
		return nil, err
	}
	res, err := shortcut.Create(s.sdk(), shortcut.Options{AVD: name, DisplayName: req.DisplayName, IconData: req.IconData, Pin: req.Pin})
	if err != nil {
		return nil, errv(http.StatusBadRequest, err)
	}
	return res, nil
}

func (s *Server) deleteShortcut(w http.ResponseWriter, r *http.Request) (any, error) {
	name, err := nameParam(r)
	if err != nil {
		return nil, err
	}
	if err := shortcut.Remove(name); err != nil {
		return nil, errv(http.StatusBadRequest, err)
	}
	return nil, nil
}

func (s *Server) postDevice(w http.ResponseWriter, r *http.Request) (any, error) {
	var d devices.Device
	if err := decode(r, &d); err != nil {
		return nil, err
	}
	saved, err := devices.SaveUser(d)
	if err != nil {
		return nil, errv(http.StatusBadRequest, err)
	}
	return map[string]any{"device": saved}, nil
}

// splitArgs divide uma linha de argumentos respeitando aspas simples/duplas.
func splitArgs(s string) []string {
	var out []string
	var cur strings.Builder
	var quote rune
	has := false
	for _, r := range s {
		switch {
		case quote != 0:
			if r == quote {
				quote = 0
			} else {
				cur.WriteRune(r)
			}
		case r == '"' || r == '\'':
			quote = r
			has = true
		case r == ' ' || r == '\t' || r == '\n':
			if has || cur.Len() > 0 {
				out = append(out, cur.String())
				cur.Reset()
				has = false
			}
		default:
			cur.WriteRune(r)
		}
	}
	if has || cur.Len() > 0 {
		out = append(out, cur.String())
	}
	return out
}
