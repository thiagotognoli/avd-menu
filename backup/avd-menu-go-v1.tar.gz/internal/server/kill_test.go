package server

import (
	"os/exec"
	"strings"
)

// exec_kill encerra processos de teste que tenham "-avd <nome>" na linha de comando.
func exec_kill(name string) error {
	out, err := exec.Command("ps", "-axww", "-o", "pid=,args=").Output()
	if err != nil {
		return err
	}
	for _, l := range strings.Split(string(out), "\n") {
		if strings.Contains(l, "-avd "+name) {
			f := strings.Fields(l)
			if len(f) > 0 {
				_ = exec.Command("kill", f[0]).Run()
			}
		}
	}
	return nil
}
