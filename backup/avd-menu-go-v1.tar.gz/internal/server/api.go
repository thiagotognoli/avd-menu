package server

import (
	"context"
	"net/http"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"time"

	"avdmenu/internal/avd"
	"avdmenu/internal/devices"
	"avdmenu/internal/emu"
	"avdmenu/internal/launcher"
	"avdmenu/internal/platform"
	"avdmenu/internal/sdk"
	"avdmenu/internal/shortcut"
)

func (s *Server) apiRoutes(mux *http.ServeMux) {
	h := func(pattern string, fn handler) { mux.HandleFunc(pattern, wrap(fn)) }

	h("GET /api/ping", func(w http.ResponseWriter, r *http.Request) (any, error) {
		return map[string]any{"ok": true, "version": platform.Version}, nil
	})
	h("GET /api/state", s.getState)
	h("POST /api/settings", s.postSettings)
	h("POST /api/sdk/setup", s.postSDKSetup)
	h("GET /api/fs", s.getFS)
	h("GET /api/diag", func(w http.ResponseWriter, r *http.Request) (any, error) {
		return map[string]any{"checks": emu.Diagnose(s.sdk())}, nil
	})
	h("POST /api/lang", func(w http.ResponseWriter, r *http.Request) (any, error) {
		var req struct {
			Lang string `json:"lang"`
		}
		if err := decode(r, &req); err != nil {
			return nil, err
		}
		platform.SetRuntimeLang(req.Lang)
		return nil, nil
	})
	h("POST /api/shutdown", func(w http.ResponseWriter, r *http.Request) (any, error) {
		go func() { time.Sleep(200 * time.Millisecond); s.cancel() }()
		return nil, nil
	})
	h("POST /api/self/install", func(w http.ResponseWriter, r *http.Request) (any, error) {
		res, err := shortcut.InstallSelf()
		if err != nil {
			return nil, errv(http.StatusBadRequest, err)
		}
		return res, nil
	})
	h("POST /api/self/uninstall", func(w http.ResponseWriter, r *http.Request) (any, error) {
		if err := shortcut.UninstallSelf(); err != nil {
			return nil, errv(http.StatusBadRequest, err)
		}
		return nil, nil
	})

	// AVDs
	h("GET /api/avds", s.listAVDs)
	h("POST /api/avds", s.createAVD)
	h("POST /api/avds/preview", s.previewAVD)
	h("GET /api/avds/{name}", s.getAVD)
	h("PUT /api/avds/{name}", s.updateAVD)
	h("DELETE /api/avds/{name}", s.deleteAVD)
	h("POST /api/avds/{name}/start", s.startAVD)
	h("POST /api/avds/{name}/stop", s.stopAVD)
	h("POST /api/avds/{name}/wipe", s.wipeAVD)
	h("POST /api/avds/{name}/duplicate", s.duplicateAVD)
	h("POST /api/avds/{name}/show", s.showAVD)
	h("PUT /api/avds/{name}/raw", s.putRawConfig)
	h("PUT /api/avds/{name}/args", s.putArgs)
	h("GET /api/avds/{name}/log", s.getLog)
	h("POST /api/avds/{name}/shortcut", s.postShortcut)
	h("DELETE /api/avds/{name}/shortcut", s.deleteShortcut)

	// Dispositivos (perfis de hardware)
	h("GET /api/devices", func(w http.ResponseWriter, r *http.Request) (any, error) {
		return map[string]any{"devices": devices.All()}, nil
	})
	h("POST /api/devices", s.postDevice)
	h("DELETE /api/devices/{id}", func(w http.ResponseWriter, r *http.Request) (any, error) {
		if err := devices.DeleteUser(r.PathValue("id")); err != nil {
			return nil, err
		}
		return nil, nil
	})

	// SDK
	h("GET /api/packages", s.listPackages)
	h("POST /api/packages/plan", s.planPackages)
	h("POST /api/packages/install", s.installPackages)
	h("POST /api/packages/uninstall", s.uninstallPackages)

	// Tarefas
	h("GET /api/tasks", func(w http.ResponseWriter, r *http.Request) (any, error) {
		return map[string]any{"tasks": s.tasks.List()}, nil
	})
	h("POST /api/tasks/{id}/cancel", func(w http.ResponseWriter, r *http.Request) (any, error) {
		if !s.tasks.Cancel(r.PathValue("id")) {
			return nil, errf(http.StatusNotFound, "tarefa não encontrada", "task not found")
		}
		return nil, nil
	})
	h("POST /api/tasks/clear", func(w http.ResponseWriter, r *http.Request) (any, error) {
		s.tasks.Clear()
		return nil, nil
	})
}

// ---- estado e configurações -------------------------------------------------------

func (s *Server) getState(w http.ResponseWriter, r *http.Request) (any, error) {
	cfg := platform.LoadConfig()
	sd := s.sdk()
	self := shortcut.SelfInfo()
	gpus := emu.ListGPUs()
	return map[string]any{
		"version":  platform.Version,
		"os":       runtime.GOOS,
		"arch":     runtime.GOARCH,
		"hostArch": platform.HostArch(),
		"sdk": map[string]any{
			"root":        sd.Root,
			"exists":      sd.Exists(),
			"hasEmulator": sd.HasEmulator(),
			"hasAdb":      sd.HasAdb(),
			"configured":  cfg.SDKRoot != "",
			"defaultRoot": sdk.DefaultRoot(),
		},
		"candidates": sdk.Candidates(cfg.SDKRoot),
		"config": map[string]any{
			"showPreview": cfg.ShowPreview,
			"lang":        cfg.Lang,
			"theme":       cfg.Theme,
		},
		"avdHome":        avd.Home(),
		"shortcuts":      shortcut.Supported(),
		"self":           self,
		"canInstallSelf": runtime.GOOS == "linux",
		"dgpu":           len(emu.DedicatedGPUEnv()) > 0,
		"gpus":           gpus,
		"exe":            platform.Exe(),
		"appImage":       os.Getenv("APPIMAGE") != "",
	}, nil
}

func (s *Server) postSettings(w http.ResponseWriter, r *http.Request) (any, error) {
	var req struct {
		ShowPreview *bool   `json:"showPreview"`
		Lang        *string `json:"lang"`
		Theme       *string `json:"theme"`
	}
	if err := decode(r, &req); err != nil {
		return nil, err
	}
	_, err := platform.UpdateConfig(func(c *platform.Config) {
		if req.ShowPreview != nil {
			c.ShowPreview = *req.ShowPreview
		}
		if req.Lang != nil {
			c.Lang = *req.Lang
		}
		if req.Theme != nil {
			c.Theme = *req.Theme
		}
	})
	if err != nil {
		return nil, err
	}
	if req.ShowPreview != nil {
		s.catMu.Lock()
		s.cat = nil
		s.catMu.Unlock()
	}
	return nil, nil
}

func (s *Server) postSDKSetup(w http.ResponseWriter, r *http.Request) (any, error) {
	var req struct {
		Root   string `json:"root"`
		Create bool   `json:"create"`
	}
	if err := decode(r, &req); err != nil {
		return nil, err
	}
	root := strings.TrimSpace(req.Root)
	if strings.HasPrefix(root, "~") {
		root = filepath.Join(platform.Home(), strings.TrimPrefix(root, "~"))
	}
	if root != "" && !filepath.IsAbs(root) {
		return nil, errf(http.StatusBadRequest, "informe um caminho absoluto", "enter an absolute path")
	}
	if root != "" {
		root = filepath.Clean(root)
		if !platform.DirExists(root) {
			if !req.Create {
				return nil, errf(http.StatusBadRequest, "a pasta %s não existe", "the folder %s does not exist", root)
			}
			if err := os.MkdirAll(root, 0o755); err != nil {
				return nil, errf(http.StatusBadRequest, "não foi possível criar %s: %v", "could not create %s: %v", root, err)
			}
		}
	}
	if _, err := platform.UpdateConfig(func(c *platform.Config) { c.SDKRoot = root }); err != nil {
		return nil, err
	}
	s.catMu.Lock()
	s.cat = nil
	s.catMu.Unlock()
	return s.getState(w, r)
}

// getFS lista subpastas para o seletor de pasta da interface.
func (s *Server) getFS(w http.ResponseWriter, r *http.Request) (any, error) {
	p := r.URL.Query().Get("path")
	if p == "" {
		p = platform.Home()
	}
	if strings.HasPrefix(p, "~") {
		p = filepath.Join(platform.Home(), strings.TrimPrefix(p, "~"))
	}
	p = filepath.Clean(p)
	entries, err := os.ReadDir(p)
	if err != nil {
		// caminho digitado pela metade: lista o pai
		parent := filepath.Dir(p)
		entries, err = os.ReadDir(parent)
		if err != nil {
			return nil, errf(http.StatusBadRequest, "não foi possível abrir %s", "could not open %s", p)
		}
		p = parent
	}
	dirs := []string{}
	for _, e := range entries {
		if e.IsDir() && !strings.HasPrefix(e.Name(), ".") {
			dirs = append(dirs, e.Name())
		}
	}
	sort.Strings(dirs)
	return map[string]any{
		"path":   p,
		"parent": filepath.Dir(p),
		"dirs":   dirs,
		"isSdk":  sdk.SDK{Root: p}.HasEmulator() || sdk.SDK{Root: p}.HasAdb() || platform.DirExists(filepath.Join(p, "licenses")),
	}, nil
}

// ---- catálogo -----------------------------------------------------------------------

func (s *Server) catalog(ctx context.Context, force bool) (*sdk.Catalog, error) {
	s.catMu.Lock()
	defer s.catMu.Unlock()
	if !force && s.cat != nil && time.Since(s.catAt) < 15*time.Minute {
		return s.cat, nil
	}
	cat, err := sdk.FetchCatalog(ctx, force)
	if err != nil {
		if s.cat != nil {
			return s.cat, nil
		}
		return nil, err
	}
	s.cat, s.catAt = cat, time.Now()
	return cat, nil
}

// openPath abre uma pasta no gerenciador de arquivos.
func openPath(p string) error { return launcher.OpenPath(p) }
