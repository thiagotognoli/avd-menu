// Package server expõe a interface web local do AVD Menu: uma API JSON +
// os arquivos estáticos da interface, ouvindo só em 127.0.0.1.
package server

import (
	"context"
	"crypto/rand"
	"crypto/subtle"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/signal"
	"path/filepath"
	"reflect"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"

	"avdmenu/internal/emu"
	"avdmenu/internal/platform"
	"avdmenu/internal/sdk"
	"avdmenu/internal/tasks"
	"avdmenu/ui"
)

// Options configura o servidor.
type Options struct {
	Port      int  // 0 = porta aleatória
	KeepAlive bool // não encerra quando a janela fecha
	NewWindow bool // sempre inicia uma instância nova
	Open      func(url string) (string, error)
	Logf      func(format string, a ...any)
}

// Server é a instância em execução.
type Server struct {
	opts  Options
	token string
	port  int
	tasks *tasks.Manager
	hub   *hub

	catMu   sync.Mutex
	cat     *sdk.Catalog
	catAt   time.Time
	catPrev bool

	started time.Time
	cancel  context.CancelFunc
}

// instanceFile guarda pid/porta/token para reaproveitar a instância aberta.
type instanceInfo struct {
	PID   int    `json:"pid"`
	Port  int    `json:"port"`
	Token string `json:"token"`
}

func instancePath() string { return filepath.Join(platform.StateDir(), "server.json") }

func randomHex(n int) string {
	b := make([]byte, n)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}

func (s *Server) logf(format string, a ...any) {
	if s.opts.Logf != nil {
		s.opts.Logf(format, a...)
	}
}

func newServer(o Options, cancel context.CancelFunc) *Server {
	s := &Server{opts: o, token: randomHex(16), started: time.Now(), cancel: cancel}
	s.hub = newHub()
	s.tasks = tasks.New(func(t tasks.Task) { s.hub.broadcast("task", t) })
	return s
}

// existing tenta falar com uma instância já em execução.
func existing() (instanceInfo, bool) {
	b, err := os.ReadFile(instancePath())
	if err != nil {
		return instanceInfo{}, false
	}
	var in instanceInfo
	if json.Unmarshal(b, &in) != nil || in.Port == 0 {
		return in, false
	}
	c := &http.Client{Timeout: 1500 * time.Millisecond}
	req, _ := http.NewRequest("GET", fmt.Sprintf("http://127.0.0.1:%d/api/ping", in.Port), nil)
	req.AddCookie(&http.Cookie{Name: cookieName(in.Port), Value: in.Token})
	resp, err := c.Do(req)
	if err != nil {
		return in, false
	}
	defer resp.Body.Close()
	return in, resp.StatusCode == http.StatusOK
}

func cookieName(port int) string { return "avdm_" + strconv.Itoa(port) }

// Run inicia o servidor e bloqueia até ele encerrar.
func Run(o Options) error {
	if !o.NewWindow {
		if in, ok := existing(); ok {
			u := fmt.Sprintf("http://127.0.0.1:%d/?t=%s", in.Port, in.Token)
			if o.Open != nil {
				if _, err := o.Open(u); err != nil {
					return err
				}
			}
			return nil
		}
	}
	ln, err := net.Listen("tcp", fmt.Sprintf("127.0.0.1:%d", o.Port))
	if err != nil {
		return err
	}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	s := newServer(o, cancel)
	s.port = ln.Addr().(*net.TCPAddr).Port

	mux := s.routes()
	srv := &http.Server{Handler: s.guard(mux), ReadHeaderTimeout: 10 * time.Second}

	_ = os.MkdirAll(platform.StateDir(), 0o755)
	info, _ := json.Marshal(instanceInfo{PID: os.Getpid(), Port: s.port, Token: s.token})
	_ = os.WriteFile(instancePath(), info, 0o600)
	defer func() {
		// só remove o arquivo se ainda for o nosso
		if b, err := os.ReadFile(instancePath()); err == nil {
			var in instanceInfo
			if json.Unmarshal(b, &in) == nil && in.PID == os.Getpid() {
				_ = os.Remove(instancePath())
			}
		}
	}()

	go s.pollRunning(ctx)
	if !o.KeepAlive {
		go s.idleWatch(ctx)
	}

	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		select {
		case <-sig:
		case <-ctx.Done():
		}
		sc, c := context.WithTimeout(context.Background(), 3*time.Second)
		defer c()
		_ = srv.Shutdown(sc)
	}()

	u := fmt.Sprintf("http://127.0.0.1:%d/?t=%s", s.port, s.token)
	s.logf("AVD Menu %s — %s", platform.Version, u)
	if o.Open != nil {
		go func() {
			how, err := o.Open(u)
			if err != nil {
				s.logf("%s: %v", platform.Tr("aviso", "warning"), err)
			} else {
				s.logf("%s: %s", platform.Tr("janela", "window"), how)
			}
		}()
	}
	if err := srv.Serve(ln); err != nil && !errors.Is(err, http.ErrServerClosed) {
		return err
	}
	return nil
}

// sdk devolve o SDK atualmente configurado/detectado.
func (s *Server) sdk() sdk.SDK { return sdk.Detect(platform.LoadConfig().SDKRoot) }

// ---- segurança --------------------------------------------------------------------

func (s *Server) hostOK(h string) bool {
	h = strings.ToLower(h)
	p := strconv.Itoa(s.port)
	return h == "127.0.0.1:"+p || h == "localhost:"+p
}

func (s *Server) authed(r *http.Request) bool {
	c, err := r.Cookie(cookieName(s.port))
	if err != nil {
		return false
	}
	return subtle.ConstantTimeCompare([]byte(c.Value), []byte(s.token)) == 1
}

// guard barra acessos de outros sites (DNS rebinding / CSRF): só aceita o Host
// do próprio servidor e exige o cookie de sessão, que só o navegador aberto por
// nós recebe (via ?t=).
func (s *Server) guard(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !s.hostOK(r.Host) {
			http.Error(w, platform.Tr("host inválido", "invalid host"), http.StatusForbidden)
			return
		}
		if t := r.URL.Query().Get("t"); t != "" && r.Method == http.MethodGet && !strings.HasPrefix(r.URL.Path, "/api/") {
			if subtle.ConstantTimeCompare([]byte(t), []byte(s.token)) == 1 {
				http.SetCookie(w, &http.Cookie{Name: cookieName(s.port), Value: s.token, Path: "/", HttpOnly: true, SameSite: http.SameSiteStrictMode})
				http.Redirect(w, r, "/", http.StatusFound)
				return
			}
		}
		if !s.authed(r) {
			http.Error(w, platform.Tr("não autorizado — abra o AVD Menu pelo aplicativo", "unauthorized — open AVD Menu through the app"), http.StatusUnauthorized)
			return
		}
		if origin := r.Header.Get("Origin"); origin != "" {
			if u, err := url.Parse(origin); err != nil || !s.hostOK(u.Host) {
				http.Error(w, platform.Tr("origem inválida", "invalid origin"), http.StatusForbidden)
				return
			}
		}
		next.ServeHTTP(w, r)
	})
}

// ---- encerramento por inatividade --------------------------------------------------

func (s *Server) idleWatch(ctx context.Context) {
	t := time.NewTicker(3 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			if time.Since(s.started) < 90*time.Second {
				continue // dá tempo do navegador abrir
			}
			n, last := s.hub.stats()
			if n == 0 && time.Since(last) > 20*time.Second && !s.tasks.Active() {
				s.logf("%s", platform.Tr("nenhuma janela aberta — encerrando", "no window open — shutting down"))
				s.cancel()
				return
			}
		}
	}
}

// pollRunning avisa a interface quando emuladores sobem ou descem.
func (s *Server) pollRunning(ctx context.Context) {
	var prev map[string]emu.Instance
	t := time.NewTicker(2 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			if n, _ := s.hub.stats(); n == 0 {
				continue
			}
			cur := emu.Running()
			if prev == nil || !reflect.DeepEqual(prev, cur) {
				prev = cur
				s.hub.broadcast("running", cur)
			}
		}
	}
}

// ---- SSE ----------------------------------------------------------------------------

type hub struct {
	mu       sync.Mutex
	clients  map[chan []byte]struct{}
	lastGone time.Time
}

func newHub() *hub { return &hub{clients: map[chan []byte]struct{}{}, lastGone: time.Now()} }

func (h *hub) stats() (int, time.Time) {
	h.mu.Lock()
	defer h.mu.Unlock()
	return len(h.clients), h.lastGone
}

func (h *hub) broadcast(event string, data any) {
	b, err := json.Marshal(data)
	if err != nil {
		return
	}
	msg := []byte("event: " + event + "\ndata: " + string(b) + "\n\n")
	h.mu.Lock()
	defer h.mu.Unlock()
	for c := range h.clients {
		select {
		case c <- msg:
		default: // cliente lento: descarta (a interface ressincroniza sozinha)
		}
	}
}

func (s *Server) handleEvents(w http.ResponseWriter, r *http.Request) {
	fl, ok := w.(http.Flusher)
	if !ok {
		http.Error(w, "streaming unsupported", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	w.Header().Set("Connection", "keep-alive")
	ch := make(chan []byte, 64)
	s.hub.mu.Lock()
	s.hub.clients[ch] = struct{}{}
	s.hub.mu.Unlock()
	defer func() {
		s.hub.mu.Lock()
		delete(s.hub.clients, ch)
		s.hub.lastGone = time.Now()
		s.hub.mu.Unlock()
	}()
	fmt.Fprint(w, "retry: 2000\n\n")
	fl.Flush()
	// estado inicial
	if b, err := json.Marshal(emu.Running()); err == nil {
		fmt.Fprintf(w, "event: running\ndata: %s\n\n", b)
	}
	for _, t := range s.tasks.List() {
		if b, err := json.Marshal(t); err == nil {
			fmt.Fprintf(w, "event: task\ndata: %s\n\n", b)
		}
	}
	fl.Flush()
	ping := time.NewTicker(10 * time.Second)
	defer ping.Stop()
	for {
		select {
		case <-r.Context().Done():
			return
		case msg := <-ch:
			if _, err := w.Write(msg); err != nil {
				return
			}
			fl.Flush()
		case <-ping.C:
			if _, err := io.WriteString(w, ": ping\n\n"); err != nil {
				return
			}
			fl.Flush()
		}
	}
}

// ---- JSON helpers ---------------------------------------------------------------------

type httpError struct {
	Code int
	Msg  string
	Data any
}

func (e *httpError) Error() string { return e.Msg }

// errf cria um erro HTTP com a mensagem no idioma atual da interface.
func errf(code int, pt, en string, a ...any) error {
	return &httpError{Code: code, Msg: platform.Trf(pt, en, a...)}
}

// errv converte um erro qualquer (já localizado na origem) em erro HTTP.
func errv(code int, err error) error { return &httpError{Code: code, Msg: err.Error()} }

type handler func(w http.ResponseWriter, r *http.Request) (any, error)

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func wrap(h handler) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		v, err := h(w, r)
		if err != nil {
			var he *httpError
			if errors.As(err, &he) {
				body := map[string]any{"error": he.Msg}
				if he.Data != nil {
					body["data"] = he.Data
				}
				writeJSON(w, he.Code, body)
				return
			}
			writeJSON(w, http.StatusInternalServerError, map[string]any{"error": err.Error()})
			return
		}
		if v == nil {
			v = map[string]bool{"ok": true}
		}
		writeJSON(w, http.StatusOK, v)
	}
}

func decode(r *http.Request, v any) error {
	r.Body = http.MaxBytesReader(nil, r.Body, 16<<20)
	dec := json.NewDecoder(r.Body)
	if err := dec.Decode(v); err != nil && !errors.Is(err, io.EOF) {
		return errf(http.StatusBadRequest, "JSON inválido: %v", "invalid JSON: %v", err)
	}
	return nil
}

// ---- rotas ------------------------------------------------------------------------------

func (s *Server) routes() http.Handler {
	mux := http.NewServeMux()
	sub, _ := fs.Sub(ui.Files, ".")
	static := http.FileServer(http.FS(sub))
	mux.Handle("GET /", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Cache-Control", "no-cache")
		w.Header().Set("Content-Security-Policy", "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Referrer-Policy", "no-referrer")
		static.ServeHTTP(w, r)
	}))
	mux.HandleFunc("GET /api/events", s.handleEvents)
	s.apiRoutes(mux)
	return mux
}

// tasksHandle é o identificador curto usado pelos handlers.
type tasksHandle = tasks.Handle
