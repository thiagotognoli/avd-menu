// Package assets embute os ícones do aplicativo.
package assets

import _ "embed"

// IconSVG é o ícone padrão (Android) usado no aplicativo e nos atalhos.
//
//go:embed android-icon.svg
var IconSVG []byte

// IconPNG é o mesmo ícone rasterizado em 1024x1024 (para .icns e AppImage).
//
//go:embed icon-1024.png
var IconPNG []byte
