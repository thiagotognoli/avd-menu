// Package sdk implementa o que o sdkmanager do Android faz: localizar o SDK,
// ler os manifestos de pacotes do Google, baixar/instalar/remover pacotes e
// gerenciar as licenças — tudo sem precisar de Java.
package sdk

import (
	"os"
	"path/filepath"
	"runtime"
	"strings"

	"avdmenu/internal/platform"
)

// SDK é uma instalação do Android SDK.
type SDK struct {
	Root string
}

// Candidate descreve um local possível de SDK.
type Candidate struct {
	Path     string `json:"path"`
	Source   string `json:"source"`
	Exists   bool   `json:"exists"`
	Emulator bool   `json:"emulator"`
	Adb      bool   `json:"adb"`
}

// DefaultRoot é o local padrão para criar um SDK novo (o mesmo do Android Studio).
func DefaultRoot() string {
	if platform.IsMac() {
		return filepath.Join(platform.Home(), "Library", "Android", "sdk")
	}
	return filepath.Join(platform.Home(), "Android", "Sdk")
}

func exeName(name string) string {
	if runtime.GOOS == "windows" {
		return name + ".exe"
	}
	return name
}

// Emulator devolve o caminho do binário do emulador (existente ou não).
func (s SDK) Emulator() string { return filepath.Join(s.Root, "emulator", exeName("emulator")) }

// Adb devolve o caminho do adb.
func (s SDK) Adb() string { return filepath.Join(s.Root, "platform-tools", exeName("adb")) }

// HasEmulator informa se o emulador está instalado.
func (s SDK) HasEmulator() bool { return platform.IsExecutable(s.Emulator()) }

// HasAdb informa se o adb está instalado.
func (s SDK) HasAdb() bool { return platform.IsExecutable(s.Adb()) }

// Exists informa se o diretório raiz existe.
func (s SDK) Exists() bool { return s.Root != "" && platform.DirExists(s.Root) }

// PackageDir converte um path de pacote ("system-images;android-36;x;y") no
// diretório onde ele é instalado.
func (s SDK) PackageDir(pkgPath string) string {
	return filepath.Join(s.Root, filepath.FromSlash(strings.ReplaceAll(pkgPath, ";", "/")))
}

// Candidates lista os locais onde um SDK pode estar, na ordem de preferência.
func Candidates(configured string) []Candidate {
	home := platform.Home()
	type c struct{ path, src string }
	list := []c{
		{configured, "config"},
		{os.Getenv("ANDROID_SDK_ROOT"), "ANDROID_SDK_ROOT"},
		{os.Getenv("ANDROID_HOME"), "ANDROID_HOME"},
	}
	// Binários no PATH apontam para a raiz do SDK.
	if p := platform.Which("emulator"); p != "" {
		if r, err := filepath.EvalSymlinks(p); err == nil {
			p = r
		}
		list = append(list, c{filepath.Dir(filepath.Dir(p)), "emulator no PATH"})
	}
	if p := platform.Which("adb"); p != "" {
		if r, err := filepath.EvalSymlinks(p); err == nil {
			p = r
		}
		list = append(list, c{filepath.Dir(filepath.Dir(p)), "adb on PATH"})
	}
	list = append(list,
		c{filepath.Join(home, "Android", "Sdk"), "Android Studio default"},
		c{filepath.Join(home, "Library", "Android", "sdk"), "Android Studio default (macOS)"},
		c{filepath.Join(home, "Applications", "Android", "Sdk"), "known location"},
		c{filepath.Join(home, "Applications", "android-sdk"), "known location"},
		c{filepath.Join(home, ".local", "share", "Android", "Sdk"), "known location"},
		c{filepath.Join(home, "android-sdk"), "known location"},
		c{filepath.Join(home, "Android", "sdk"), "known location"},
		c{"/opt/android-sdk", "known location"},
		c{"/usr/lib/android-sdk", "known location"},
		c{"/usr/local/share/android-sdk", "known location"},
		c{"/opt/homebrew/share/android-commandlinetools", "Homebrew"},
		c{"/usr/local/share/android-commandlinetools", "Homebrew"},
	)
	seen := map[string]bool{}
	var out []Candidate
	for _, it := range list {
		if it.path == "" {
			continue
		}
		p := filepath.Clean(it.path)
		if seen[p] {
			continue
		}
		seen[p] = true
		sd := SDK{Root: p}
		cand := Candidate{Path: p, Source: it.src, Exists: sd.Exists(), Emulator: sd.HasEmulator(), Adb: sd.HasAdb()}
		// Só interessam locais que existem ou foram pedidos explicitamente.
		if cand.Exists || it.src == "config" {
			out = append(out, cand)
		}
	}
	return out
}

// Detect escolhe o SDK a usar: o configurado; senão o primeiro com emulador;
// senão o primeiro que exista; senão o padrão (ainda não criado).
func Detect(configured string) SDK {
	if configured != "" {
		return SDK{Root: filepath.Clean(configured)}
	}
	cands := Candidates("")
	for _, c := range cands {
		if c.Emulator {
			return SDK{Root: c.Path}
		}
	}
	for _, c := range cands {
		if c.Exists && (c.Adb || looksLikeSDK(c.Path)) {
			return SDK{Root: c.Path}
		}
	}
	return SDK{Root: DefaultRoot()}
}

func looksLikeSDK(root string) bool {
	for _, d := range []string{"platforms", "platform-tools", "system-images", "cmdline-tools", "build-tools", "licenses"} {
		if platform.DirExists(filepath.Join(root, d)) {
			return true
		}
	}
	return false
}
