package sdk

import "time"

var timeZero = time.Time{}
