package sdk

import (
	"archive/zip"
	"bytes"
	"context"
	"crypto/sha1"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"syscall"
	"time"

	"avdmenu/internal/platform"
)

// Progress descreve o andamento de uma instalação.
type Progress struct {
	Phase   string  // "download", "verify", "extract", "finalize"
	Package string  // path do pacote em andamento
	Name    string  // nome legível
	Done    int64   // bytes concluídos na fase atual
	Total   int64   // bytes totais da fase atual
	Overall float64 // 0..1 do plano inteiro
	Index   int     // pacote atual (1-based)
	Count   int     // total de pacotes do plano
}

// Plan é o resultado de resolver o que precisa ser instalado.
type Plan struct {
	Install  []*Remote
	Licenses []License // licenças ainda não aceitas exigidas pelo plano
	Size     int64     // bytes a baixar
	Missing  []string  // pacotes pedidos que não existem / não servem para este host
}

// PlanInstall resolve dependências (emulador para imagens de sistema, etc.) e
// informa quais licenças faltam ser aceitas. Pacotes já instalados na mesma
// revisão (ou mais nova) são ignorados, a menos que force seja verdadeiro.
func (s SDK) PlanInstall(cat *Catalog, paths []string, preview, force bool) Plan {
	var plan Plan
	have := s.InstalledMap()
	added := map[string]bool{}
	var add func(path string, min *Revision, requested bool)
	add = func(path string, min *Revision, requested bool) {
		if added[path] {
			return
		}
		r := cat.Find(path, preview)
		if r == nil || r.ArchiveFor(platform.HostOS(), platform.HostArch()) == nil {
			if requested {
				plan.Missing = append(plan.Missing, path)
			}
			return
		}
		cur, installed := have[path]
		needed := force && requested
		if !installed {
			needed = true
		} else if min != nil && cur.Revision.Compare(*min) < 0 {
			needed = true
		} else if requested && cur.Revision.Compare(r.Revision) < 0 {
			needed = true
		}
		if !needed {
			return
		}
		added[path] = true
		for _, d := range r.Deps {
			dm := d.Min
			add(d.Path, &dm, false)
		}
		plan.Install = append(plan.Install, r)
	}
	for _, p := range paths {
		add(p, nil, true)
	}
	// Quem instala imagens ou o emulador quase sempre quer o adb junto.
	for _, r := range append([]*Remote(nil), plan.Install...) {
		if strings.HasPrefix(r.Path, "system-images;") || r.Path == "emulator" {
			add("platform-tools", nil, false)
			break
		}
	}
	seen := map[string]bool{}
	for _, r := range plan.Install {
		if a := r.ArchiveFor(platform.HostOS(), platform.HostArch()); a != nil {
			plan.Size += a.Size
		}
		if seen[r.LicenseID] || r.LicenseID == "" {
			continue
		}
		seen[r.LicenseID] = true
		if l, ok := cat.Licenses[r.LicenseID]; ok && !s.Accepted(l) {
			plan.Licenses = append(plan.Licenses, l)
		}
	}
	sort.Slice(plan.Licenses, func(i, j int) bool { return plan.Licenses[i].ID < plan.Licenses[j].ID })
	return plan
}

// Install baixa e instala os pacotes do plano. As licenças precisam ter sido
// aceitas antes (ver Accept).
func (s SDK) Install(ctx context.Context, cat *Catalog, plan Plan, on func(Progress), logf func(string, ...any)) error {
	if logf == nil {
		logf = func(string, ...any) {}
	}
	if on == nil {
		on = func(Progress) {}
	}
	for _, r := range plan.Install {
		if l, ok := cat.Licenses[r.LicenseID]; ok && !s.Accepted(l) {
			return platform.Errorf("a licença %q ainda não foi aceita", "license %q has not been accepted yet", r.LicenseID)
		}
	}
	if err := os.MkdirAll(s.Root, 0o755); err != nil {
		return platform.Errorf("não foi possível criar %s: %w", "could not create %s: %w", s.Root, err)
	}
	if free, err := freeSpace(s.Root); err == nil {
		// Precisa do zip + o conteúdo extraído (~ 2x); usamos 2,2x como folga.
		if need := uint64(float64(plan.Size) * 2.2); free < need {
			return platform.Errorf("espaço insuficiente em %s: livre %s, necessário cerca de %s",
				"not enough space in %s: %s free, about %s needed",
				s.Root, HumanBytes(int64(free)), HumanBytes(int64(need)))
		}
	}
	var totalWork float64
	for _, r := range plan.Install {
		if a := r.ArchiveFor(platform.HostOS(), platform.HostArch()); a != nil {
			totalWork += float64(a.Size) + 1
		}
	}
	var doneWork float64
	for i, r := range plan.Install {
		a := r.ArchiveFor(platform.HostOS(), platform.HostArch())
		if a == nil {
			return platform.Errorf("%s não está disponível para este sistema", "%s is not available for this system", r.Path)
		}
		weight := float64(a.Size) + 1
		report := func(phase string, done, total int64, frac float64) {
			on(Progress{
				Phase: phase, Package: r.Path, Name: r.Name, Done: done, Total: total,
				Overall: (doneWork + weight*frac) / totalWork, Index: i + 1, Count: len(plan.Install),
			})
		}
		logf("→ %s (%s, %s)", r.Name, r.Path, platform.Trf("revisão %s", "revision %s", r.Revision))

		dlDir := filepath.Join(s.Root, ".downloadIntermediates")
		if err := os.MkdirAll(dlDir, 0o755); err != nil {
			return err
		}
		zipPath := filepath.Join(dlDir, strings.ReplaceAll(r.Path, ";", "_")+"_"+filepath.Base(a.URL))
		err := downloadFile(ctx, r.AbsURL(a), zipPath, a.Size, func(done, total int64) {
			if total <= 0 {
				total = a.Size
			}
			report("download", done, total, 0.9*float64(done)/float64(max64(total, 1)))
		})
		if err != nil {
			return platform.Errorf("download de %s: %w", "download of %s: %w", r.Path, err)
		}
		report("verify", 0, a.Size, 0.9)
		if a.SHA1 != "" {
			if err := verifySHA1(zipPath, a.SHA1); err != nil {
				_ = os.Remove(zipPath)
				return fmt.Errorf("%s: %w", r.Path, err)
			}
		}
		// Extrai ao lado do destino final: assim o rename é sempre dentro do
		// mesmo sistema de arquivos (pastas do SDK podem ser links para outro disco).
		tmp := s.PackageDir(r.Path) + ".installing"
		_ = os.RemoveAll(tmp)
		if err := os.MkdirAll(tmp, 0o755); err != nil {
			return err
		}
		err = extractZip(ctx, zipPath, tmp, func(done, total int64) {
			report("extract", done, total, 0.92+0.07*float64(done)/float64(max64(total, 1)))
		})
		if err != nil {
			_ = os.RemoveAll(tmp)
			return platform.Errorf("extração de %s: %w", "extraction of %s: %w", r.Path, err)
		}
		report("finalize", 0, 0, 0.99)
		if err := s.commit(r, cat.Licenses[r.LicenseID], tmp); err != nil {
			_ = os.RemoveAll(tmp)
			return platform.Errorf("instalação de %s: %w", "installation of %s: %w", r.Path, err)
		}
		_ = os.Remove(zipPath)
		report("finalize", 0, 0, 1)
		doneWork += weight
		logf("✓ %s", platform.Trf("%s instalado", "%s installed", r.Path))
	}
	// Limpa a pasta de downloads se ficou vazia.
	_ = os.Remove(filepath.Join(s.Root, ".downloadIntermediates"))
	return nil
}

// commit move o conteúdo extraído para o destino final e grava o package.xml.
func (s SDK) commit(r *Remote, lic License, tmp string) error {
	// O zip costuma ter uma única pasta raiz; o conteúdo dela é o pacote.
	src := tmp
	entries, err := os.ReadDir(tmp)
	if err != nil {
		return err
	}
	if len(entries) == 1 && entries[0].IsDir() {
		src = filepath.Join(tmp, entries[0].Name())
	}
	dest := s.PackageDir(r.Path)
	if err := os.MkdirAll(filepath.Dir(dest), 0o755); err != nil {
		return err
	}
	backup := ""
	if platform.DirExists(dest) {
		backup = dest + ".old-" + fmt.Sprint(time.Now().UnixNano())
		if err := os.Rename(dest, backup); err != nil {
			return err
		}
	}
	if err := os.Rename(src, dest); err != nil {
		if backup != "" {
			_ = os.Rename(backup, dest)
		}
		return err
	}
	if err := os.WriteFile(filepath.Join(dest, "package.xml"), packageXML(r, lic), 0o644); err != nil {
		return err
	}
	if backup != "" {
		_ = os.RemoveAll(backup)
	}
	_ = os.RemoveAll(tmp)
	return nil
}

// Uninstall remove pacotes instalados.
func (s SDK) Uninstall(paths []string) error {
	for _, p := range paths {
		if p == "" || strings.Contains(p, "..") {
			return platform.Errorf("pacote inválido: %q", "invalid package: %q", p)
		}
		dir := s.PackageDir(p)
		rel, err := filepath.Rel(s.Root, dir)
		if err != nil || rel == "." || strings.HasPrefix(rel, "..") {
			return platform.Errorf("pacote inválido: %q", "invalid package: %q", p)
		}
		if err := os.RemoveAll(dir); err != nil {
			return err
		}
		// Remove pastas-pai vazias (system-images/android-36/google_apis...).
		for parent := filepath.Dir(dir); parent != s.Root; parent = filepath.Dir(parent) {
			if os.Remove(parent) != nil { // só remove se estiver vazia
				break
			}
		}
	}
	return nil
}

// ---- package.xml -------------------------------------------------------------

const localNamespaces = `xmlns:ns2="http://schemas.android.com/repository/android/common/02" ` +
	`xmlns:ns3="http://schemas.android.com/repository/android/common/01" ` +
	`xmlns:ns4="http://schemas.android.com/repository/android/generic/01" ` +
	`xmlns:ns5="http://schemas.android.com/repository/android/generic/02" ` +
	`xmlns:ns6="http://schemas.android.com/sdk/android/repo/repository2/04" ` +
	`xmlns:ns7="http://schemas.android.com/sdk/android/repo/repository2/01" ` +
	`xmlns:ns8="http://schemas.android.com/sdk/android/repo/repository2/02" ` +
	`xmlns:ns9="http://schemas.android.com/sdk/android/repo/repository2/03" ` +
	`xmlns:ns10="http://schemas.android.com/sdk/android/repo/addon2/01" ` +
	`xmlns:ns11="http://schemas.android.com/sdk/android/repo/addon2/02" ` +
	`xmlns:ns12="http://schemas.android.com/sdk/android/repo/addon2/03" ` +
	`xmlns:ns13="http://schemas.android.com/sdk/android/repo/addon2/04" ` +
	`xmlns:ns14="http://schemas.android.com/sdk/android/repo/sys-img2/05" ` +
	`xmlns:ns15="http://schemas.android.com/sdk/android/repo/sys-img2/04" ` +
	`xmlns:ns16="http://schemas.android.com/sdk/android/repo/sys-img2/03" ` +
	`xmlns:ns17="http://schemas.android.com/sdk/android/repo/sys-img2/02" ` +
	`xmlns:ns18="http://schemas.android.com/sdk/android/repo/sys-img2/01"`

// detailsPrefix converte o xsi:type do manifesto ("sys-img:sysImgDetailsType")
// no prefixo usado nos package.xml locais ("ns14:sysImgDetailsType").
func detailsPrefix(t string) string {
	local := t
	if i := strings.IndexByte(t, ':'); i >= 0 {
		local = t[i+1:]
	}
	switch local {
	case "genericDetailsType":
		return "ns5:" + local
	case "sysImgDetailsType":
		return "ns14:" + local
	case "addonDetailsType":
		return "ns13:" + local
	default: // platformDetailsType, sourceDetailsType, extraDetailsType...
		return "ns6:" + local
	}
}

var textEscaper = strings.NewReplacer("&", "&amp;", "<", "&lt;", ">", "&gt;")
var attrEscaper = strings.NewReplacer("&", "&amp;", "<", "&lt;", ">", "&gt;", `"`, "&quot;")

func esc(s string) string     { return textEscaper.Replace(s) }
func escAttr(s string) string { return attrEscaper.Replace(s) }

// packageXML produz o mesmo package.xml que o sdkmanager grava ao instalar, o
// que faz o Android Studio e o sdkmanager reconhecerem o pacote como instalado.
func packageXML(r *Remote, lic License) []byte {
	var b bytes.Buffer
	b.WriteString(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` + "\n")
	b.WriteString("<ns2:repository " + localNamespaces + ">")
	if lic.ID != "" {
		fmt.Fprintf(&b, `<license id="%s" type="text">%s</license>`, escAttr(lic.ID), esc(lic.Text))
	}
	fmt.Fprintf(&b, `<localPackage path="%s" obsolete="false">`, escAttr(r.Path))
	typ := r.DetailsType
	if typ == "" {
		typ = "generic:genericDetailsType"
	}
	inner := strings.TrimSpace(r.DetailsInner)
	if inner == "" {
		fmt.Fprintf(&b, `<type-details xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="%s"/>`, detailsPrefix(typ))
	} else {
		fmt.Fprintf(&b, `<type-details xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="%s">%s</type-details>`, detailsPrefix(typ), inner)
	}
	b.WriteString("<revision>")
	fmt.Fprintf(&b, "<major>%d</major><minor>%d</minor><micro>%d</micro>", r.Revision.Major, r.Revision.Minor, r.Revision.Micro)
	if r.Revision.Preview != 0 {
		fmt.Fprintf(&b, "<preview>%d</preview>", r.Revision.Preview)
	}
	b.WriteString("</revision>")
	fmt.Fprintf(&b, "<display-name>%s</display-name>", esc(r.Name))
	if r.LicenseID != "" {
		fmt.Fprintf(&b, `<uses-license ref="%s"/>`, escAttr(r.LicenseID))
	}
	if len(r.Deps) > 0 {
		b.WriteString("<dependencies>")
		for _, d := range r.Deps {
			fmt.Fprintf(&b, `<dependency path="%s"><min-revision><major>%d</major><minor>%d</minor><micro>%d</micro></min-revision></dependency>`,
				escAttr(d.Path), d.Min.Major, d.Min.Minor, d.Min.Micro)
		}
		b.WriteString("</dependencies>")
	}
	b.WriteString("</localPackage></ns2:repository>")
	return b.Bytes()
}

// ---- download -----------------------------------------------------------------

func max64(a, b int64) int64 {
	if a > b {
		return a
	}
	return b
}

// HumanBytes formata um tamanho em bytes.
func HumanBytes(n int64) string {
	const unit = 1024
	if n < unit {
		return fmt.Sprintf("%d B", n)
	}
	div, exp := int64(unit), 0
	for m := n / unit; m >= unit; m /= unit {
		div *= unit
		exp++
	}
	return fmt.Sprintf("%.1f %ciB", float64(n)/float64(div), "KMGTPE"[exp])
}

func freeSpace(dir string) (uint64, error) {
	probe := dir
	for !platform.DirExists(probe) {
		parent := filepath.Dir(probe)
		if parent == probe {
			break
		}
		probe = parent
	}
	var st syscall.Statfs_t
	if err := syscall.Statfs(probe, &st); err != nil {
		return 0, err
	}
	return uint64(st.Bavail) * uint64(st.Bsize), nil
}

type countWriter struct {
	w    io.Writer
	done int64
	cb   func(int64)
	last time.Time
}

func (c *countWriter) Write(p []byte) (int, error) {
	n, err := c.w.Write(p)
	c.done += int64(n)
	if time.Since(c.last) > 150*time.Millisecond {
		c.last = time.Now()
		c.cb(c.done)
	}
	return n, err
}

// downloadFile baixa url para dest, retomando de dest+".part" quando possível.
func downloadFile(ctx context.Context, url, dest string, expected int64, progress func(done, total int64)) error {
	if st, err := os.Stat(dest); err == nil && (expected <= 0 || st.Size() == expected) {
		progress(st.Size(), st.Size()) // já baixado antes
		return nil
	}
	part := dest + ".part"
	var offset int64
	if st, err := os.Stat(part); err == nil {
		offset = st.Size()
	}
	for attempt := 0; ; attempt++ {
		err := downloadOnce(ctx, url, part, &offset, expected, progress)
		if err == nil {
			break
		}
		if ctx.Err() != nil {
			return ctx.Err()
		}
		var he *httpStatusError
		if errors.As(err, &he) && he.code != http.StatusRequestedRangeNotSatisfiable {
			return err
		}
		if attempt >= 5 {
			return err
		}
		if errors.As(err, &he) { // 416: o .part está inválido, recomeça
			_ = os.Remove(part)
			offset = 0
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-time.After(time.Duration(attempt+1) * 2 * time.Second):
		}
	}
	return os.Rename(part, dest)
}

type httpStatusError struct {
	code int
	url  string
}

func (e *httpStatusError) Error() string { return fmt.Sprintf("%s: HTTP %d", e.url, e.code) }

func downloadOnce(ctx context.Context, url, part string, offset *int64, expected int64, progress func(done, total int64)) error {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return err
	}
	req.Header.Set("User-Agent", userAgent())
	if *offset > 0 {
		req.Header.Set("Range", fmt.Sprintf("bytes=%d-", *offset))
	}
	resp, err := DownloadClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	flags := os.O_CREATE | os.O_WRONLY
	switch resp.StatusCode {
	case http.StatusOK:
		*offset = 0 // servidor ignorou o Range: recomeça do zero
		flags |= os.O_TRUNC
	case http.StatusPartialContent:
		flags |= os.O_APPEND
	default:
		return &httpStatusError{resp.StatusCode, url}
	}
	total := expected
	if resp.ContentLength > 0 {
		total = *offset + resp.ContentLength
	}
	f, err := os.OpenFile(part, flags, 0o644)
	if err != nil {
		return err
	}
	cw := &countWriter{w: f, done: *offset, cb: func(d int64) { *offset = d; progress(d, total) }}
	_, err = io.Copy(cw, resp.Body)
	*offset = cw.done
	if cerr := f.Close(); err == nil {
		err = cerr
	}
	if err != nil {
		return err
	}
	progress(cw.done, total)
	if expected > 0 && cw.done != expected {
		return platform.Errorf("download incompleto (%d de %d bytes)", "incomplete download (%d of %d bytes)", cw.done, expected)
	}
	return nil
}

func verifySHA1(file, want string) error {
	f, err := os.Open(file)
	if err != nil {
		return err
	}
	defer f.Close()
	h := sha1.New()
	if _, err := io.Copy(h, f); err != nil {
		return err
	}
	if got := hex.EncodeToString(h.Sum(nil)); !strings.EqualFold(got, want) {
		return platform.Errorf("checksum inválido (esperado %s, obtido %s) — o download foi descartado", "invalid checksum (expected %s, got %s) — the download was discarded", want, got)
	}
	return nil
}

// extractZip extrai o zip em dest, protegendo contra "zip slip" e preservando
// permissões (bit de execução) e links simbólicos.
func extractZip(ctx context.Context, zipPath, dest string, progress func(done, total int64)) error {
	zr, err := zip.OpenReader(zipPath)
	if err != nil {
		return err
	}
	defer zr.Close()
	var total int64
	for _, f := range zr.File {
		total += int64(f.UncompressedSize64)
	}
	var done int64
	last := time.Now()
	destClean := filepath.Clean(dest) + string(filepath.Separator)
	for _, f := range zr.File {
		if err := ctx.Err(); err != nil {
			return err
		}
		target := filepath.Join(dest, filepath.FromSlash(f.Name))
		if !strings.HasPrefix(target+string(filepath.Separator), destClean) {
			return platform.Errorf("entrada suspeita no zip: %s", "suspicious entry in zip: %s", f.Name)
		}
		mode := f.Mode()
		switch {
		case f.FileInfo().IsDir():
			if err := os.MkdirAll(target, 0o755); err != nil {
				return err
			}
		case mode&os.ModeSymlink != 0:
			rc, err := f.Open()
			if err != nil {
				return err
			}
			link, err := io.ReadAll(rc)
			rc.Close()
			if err != nil {
				return err
			}
			if err := os.MkdirAll(filepath.Dir(target), 0o755); err != nil {
				return err
			}
			l := string(link)
			if filepath.IsAbs(l) {
				return platform.Errorf("link simbólico absoluto no zip: %s -> %s", "absolute symlink in zip: %s -> %s", f.Name, l)
			}
			resolved := filepath.Join(filepath.Dir(target), l)
			if !strings.HasPrefix(resolved+string(filepath.Separator), destClean) {
				return platform.Errorf("link simbólico suspeito no zip: %s -> %s", "suspicious symlink in zip: %s -> %s", f.Name, l)
			}
			_ = os.Remove(target)
			if err := os.Symlink(l, target); err != nil {
				return err
			}
		default:
			if err := os.MkdirAll(filepath.Dir(target), 0o755); err != nil {
				return err
			}
			perm := mode.Perm()
			if perm == 0 {
				perm = 0o644
			}
			perm |= 0o600
			out, err := os.OpenFile(target, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, perm)
			if err != nil {
				return err
			}
			rc, err := f.Open()
			if err != nil {
				out.Close()
				return err
			}
			_, err = io.Copy(out, rc)
			rc.Close()
			if cerr := out.Close(); err == nil {
				err = cerr
			}
			if err != nil {
				return err
			}
			_ = os.Chmod(target, perm) // ignora o umask
		}
		done += int64(f.UncompressedSize64)
		if time.Since(last) > 150*time.Millisecond {
			last = time.Now()
			progress(done, total)
		}
	}
	progress(total, total)
	return nil
}
