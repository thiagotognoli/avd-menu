package sdk

import (
	"bufio"
	"encoding/xml"
	"io/fs"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"avdmenu/internal/platform"
)

// Installed é um pacote já presente no disco.
type Installed struct {
	Path      string   `json:"path"`
	Name      string   `json:"name"`
	Revision  Revision `json:"-"`
	Rev       string   `json:"revision"`
	LicenseID string   `json:"license,omitempty"`
	Dir       string   `json:"dir"`
	Details   Details  `json:"-"`
}

type xmlLocal struct {
	Local struct {
		Path    string `xml:"path,attr"`
		Details struct {
			Details
		} `xml:"type-details"`
		Revision    Revision `xml:"revision"`
		DisplayName string   `xml:"display-name"`
		UsesLicense struct {
			Ref string `xml:"ref,attr"`
		} `xml:"uses-license"`
	} `xml:"localPackage"`
}

func readPackageXML(file string) (*Installed, error) {
	b, err := os.ReadFile(file)
	if err != nil {
		return nil, err
	}
	var x xmlLocal
	if err := xml.Unmarshal(b, &x); err != nil {
		return nil, err
	}
	l := x.Local
	if l.Path == "" {
		return nil, fs.ErrNotExist
	}
	return &Installed{
		Path:      l.Path,
		Name:      strings.TrimSpace(l.DisplayName),
		Revision:  l.Revision,
		Rev:       l.Revision.String(),
		LicenseID: l.UsesLicense.Ref,
		Dir:       filepath.Dir(file),
		Details:   l.Details.Details,
	}, nil
}

// readSourceProps lê um source.properties (formato chave=valor).
func readSourceProps(file string) map[string]string {
	f, err := os.Open(file)
	if err != nil {
		return nil
	}
	defer f.Close()
	m := map[string]string{}
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		if i := strings.IndexByte(line, '='); i > 0 {
			m[strings.TrimSpace(line[:i])] = strings.TrimSpace(line[i+1:])
		}
	}
	return m
}

// ListInstalled varre o SDK atrás de pacotes instalados (via package.xml, como
// o sdkmanager). Pacotes descompactados à mão, só com source.properties, são
// reconhecidos para emulator, platform-tools e cmdline-tools. Links simbólicos
// para pastas são seguidos (é comum mover system-images para outro disco).
func (s SDK) ListInstalled() []Installed {
	var out []Installed
	if !s.Exists() {
		return out
	}
	const maxDepth = 4
	skip := map[string]bool{"licenses": true, ".temp": true, ".downloadIntermediates": true, "patcher": true}
	var walk func(dir, rel string, depth int)
	walk = func(dir, rel string, depth int) {
		entries, err := os.ReadDir(dir)
		if err != nil {
			return
		}
		for _, e := range entries {
			name := e.Name()
			if depth == 1 && skip[name] || strings.HasSuffix(name, ".installing") || strings.Contains(name, ".old-") {
				continue
			}
			p := filepath.Join(dir, name)
			if st, err := os.Stat(p); err != nil || !st.IsDir() { // Stat segue links
				continue
			}
			r := name
			if rel != "" {
				r = rel + "/" + name
			}
			if pk, err := readPackageXML(filepath.Join(p, "package.xml")); err == nil {
				pk.Dir = p
				out = append(out, *pk)
				continue
			}
			// Pacotes descompactados à mão, sem package.xml.
			pkgPath := ""
			switch {
			case depth == 1 && (r == "emulator" || r == "platform-tools"):
				pkgPath = r
			case depth == 2 && strings.HasPrefix(r, "cmdline-tools/"):
				pkgPath = "cmdline-tools;" + name
			}
			if pkgPath != "" {
				if sp := readSourceProps(filepath.Join(p, "source.properties")); sp != nil {
					rev := ParseRevision(sp["Pkg.Revision"])
					desc := sp["Pkg.Desc"]
					if desc == "" {
						desc = pkgPath
					}
					out = append(out, Installed{Path: pkgPath, Name: desc, Revision: rev, Rev: rev.String(), Dir: p})
					continue
				}
			}
			if depth < maxDepth {
				walk(p, r, depth+1)
			}
		}
	}
	root := s.Root
	if r, err := filepath.EvalSymlinks(root); err == nil {
		root = r
	}
	walk(root, "", 1)
	sort.Slice(out, func(i, j int) bool { return out[i].Path < out[j].Path })
	return out
}

// InstalledMap indexa os pacotes instalados pelo path.
func (s SDK) InstalledMap() map[string]Installed {
	m := map[string]Installed{}
	for _, p := range s.ListInstalled() {
		m[p.Path] = p
	}
	return m
}

// SysImageProps são as propriedades de uma imagem de sistema instalada, lidas
// do source.properties dela.
type SysImageProps struct {
	API        string
	TagID      string
	TagDisplay string
	ABI        string
	Vendor     string
	PlayStore  bool
	Target     string // android-36 / android-36.1 (nome da pasta da API)
	Dir        string // relativo ao SDK, com barra final (vai em image.sysdir.1)
}

// ReadSysImage lê as propriedades de uma imagem instalada pelo path do pacote.
func (s SDK) ReadSysImage(pkgPath string) (SysImageProps, bool) {
	dir := s.PackageDir(pkgPath)
	if !platform.DirExists(dir) {
		return SysImageProps{}, false
	}
	parts := strings.Split(pkgPath, ";")
	if len(parts) != 4 || parts[0] != "system-images" {
		return SysImageProps{}, false
	}
	p := SysImageProps{
		Dir:    filepath.ToSlash(filepath.Join(parts[0], parts[1], parts[2], parts[3])) + "/",
		API:    strings.TrimPrefix(parts[1], "android-"),
		Target: parts[1],
		TagID:  parts[2],
		ABI:    parts[3],
	}
	if sp := readSourceProps(filepath.Join(dir, "source.properties")); sp != nil {
		if v := sp["AndroidVersion.ApiLevel"]; v != "" {
			p.API = v
		}
		if v := sp["SystemImage.TagId"]; v != "" {
			p.TagID = v
		}
		p.TagDisplay = sp["SystemImage.TagDisplay"]
		if v := sp["SystemImage.Abi"]; v != "" {
			p.ABI = v
		}
		p.Vendor = sp["Addon.VendorDisplay"]
	}
	p.PlayStore = strings.Contains(p.TagID, "playstore") || strings.Contains(strings.ToLower(p.TagDisplay), "play")
	return p, true
}
