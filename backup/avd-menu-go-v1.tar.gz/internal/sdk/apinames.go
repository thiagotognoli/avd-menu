package sdk

import "strings"

// apiNames mapeia nível de API -> versão do Android.
var apiNames = map[string]string{
	"37": "Android 17", "36": "Android 16", "35": "Android 15", "34": "Android 14",
	"33": "Android 13", "32": "Android 12L", "31": "Android 12", "30": "Android 11", "29": "Android 10",
	"28": "Android 9 (Pie)", "27": "Android 8.1 (Oreo)", "26": "Android 8.0 (Oreo)", "25": "Android 7.1 (Nougat)",
	"24": "Android 7.0 (Nougat)", "23": "Android 6.0 (Marshmallow)", "22": "Android 5.1 (Lollipop)",
	"21": "Android 5.0 (Lollipop)", "20": "Android 4.4W", "19": "Android 4.4 (KitKat)", "18": "Android 4.3",
	"17": "Android 4.2", "16": "Android 4.1", "15": "Android 4.0.3", "14": "Android 4.0",
}

// APIName devolve o nome amigável da versão ("Android 16") para um nível de API.
// Para níveis desconhecidos usa o codinome da prévia, se houver.
func APIName(api, codename string) string {
	api = strings.TrimRight(api, "x")
	if n, ok := apiNames[api]; ok {
		return n
	}
	// 36.1, 37.2... são versões menores do mesmo Android
	if i := strings.IndexByte(api, '.'); i > 0 {
		if n, ok := apiNames[api[:i]]; ok {
			return n
		}
	}
	if i := strings.Index(api, "-ext"); i > 0 {
		if n, ok := apiNames[api[:i]]; ok {
			return n
		}
	}
	if codename != "" {
		return codename + " (preview)"
	}
	return ""
}
