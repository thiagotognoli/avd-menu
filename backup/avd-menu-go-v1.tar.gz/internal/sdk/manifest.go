package sdk

import (
	"context"
	"crypto/sha1"
	"encoding/hex"
	"encoding/xml"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"avdmenu/internal/platform"
)

// RepoBase é a raiz do repositório público de pacotes do Android SDK.
const RepoBase = "https://dl.google.com/android/repository/"

// Revision é a versão de um pacote (major.minor.micro[-rcN]).
type Revision struct {
	Major   int `xml:"major"`
	Minor   int `xml:"minor"`
	Micro   int `xml:"micro"`
	Preview int `xml:"preview"`
}

func (r Revision) String() string {
	s := strconv.Itoa(r.Major)
	if r.Minor != 0 || r.Micro != 0 {
		s += "." + strconv.Itoa(r.Minor)
	}
	if r.Micro != 0 {
		s += "." + strconv.Itoa(r.Micro)
	}
	if r.Preview > 0 {
		s += " rc" + strconv.Itoa(r.Preview)
	}
	return s
}

// Compare devolve <0, 0 ou >0. Uma versão preview vale menos que a final.
func (r Revision) Compare(o Revision) int {
	for _, p := range [][2]int{{r.Major, o.Major}, {r.Minor, o.Minor}, {r.Micro, o.Micro}} {
		if p[0] != p[1] {
			if p[0] < p[1] {
				return -1
			}
			return 1
		}
	}
	rp, op := r.Preview, o.Preview
	if rp == 0 {
		rp = 1 << 30
	}
	if op == 0 {
		op = 1 << 30
	}
	switch {
	case rp < op:
		return -1
	case rp > op:
		return 1
	}
	return 0
}

// ParseRevision lê "37.1.11" (ou "37.1.11 rc2" / "37.1.11-rc2").
func ParseRevision(s string) Revision {
	var r Revision
	s = strings.TrimSpace(s)
	if i := strings.IndexAny(s, " -"); i >= 0 {
		if strings.Contains(s[i:], "rc") {
			r.Preview, _ = strconv.Atoi(strings.TrimLeft(strings.TrimSpace(s[i:]), "-rc "))
		}
		s = s[:i]
	}
	parts := strings.Split(s, ".")
	dst := []*int{&r.Major, &r.Minor, &r.Micro}
	for i := 0; i < len(parts) && i < 3; i++ {
		*dst[i], _ = strconv.Atoi(parts[i])
	}
	return r
}

// Archive é um arquivo .zip de um pacote para um determinado host.
type Archive struct {
	URL    string `json:"url"`
	Size   int64  `json:"size"`
	SHA1   string `json:"sha1"`
	HostOS string `json:"hostOs,omitempty"`
	Arch   string `json:"hostArch,omitempty"`
}

// Dependency é um pacote exigido por outro (ex.: a imagem exige o emulador).
type Dependency struct {
	Path string
	Min  Revision
}

// Tag é a "categoria" de uma imagem de sistema (Google APIs, Google Play, TV...).
type Tag struct {
	ID      string `xml:"id" json:"id"`
	Display string `xml:"display" json:"display"`
}

// Details são os dados específicos do tipo do pacote que nos interessam.
type Details struct {
	APILevel   string `xml:"api-level"`
	Codename   string `xml:"codename"`
	ExtLevel   string `xml:"extension-level"`
	BaseExt    string `xml:"base-extension"`
	Tags       []Tag  `xml:"tag"`
	VendorID   string `xml:"vendor>id"`
	VendorDisp string `xml:"vendor>display"`
	ABI        string `xml:"abi"`
}

// TagDisplay devolve o nome legível da tag principal (ex.: "Google APIs").
func (d Details) TagDisplay() string {
	if len(d.Tags) > 0 {
		return d.Tags[0].Display
	}
	return ""
}

// Remote é um pacote disponível para download.
type Remote struct {
	Path         string
	Obsolete     bool
	Name         string
	Revision     Revision
	LicenseID    string
	ChannelID    string
	Channel      string
	DetailsType  string // valor de xsi:type, ex. "sys-img:sysImgDetailsType"
	DetailsInner string // conteúdo bruto de <type-details>
	Details      Details
	Deps         []Dependency
	Archives     []Archive
	BaseURL      string // diretório do manifesto, base das URLs relativas
}

// ArchiveFor escolhe o arquivo adequado ao host (nil se o pacote não existe
// para esta plataforma).
func (r *Remote) ArchiveFor(hostOS, hostArch string) *Archive {
	var best *Archive
	bestScore := -1
	for i := range r.Archives {
		a := &r.Archives[i]
		if a.HostOS != "" && a.HostOS != hostOS {
			continue
		}
		if a.Arch != "" && a.Arch != hostArch {
			continue
		}
		score := 0
		if a.HostOS != "" {
			score++
		}
		if a.Arch != "" {
			score++
		}
		if score > bestScore {
			best, bestScore = a, score
		}
	}
	return best
}

// AbsURL resolve a URL do arquivo em relação ao manifesto de origem.
func (r *Remote) AbsURL(a *Archive) string {
	if strings.HasPrefix(a.URL, "http://") || strings.HasPrefix(a.URL, "https://") {
		return a.URL
	}
	return r.BaseURL + a.URL
}

// ---- estruturas XML ---------------------------------------------------------

type xmlRepo struct {
	Licenses []struct {
		ID   string `xml:"id,attr"`
		Text string `xml:",chardata"`
	} `xml:"license"`
	Channels []struct {
		ID   string `xml:"id,attr"`
		Name string `xml:",chardata"`
	} `xml:"channel"`
	Packages []xmlPackage `xml:"remotePackage"`
}

type xmlPackage struct {
	Path     string `xml:"path,attr"`
	Obsolete string `xml:"obsolete,attr"`
	Details  struct {
		Type  string `xml:"http://www.w3.org/2001/XMLSchema-instance type,attr"`
		Inner string `xml:",innerxml"`
		Details
	} `xml:"type-details"`
	Revision    Revision `xml:"revision"`
	DisplayName string   `xml:"display-name"`
	UsesLicense struct {
		Ref string `xml:"ref,attr"`
	} `xml:"uses-license"`
	ChannelRef struct {
		Ref string `xml:"ref,attr"`
	} `xml:"channelRef"`
	Deps []struct {
		Path string   `xml:"path,attr"`
		Min  Revision `xml:"min-revision"`
	} `xml:"dependencies>dependency"`
	Archives []struct {
		Complete struct {
			Size     int64  `xml:"size"`
			Checksum string `xml:"checksum"`
			URL      string `xml:"url"`
		} `xml:"complete"`
		HostOS   string `xml:"host-os"`
		HostArch string `xml:"host-arch"`
	} `xml:"archives>archive"`
}

// parseRepo lê um manifesto (repository2 ou sys-img2) já baixado.
func parseRepo(data []byte, baseURL string) ([]*Remote, map[string]License, error) {
	var repo xmlRepo
	if err := xml.Unmarshal(data, &repo); err != nil {
		return nil, nil, err
	}
	licenses := map[string]License{}
	for _, l := range repo.Licenses {
		licenses[l.ID] = License{ID: l.ID, Text: l.Text}
	}
	channels := map[string]string{}
	for _, c := range repo.Channels {
		channels[c.ID] = strings.TrimSpace(c.Name)
	}
	var out []*Remote
	for _, p := range repo.Packages {
		r := &Remote{
			Path:         p.Path,
			Obsolete:     p.Obsolete == "true",
			Name:         strings.TrimSpace(p.DisplayName),
			Revision:     p.Revision,
			LicenseID:    p.UsesLicense.Ref,
			ChannelID:    p.ChannelRef.Ref,
			Channel:      channels[p.ChannelRef.Ref],
			DetailsType:  p.Details.Type,
			DetailsInner: p.Details.Inner,
			Details:      p.Details.Details,
			BaseURL:      baseURL,
		}
		if r.Channel == "" {
			r.Channel = "stable"
		}
		for _, d := range p.Deps {
			r.Deps = append(r.Deps, Dependency{Path: d.Path, Min: d.Min})
		}
		for _, a := range p.Archives {
			r.Archives = append(r.Archives, Archive{
				URL:    strings.TrimSpace(a.Complete.URL),
				Size:   a.Complete.Size,
				SHA1:   strings.ToLower(strings.TrimSpace(a.Complete.Checksum)),
				HostOS: a.HostOS,
				Arch:   a.HostArch,
			})
		}
		out = append(out, r)
	}
	return out, licenses, nil
}

// ---- download e cache dos manifestos ------------------------------------------

// Catalog é o conjunto de pacotes publicados pelo Google.
type Catalog struct {
	Packages []*Remote
	Licenses map[string]License
	Fetched  time.Time
	// Offline é verdadeiro quando só havia cópia antiga em cache.
	Offline bool
}

// Find devolve o pacote (melhor revisão permitida) com o path dado.
func (c *Catalog) Find(pkgPath string, preview bool) *Remote {
	var best *Remote
	for _, p := range c.Packages {
		if p.Path != pkgPath || !channelAllowed(p, preview) {
			continue
		}
		if best == nil || p.Revision.Compare(best.Revision) > 0 {
			best = p
		}
	}
	return best
}

// Latest devolve, para cada path, a melhor revisão permitida.
func (c *Catalog) Latest(preview bool) []*Remote {
	best := map[string]*Remote{}
	for _, p := range c.Packages {
		if !channelAllowed(p, preview) || p.Obsolete {
			continue
		}
		if cur, ok := best[p.Path]; !ok || p.Revision.Compare(cur.Revision) > 0 {
			best[p.Path] = p
		}
	}
	out := make([]*Remote, 0, len(best))
	for _, p := range best {
		out = append(out, p)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Path < out[j].Path })
	return out
}

func channelAllowed(p *Remote, preview bool) bool {
	return preview || p.ChannelID == "" || p.ChannelID == "channel-0"
}

var (
	httpClient = &http.Client{Timeout: 90 * time.Second}
	// DownloadClient não tem timeout total (os arquivos são grandes).
	DownloadClient = &http.Client{
		Transport: &http.Transport{
			Proxy:                 http.ProxyFromEnvironment,
			TLSHandshakeTimeout:   20 * time.Second,
			ResponseHeaderTimeout: 60 * time.Second,
			IdleConnTimeout:       60 * time.Second,
		},
	}
)

func userAgent() string { return "avd-menu/" + platform.Version }

func httpGet(ctx context.Context, u string) ([]byte, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", userAgent())
	resp, err := httpClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("%s: HTTP %d", u, resp.StatusCode)
	}
	return io.ReadAll(resp.Body)
}

func manifestCachePath(u string) string {
	sum := sha1.Sum([]byte(u))
	return filepath.Join(platform.CacheDir(), "manifests", hex.EncodeToString(sum[:8])+"-"+path.Base(u))
}

// cachedGet baixa u, usando o cache em disco enquanto estiver "fresco".
// Se a rede falhar devolve a cópia antiga (stale=true) quando houver.
func cachedGet(ctx context.Context, u string, ttl time.Duration, force bool) (data []byte, stale bool, err error) {
	cp := manifestCachePath(u)
	st, statErr := os.Stat(cp)
	if !force && statErr == nil && time.Since(st.ModTime()) < ttl {
		if b, e := os.ReadFile(cp); e == nil {
			return b, false, nil
		}
	}
	b, err := httpGet(ctx, u)
	if err != nil {
		if statErr == nil {
			if old, e := os.ReadFile(cp); e == nil {
				return old, true, nil
			}
		}
		return nil, false, err
	}
	if os.MkdirAll(filepath.Dir(cp), 0o755) == nil {
		_ = os.WriteFile(cp, b, 0o644)
	}
	return b, false, nil
}

// firstOf tenta cada URL em ordem e devolve a primeira que funcionar.
func firstOf(ctx context.Context, urls []string, ttl time.Duration, force bool) ([]byte, string, bool, error) {
	var lastErr error
	for _, u := range urls {
		b, stale, err := cachedGet(ctx, u, ttl, force)
		if err == nil {
			return b, u, stale, nil
		}
		lastErr = err
	}
	return nil, "", false, lastErr
}

type xmlSites struct {
	Sites []struct {
		Type string `xml:"http://www.w3.org/2001/XMLSchema-instance type,attr"`
		URL  string `xml:"url"`
	} `xml:"site"`
}

// FetchCatalog baixa (ou lê do cache) os manifestos de pacotes e imagens de
// sistema. Com force=true ignora o cache.
func FetchCatalog(ctx context.Context, force bool) (*Catalog, error) {
	const ttl = 3 * time.Hour
	cat := &Catalog{Licenses: map[string]License{}, Fetched: time.Now()}

	mainData, mainURL, stale, err := firstOf(ctx, []string{
		RepoBase + "repository2-4.xml", RepoBase + "repository2-3.xml",
	}, ttl, force)
	if err != nil {
		return nil, platform.Errorf("não foi possível obter a lista de pacotes do Android SDK: %w", "could not fetch the Android SDK package list: %w", err)
	}
	cat.Offline = stale
	pkgs, lic, err := parseRepo(mainData, mainURL[:strings.LastIndex(mainURL, "/")+1])
	if err != nil {
		return nil, platform.Errorf("manifesto inválido: %w", "invalid manifest: %w", err)
	}
	cat.Packages = append(cat.Packages, pkgs...)
	for k, v := range lic {
		cat.Licenses[k] = v
	}

	// Lista de sites de imagens de sistema.
	listData, _, stale2, err := firstOf(ctx, []string{
		RepoBase + "addons_list-7.xml", RepoBase + "addons_list-6.xml", RepoBase + "addons_list-5.xml",
	}, ttl, force)
	if err != nil {
		return cat, nil // sem imagens, mas o resto funciona
	}
	cat.Offline = cat.Offline || stale2
	var sites xmlSites
	if err := xml.Unmarshal(listData, &sites); err != nil {
		return cat, nil
	}
	var urls []string
	for _, s := range sites.Sites {
		if strings.Contains(strings.ToLower(s.Type), "sysimg") && strings.TrimSpace(s.URL) != "" {
			urls = append(urls, strings.TrimSpace(s.URL))
		}
	}

	var mu sync.Mutex
	var wg sync.WaitGroup
	sem := make(chan struct{}, 8)
	for _, rel := range urls {
		wg.Add(1)
		go func(rel string) {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()
			// A lista pode citar uma versão de esquema mais antiga; tenta a
			// mais nova primeiro.
			cands := schemaVariants(rel)
			full := make([]string, len(cands))
			for i, c := range cands {
				full[i] = RepoBase + c
			}
			data, used, st, err := firstOf(ctx, full, ttl, force)
			if err != nil {
				return
			}
			base := used[:strings.LastIndex(used, "/")+1]
			ps, ls, err := parseRepo(data, base)
			if err != nil {
				return
			}
			mu.Lock()
			defer mu.Unlock()
			cat.Packages = append(cat.Packages, ps...)
			for k, v := range ls {
				if _, ok := cat.Licenses[k]; !ok {
					cat.Licenses[k] = v
				}
			}
			cat.Offline = cat.Offline || st
		}(rel)
	}
	wg.Wait()
	return cat, nil
}

// schemaVariants devolve a URL do manifesto com versões de esquema mais novas
// primeiro (sys-img2-5.xml, -4, -3), respeitando a que a lista indicou.
func schemaVariants(rel string) []string {
	u, err := url.Parse(rel)
	if err != nil {
		return []string{rel}
	}
	base := path.Base(u.Path)
	dir := path.Dir(u.Path)
	var prefix string
	switch {
	case strings.HasPrefix(base, "sys-img2-"):
		prefix = "sys-img2-"
	default:
		return []string{rel}
	}
	cur, _ := strconv.Atoi(strings.TrimSuffix(strings.TrimPrefix(base, prefix), ".xml"))
	seen := map[int]bool{}
	var out []string
	for _, v := range []int{cur, 5, 4, 3} {
		if v == 0 || seen[v] {
			continue
		}
		seen[v] = true
		out = append(out, path.Join(dir, fmt.Sprintf("%s%d.xml", prefix, v)))
	}
	return out
}
