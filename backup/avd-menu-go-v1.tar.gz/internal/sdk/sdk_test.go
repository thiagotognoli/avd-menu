package sdk

import (
	"archive/zip"
	"bytes"
	"context"
	"crypto/sha1"
	"encoding/hex"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestLicenseHashMatchesSdkmanager(t *testing.T) {
	// Os dois textos (antigo e atual, com quebras de linha diferentes) precisam
	// gerar o mesmo hash que o sdkmanager do Google grava em licenses/.
	const want = "24333f8a63b6825ea9c5514f83c2829b004d1fee"
	for _, f := range []string{"android-sdk-license.old.txt", "android-sdk-license.current.txt"} {
		b, err := os.ReadFile(filepath.Join("testdata", f))
		if err != nil {
			t.Fatal(err)
		}
		if got := (License{ID: "android-sdk-license", Text: string(b)}).Hash(); got != want {
			t.Errorf("%s: hash = %s, quer %s", f, got, want)
		}
	}
}

func TestNormalizeLicense(t *testing.T) {
	in := "  A  b\n  c\n\n d \n\n\nE\tf  "
	if got, want := NormalizeLicense(in), "A b c\n\nd \n\n\nE\tf"; got != want {
		t.Errorf("got %q want %q", got, want)
	}
}

func TestAcceptRoundTrip(t *testing.T) {
	s := SDK{Root: t.TempDir()}
	l := License{ID: "android-sdk-license", Text: "hello world"}
	if s.Accepted(l) {
		t.Fatal("não deveria estar aceita")
	}
	if err := s.Accept(l); err != nil {
		t.Fatal(err)
	}
	if !s.Accepted(l) {
		t.Fatal("deveria estar aceita")
	}
	// uma segunda versão da licença convive com a primeira
	l2 := License{ID: "android-sdk-license", Text: "hello world v2"}
	if s.Accepted(l2) {
		t.Fatal("v2 não deveria estar aceita")
	}
	_ = s.Accept(l2)
	if !s.Accepted(l) || !s.Accepted(l2) {
		t.Fatal("aceites anteriores devem ser preservados")
	}
}

func TestRevision(t *testing.T) {
	cases := []struct {
		a, b string
		want int
	}{
		{"37.1.11", "37.1.11", 0}, {"37.1.11", "37.2", -1}, {"38", "37.9.9", 1},
		{"19.0 rc1", "19.0", -1}, {"19.0 rc2", "19.0 rc1", 1},
	}
	for _, c := range cases {
		if got := ParseRevision(c.a).Compare(ParseRevision(c.b)); got != c.want {
			t.Errorf("%s vs %s = %d, quer %d", c.a, c.b, got, c.want)
		}
	}
	if s := (Revision{Major: 37, Minor: 1, Micro: 11}).String(); s != "37.1.11" {
		t.Errorf("String = %q", s)
	}
}

func loadFixture(t *testing.T) (*Catalog, []*Remote) {
	t.Helper()
	b, err := os.ReadFile("testdata/repo.xml")
	if err != nil {
		t.Fatal(err)
	}
	pk, lic, err := parseRepo(b, "https://example.test/repo/")
	if err != nil {
		t.Fatal(err)
	}
	return &Catalog{Packages: pk, Licenses: lic}, pk
}

func TestParseAndChannels(t *testing.T) {
	cat, pk := loadFixture(t)
	if len(pk) != 4 {
		t.Fatalf("pacotes = %d", len(pk))
	}
	em := cat.Find("emulator", false)
	if em == nil || em.Revision.String() != "37.1.11" {
		t.Fatalf("estável deveria ser 37.1.11, veio %+v", em)
	}
	if dev := cat.Find("emulator", true); dev.Revision.String() != "37.3.2" {
		t.Fatalf("com prévias deveria ser 37.3.2, veio %s", dev.Revision)
	}
	img := cat.Find("system-images;android-36;google_apis_playstore;x86_64", false)
	if img == nil || img.Details.ABI != "x86_64" || img.Details.Tags[0].ID != "google_apis_playstore" || img.DetailsType != "sys-img:sysImgDetailsType" {
		t.Fatalf("imagem mal lida: %+v", img)
	}
	if len(img.Deps) != 1 || img.Deps[0].Path != "emulator" || img.Deps[0].Min.String() != "35.4.9" {
		t.Fatalf("dependência mal lida: %+v", img.Deps)
	}
	if a := em.ArchiveFor("linux", "x64"); a == nil || a.SHA1 != "aa" {
		t.Errorf("archive linux: %+v", a)
	}
	if a := em.ArchiveFor("linux", "aarch64"); a != nil {
		t.Errorf("não deveria haver emulador para linux/aarch64: %+v", a)
	}
	if a := em.ArchiveFor("macosx", "aarch64"); a == nil || a.URL != "emulator-mac-arm.zip" {
		t.Errorf("archive mac: %+v", a)
	}
	pt := cat.Find("platform-tools", false)
	if a := pt.ArchiveFor("macosx", "aarch64"); a == nil || pt.AbsURL(a) != "https://example.test/repo/pt-mac.zip" {
		t.Errorf("url absoluta: %+v", a)
	}
}

func TestPlanInstallAddsDependencies(t *testing.T) {
	cat, _ := loadFixture(t)
	s := SDK{Root: t.TempDir()}
	plan := s.PlanInstall(cat, []string{"system-images;android-36;google_apis_playstore;x86_64"}, false, false)
	var got []string
	for _, r := range plan.Install {
		got = append(got, r.Path)
	}
	want := "emulator,system-images;android-36;google_apis_playstore;x86_64,platform-tools"
	if strings.Join(got, ",") != want {
		t.Errorf("plano = %v", got)
	}
	if len(plan.Licenses) != 1 || plan.Licenses[0].ID != "android-sdk-license" {
		t.Errorf("licenças = %+v", plan.Licenses)
	}
	if len(plan.Missing) != 0 {
		t.Errorf("missing = %v", plan.Missing)
	}
	if p := s.PlanInstall(cat, []string{"nao-existe"}, false, false); len(p.Missing) != 1 {
		t.Errorf("deveria reportar pacote inexistente")
	}
}

func TestPackageXMLRoundTrip(t *testing.T) {
	cat, _ := loadFixture(t)
	r := cat.Find("system-images;android-36;google_apis_playstore;x86_64", false)
	root := t.TempDir()
	dir := filepath.Join(root, "system-images", "android-36", "google_apis_playstore", "x86_64")
	_ = os.MkdirAll(dir, 0o755)
	if err := os.WriteFile(filepath.Join(dir, "package.xml"), packageXML(r, cat.Licenses["android-sdk-license"]), 0o644); err != nil {
		t.Fatal(err)
	}
	inst := SDK{Root: root}.ListInstalled()
	if len(inst) != 1 {
		t.Fatalf("instalados = %d", len(inst))
	}
	p := inst[0]
	if p.Path != r.Path || p.Rev != "7" || p.LicenseID != "android-sdk-license" || p.Details.ABI != "x86_64" || p.Details.Tags[0].Display != "Google Play" {
		t.Errorf("leitura do package.xml: %+v", p)
	}
	x := string(packageXML(r, License{}))
	if !strings.Contains(x, `xsi:type="ns14:sysImgDetailsType"`) || !strings.Contains(x, `<dependency path="emulator">`) {
		t.Errorf("package.xml sem os elementos esperados:\n%s", x)
	}
}

// makeZip monta um zip com uma pasta raiz (como os do Google) e um link simbólico.
func makeZip(t *testing.T, files map[string]string, links map[string]string) []byte {
	t.Helper()
	var buf bytes.Buffer
	zw := zip.NewWriter(&buf)
	for name, content := range files {
		hd := &zip.FileHeader{Name: name, Method: zip.Deflate}
		hd.SetMode(0o755)
		w, _ := zw.CreateHeader(hd)
		_, _ = w.Write([]byte(content))
	}
	for name, target := range links {
		hd := &zip.FileHeader{Name: name}
		hd.SetMode(os.ModeSymlink | 0o777)
		w, _ := zw.CreateHeader(hd)
		_, _ = w.Write([]byte(target))
	}
	_ = zw.Close()
	return buf.Bytes()
}

func TestExtractZipProtectsAgainstZipSlip(t *testing.T) {
	bad := makeZip(t, map[string]string{"../evil.txt": "x"}, nil)
	zp := filepath.Join(t.TempDir(), "bad.zip")
	_ = os.WriteFile(zp, bad, 0o644)
	dest := t.TempDir()
	if err := extractZip(context.Background(), zp, dest, func(int64, int64) {}); err == nil {
		t.Fatal("deveria recusar caminho com ..")
	}
	abs := makeZip(t, map[string]string{"ok/a.txt": "x"}, map[string]string{"ok/link": "/etc/passwd"})
	_ = os.WriteFile(zp, abs, 0o644)
	if err := extractZip(context.Background(), zp, t.TempDir(), func(int64, int64) {}); err == nil {
		t.Fatal("deveria recusar link simbólico absoluto")
	}
}

func TestInstallEndToEnd(t *testing.T) {
	zipBytes := makeZip(t, map[string]string{
		"platform-tools/adb":               "#!/bin/sh\necho adb\n",
		"platform-tools/source.properties": "Pkg.Revision=37.0.1\n",
	}, map[string]string{"platform-tools/adb-link": "adb"})
	sum := sha1.Sum(zipBytes)
	var hits int
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		hits++
		http.ServeContent(w, r, "pt.zip", timeZero, bytes.NewReader(zipBytes)) // suporta Range
	}))
	defer srv.Close()

	cat, _ := loadFixture(t)
	pt := cat.Find("platform-tools", false)
	pt.BaseURL = srv.URL + "/"
	for i := range pt.Archives {
		pt.Archives[i].Size = int64(len(zipBytes))
		pt.Archives[i].SHA1 = hex.EncodeToString(sum[:])
		pt.Archives[i].URL = "pt.zip"
	}
	s := SDK{Root: filepath.Join(t.TempDir(), "sdk")}
	plan := s.PlanInstall(cat, []string{"platform-tools"}, false, false)
	if len(plan.Install) != 1 {
		t.Fatalf("plano: %+v", plan.Install)
	}
	if err := s.Install(context.Background(), cat, plan, nil, nil); err == nil {
		t.Fatal("sem aceitar a licença deveria falhar")
	}
	for _, l := range plan.Licenses {
		_ = s.Accept(l)
	}
	var last Progress
	if err := s.Install(context.Background(), cat, plan, func(p Progress) { last = p }, nil); err != nil {
		t.Fatal(err)
	}
	if last.Overall < 0.999 || last.Overall > 1.001 {
		t.Errorf("progresso final = %v", last.Overall)
	}
	adb := filepath.Join(s.Root, "platform-tools", "adb")
	st, err := os.Stat(adb)
	if err != nil || st.Mode()&0o111 == 0 {
		t.Fatalf("adb deveria existir e ser executável: %v %v", err, st)
	}
	if l, err := os.Readlink(filepath.Join(s.Root, "platform-tools", "adb-link")); err != nil || l != "adb" {
		t.Errorf("link simbólico perdido: %v %q", err, l)
	}
	in := s.InstalledMap()["platform-tools"]
	if in.Rev != "37.0.1" {
		t.Errorf("instalado: %+v", in)
	}
	// já instalado => nada a fazer; força => reinstala
	if p := s.PlanInstall(cat, []string{"platform-tools"}, false, false); len(p.Install) != 0 {
		t.Errorf("deveria estar em dia: %+v", p.Install)
	}
	// diretórios temporários limpos
	if _, err := os.Stat(filepath.Join(s.Root, ".downloadIntermediates")); err == nil {
		t.Error(".downloadIntermediates deveria ter sido removido")
	}
	if m, _ := filepath.Glob(filepath.Join(s.Root, "*.installing")); len(m) != 0 {
		t.Errorf("sobrou pasta temporária: %v", m)
	}
	if err := s.Uninstall([]string{"platform-tools"}); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(s.Root, "platform-tools")); err == nil {
		t.Error("platform-tools deveria ter sido removido")
	}
}

func TestInstallRejectsBadChecksum(t *testing.T) {
	zipBytes := makeZip(t, map[string]string{"platform-tools/adb": "x"}, nil)
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.ServeContent(w, r, "pt.zip", timeZero, bytes.NewReader(zipBytes))
	}))
	defer srv.Close()
	cat, _ := loadFixture(t)
	pt := cat.Find("platform-tools", false)
	pt.BaseURL = srv.URL + "/"
	for i := range pt.Archives {
		pt.Archives[i].Size = int64(len(zipBytes))
		pt.Archives[i].SHA1 = strings.Repeat("0", 40)
		pt.Archives[i].URL = "pt.zip"
	}
	s := SDK{Root: t.TempDir()}
	plan := s.PlanInstall(cat, []string{"platform-tools"}, false, false)
	for _, l := range plan.Licenses {
		_ = s.Accept(l)
	}
	err := s.Install(context.Background(), cat, plan, nil, nil)
	if err == nil || !strings.Contains(err.Error(), "checksum") {
		t.Fatalf("deveria falhar por checksum, veio %v", err)
	}
	if _, err := os.Stat(filepath.Join(s.Root, "platform-tools")); err == nil {
		t.Error("nada deveria ter sido instalado")
	}
}

func TestDownloadResumes(t *testing.T) {
	data := bytes.Repeat([]byte("0123456789"), 5000)
	var ranges []string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ranges = append(ranges, r.Header.Get("Range"))
		http.ServeContent(w, r, "f.bin", timeZero, bytes.NewReader(data))
	}))
	defer srv.Close()
	dest := filepath.Join(t.TempDir(), "f.bin")
	_ = os.WriteFile(dest+".part", data[:12345], 0o644) // download interrompido antes
	if err := downloadFile(context.Background(), srv.URL, dest, int64(len(data)), func(int64, int64) {}); err != nil {
		t.Fatal(err)
	}
	got, _ := os.ReadFile(dest)
	if !bytes.Equal(got, data) {
		t.Fatal("conteúdo diferente após retomar")
	}
	if len(ranges) != 1 || ranges[0] != "bytes=12345-" {
		t.Errorf("deveria retomar de 12345, ranges=%v", ranges)
	}
}

func TestUninstallRefusesEscapes(t *testing.T) {
	s := SDK{Root: t.TempDir()}
	for _, p := range []string{"", "..", "a;..;b", "../x"} {
		if err := s.Uninstall([]string{p}); err == nil {
			t.Errorf("deveria recusar %q", p)
		}
	}
}

func TestAPIName(t *testing.T) {
	for in, want := range map[string]string{"36": "Android 16", "36.1": "Android 16", "34x": "Android 14", "34-ext10": "Android 14", "99": ""} {
		if got := APIName(in, ""); got != want {
			t.Errorf("APIName(%q) = %q, quer %q", in, got, want)
		}
	}
}
