package sdk

import (
	"os"
	"path/filepath"
	"testing"
)

// SDKs com pastas movidas para outro disco (links simbólicos) precisam continuar
// sendo reconhecidos — inclusive quando a própria raiz do SDK é um link.
func TestListInstalledFollowsSymlinks(t *testing.T) {
	real := t.TempDir()
	imgs := filepath.Join(real, "big-disk-images")
	img := filepath.Join(imgs, "android-36", "google_apis", "x86_64")
	_ = os.MkdirAll(img, 0o755)
	cat, _ := loadFixture(t)
	r := cat.Find("system-images;android-36;google_apis_playstore;x86_64", false)
	r.Path = "system-images;android-36;google_apis;x86_64"
	_ = os.WriteFile(filepath.Join(img, "package.xml"), packageXML(r, License{}), 0o644)

	sdkDir := filepath.Join(real, "sdk")
	_ = os.MkdirAll(sdkDir, 0o755)
	_ = os.Symlink(imgs, filepath.Join(sdkDir, "system-images"))
	link := filepath.Join(t.TempDir(), "Sdk")
	if err := os.Symlink(sdkDir, link); err != nil {
		t.Skip("sem suporte a symlink")
	}
	got := SDK{Root: link}.ListInstalled()
	if len(got) != 1 || got[0].Path != "system-images;android-36;google_apis;x86_64" {
		t.Fatalf("instalados = %+v", got)
	}
}
