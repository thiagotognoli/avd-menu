package sdk

import (
	"bufio"
	"crypto/sha1"
	"encoding/hex"
	"os"
	"path/filepath"
	"regexp"
	"strings"
)

// License é um contrato que o usuário precisa aceitar antes de instalar pacotes.
type License struct {
	ID   string `json:"id"`
	Text string `json:"text"`
}

var multiSpace = regexp.MustCompile(` +`)

func isWS(b byte) bool {
	return b == ' ' || b == '\t' || b == '\n' || b == '\r' || b == '\f' || b == '\v'
}

// NormalizeLicense reproduz o TrimStringAdapter do sdklib do Google, que é o
// que o sdkmanager aplica ao texto antes de calcular o hash da licença:
//
//	replaceAll("(?<=\s)[ \t]*", "")   remove espaços depois de espaço/indentação
//	replaceAll("(?<!\n)\n(?!\n)", " ") junta linhas de um mesmo parágrafo
//	replaceAll(" +", " ")
//	trim()
func NormalizeLicense(s string) string {
	b := []byte(s)
	var step1 []byte
	for i, c := range b {
		if (c == ' ' || c == '\t') && i > 0 && isWS(b[i-1]) {
			continue
		}
		step1 = append(step1, c)
	}
	step2 := make([]byte, len(step1))
	for i, c := range step1 {
		if c == '\n' && (i == 0 || step1[i-1] != '\n') && (i == len(step1)-1 || step1[i+1] != '\n') {
			step2[i] = ' '
		} else {
			step2[i] = c
		}
	}
	out := multiSpace.ReplaceAllString(string(step2), " ")
	return strings.TrimFunc(out, func(r rune) bool { return r <= ' ' })
}

// Hash é o SHA-1 do texto normalizado — o mesmo valor que o sdkmanager grava
// em <sdk>/licenses/<id>, o que torna o aceite compatível com Android Studio.
func (l License) Hash() string {
	sum := sha1.Sum([]byte(NormalizeLicense(l.Text)))
	return hex.EncodeToString(sum[:])
}

func (s SDK) licenseFile(id string) string {
	return filepath.Join(s.Root, "licenses", filepath.Base(id))
}

// Accepted informa se a licença já foi aceita neste SDK.
func (s SDK) Accepted(l License) bool {
	f, err := os.Open(s.licenseFile(l.ID))
	if err != nil {
		return false
	}
	defer f.Close()
	want := l.Hash()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		if strings.TrimSpace(sc.Text()) == want {
			return true
		}
	}
	return false
}

// Accept grava o aceite da licença (preserva aceites anteriores de outras versões).
func (s SDK) Accept(l License) error {
	if s.Accepted(l) {
		return nil
	}
	if err := os.MkdirAll(filepath.Join(s.Root, "licenses"), 0o755); err != nil {
		return err
	}
	f, err := os.OpenFile(s.licenseFile(l.ID), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
	if err != nil {
		return err
	}
	defer f.Close()
	_, err = f.WriteString("\n" + l.Hash())
	return err
}
