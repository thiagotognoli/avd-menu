package emu

import (
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"syscall"
	"time"

	"avdmenu/internal/platform"
	"avdmenu/internal/sdk"
)

// Check é o resultado de uma verificação de ambiente. O texto exibido vem da
// interface (chaves diag.<id>.*); aqui só vão o identificador e os dados.
type Check struct {
	ID    string            `json:"id"`
	Level string            `json:"level"` // ok | warn | error | info
	Args  map[string]string `json:"args,omitempty"`
	Fix   string            `json:"fix,omitempty"` // comando sugerido
}

// Diagnose verifica o que o emulador precisa para rodar bem.
func Diagnose(s sdk.SDK) []Check {
	var out []Check
	add := func(id, level string, args map[string]string, fix string) {
		out = append(out, Check{ID: id, Level: level, Args: args, Fix: fix})
	}

	if s.Exists() {
		add("sdk", "ok", map[string]string{"path": s.Root}, "")
	} else {
		add("sdk", "warn", map[string]string{"path": s.Root}, "")
	}
	inst := s.InstalledMap()
	if e, ok := inst["emulator"]; ok || s.HasEmulator() {
		add("emulator", "ok", map[string]string{"version": e.Rev}, "")
	} else {
		add("emulator", "warn", nil, "")
	}
	if e, ok := inst["platform-tools"]; ok || s.HasAdb() {
		add("adb", "ok", map[string]string{"version": e.Rev}, "")
	} else {
		add("adb", "warn", nil, "")
	}

	if runtime.GOOS == "linux" && runtime.GOARCH != "amd64" {
		add("arch", "error", map[string]string{"arch": runtime.GOARCH}, "")
	}

	// Aceleração de hardware: KVM (Linux) ou Hypervisor.framework (macOS).
	out = append(out, checkAccel(s)...)

	if runtime.GOOS == "linux" && s.HasEmulator() {
		if missing := missingLibs(s); len(missing) > 0 {
			add("libs", "error", map[string]string{"libs": strings.Join(missing, ", ")}, installHint(missing))
		} else {
			add("libs", "ok", nil, "")
		}
	}

	if runtime.GOOS == "linux" {
		if gpus := ListGPUs(); len(gpus) > 0 {
			var names []string
			for _, g := range gpus {
				names = append(names, g.Name)
			}
			add("gpu", "info", map[string]string{"gpus": strings.Join(names, " · "), "count": strconv.Itoa(len(gpus))}, "")
		}
		if t := os.Getenv("XDG_SESSION_TYPE"); t != "" {
			add("session", "info", map[string]string{"type": t}, "")
		}
	}

	var st syscall.Statfs_t
	probe := s.Root
	if !s.Exists() {
		probe = platform.Home()
	}
	if syscall.Statfs(probe, &st) == nil {
		free := int64(st.Bavail) * int64(st.Bsize)
		lvl := "ok"
		if free < 8<<30 {
			lvl = "warn"
		}
		add("disk", lvl, map[string]string{"free": sdk.HumanBytes(free), "path": probe}, "")
	}
	return out
}

func checkAccel(s sdk.SDK) []Check {
	var out []Check
	chk := filepath.Join(s.Root, "emulator", "emulator-check")
	if platform.IsExecutable(chk) {
		ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
		defer cancel()
		b, _ := exec.CommandContext(ctx, chk, "accel").Output()
		lines := strings.Split(strings.TrimSpace(string(b)), "\n")
		// formato: accel: / <código> / <texto> / accel
		if len(lines) >= 3 {
			code := strings.TrimSpace(lines[1])
			msg := strings.TrimSpace(lines[2])
			if code == "0" {
				return []Check{{ID: "accel", Level: "ok", Args: map[string]string{"info": msg}}}
			}
			c := Check{ID: "accel", Level: "error", Args: map[string]string{"info": msg}}
			if runtime.GOOS == "linux" {
				c.Fix = kvmFix()
			}
			return []Check{c}
		}
	}
	// Sem o emulator-check (emulador ainda não instalado): checagem manual.
	if runtime.GOOS == "linux" {
		f, err := os.OpenFile("/dev/kvm", os.O_RDWR, 0)
		switch {
		case err == nil:
			f.Close()
			out = append(out, Check{ID: "accel", Level: "ok", Args: map[string]string{"info": "KVM (/dev/kvm)"}})
		case os.IsNotExist(err):
			out = append(out, Check{ID: "accel", Level: "error", Args: map[string]string{"info": platform.Tr("/dev/kvm não existe", "/dev/kvm does not exist")}, Fix: kvmFix()})
		default:
			out = append(out, Check{ID: "accel", Level: "error", Args: map[string]string{"info": platform.Tr("sem permissão em /dev/kvm", "no permission on /dev/kvm")}, Fix: kvmFix()})
		}
	} else if runtime.GOOS == "darwin" {
		b, _ := exec.Command("sysctl", "-n", "kern.hv_support").Output()
		if strings.TrimSpace(string(b)) == "1" {
			out = append(out, Check{ID: "accel", Level: "ok", Args: map[string]string{"info": "Hypervisor.framework"}})
		} else {
			out = append(out, Check{ID: "accel", Level: "error", Args: map[string]string{"info": platform.Tr("Hypervisor.framework indisponível", "Hypervisor.framework unavailable")}})
		}
	}
	return out
}

func kvmFix() string {
	if _, err := os.Stat("/dev/kvm"); err == nil {
		return "sudo usermod -aG kvm $USER   # depois saia da sessão e entre de novo"
	}
	return "sudo apt install qemu-kvm   # e habilite VT-x/AMD-V na BIOS"
}

// missingLibs roda o ldd nos binários do emulador com o mesmo
// LD_LIBRARY_PATH que o lançador usa, e devolve as bibliotecas ausentes.
func missingLibs(s sdk.SDK) []string {
	root := filepath.Join(s.Root, "emulator")
	ldpath := strings.Join([]string{
		filepath.Join(root, "lib64"), filepath.Join(root, "lib64", "qt", "lib"),
		filepath.Join(root, "lib64", "gles_angle"), filepath.Join(root, "lib64", "gles_swiftshader"),
		filepath.Join(root, "lib64", "vulkan"),
	}, ":")
	targets := []string{
		filepath.Join(root, "emulator"),
		filepath.Join(root, "lib64", "qt", "plugins", "platforms", "libqxcb.so"),
	}
	if m, _ := filepath.Glob(filepath.Join(root, "qemu", "linux-x86_64", "qemu-system-x86_64")); len(m) > 0 {
		targets = append(targets, m...)
	}
	set := map[string]bool{}
	for _, t := range targets {
		if !platform.FileExists(t) {
			continue
		}
		cmd := exec.Command("ldd", t)
		cmd.Env = append(os.Environ(), "LD_LIBRARY_PATH="+ldpath)
		b, err := cmd.Output()
		if err != nil && len(b) == 0 {
			continue
		}
		for _, line := range strings.Split(string(b), "\n") {
			if strings.Contains(line, "not found") {
				f := strings.Fields(line)
				if len(f) > 0 {
					set[f[0]] = true
				}
			}
		}
	}
	var out []string
	for l := range set {
		out = append(out, l)
	}
	sort.Strings(out)
	return out
}

// pacotes por família de distribuição para as bibliotecas mais comuns.
var libPackages = map[string][3]string{ // apt, dnf, pacman
	"libxcb-cursor.so.0":    {"libxcb-cursor0", "xcb-util-cursor", "xcb-util-cursor"},
	"libxcb-xinerama.so.0":  {"libxcb-xinerama0", "libxcb", "libxcb"},
	"libxkbfile.so.1":       {"libxkbfile1", "libxkbfile", "libxkbfile"},
	"libpulse.so.0":         {"libpulse0", "pulseaudio-libs", "libpulse"},
	"libnss3.so":            {"libnss3", "nss", "nss"},
	"libasound.so.2":        {"libasound2t64", "alsa-lib", "alsa-lib"},
	"libGL.so.1":            {"libgl1", "mesa-libGL", "mesa"},
	"libX11-xcb.so.1":       {"libx11-xcb1", "libX11-xcb", "libx11"},
	"libxcb-xkb.so.1":       {"libxcb-xkb1", "libxcb", "libxcb"},
	"libxkbcommon-x11.so.0": {"libxkbcommon-x11-0", "libxkbcommon-x11", "libxkbcommon-x11"},
	"libtinfo.so.5":         {"libtinfo5", "ncurses-compat-libs", "ncurses5-compat-libs"},
	"libbsd.so.0":           {"libbsd0", "libbsd", "libbsd"},
}

func installHint(libs []string) string {
	family := distroFamily()
	idx := map[string]int{"debian": 0, "fedora": 1, "arch": 2}[family]
	var pkgs []string
	for _, l := range libs {
		if p, ok := libPackages[l]; ok {
			pkgs = append(pkgs, p[idx])
		}
	}
	if len(pkgs) == 0 {
		return ""
	}
	switch family {
	case "fedora":
		return "sudo dnf install " + strings.Join(pkgs, " ")
	case "arch":
		return "sudo pacman -S " + strings.Join(pkgs, " ")
	}
	return "sudo apt install " + strings.Join(pkgs, " ")
}

func distroFamily() string {
	b, err := os.ReadFile("/etc/os-release")
	if err != nil {
		return "debian"
	}
	s := strings.ToLower(string(b))
	switch {
	case strings.Contains(s, "fedora"), strings.Contains(s, "rhel"), strings.Contains(s, "centos"), strings.Contains(s, "suse"):
		return "fedora"
	case strings.Contains(s, "arch"), strings.Contains(s, "manjaro"):
		return "arch"
	}
	return "debian"
}
