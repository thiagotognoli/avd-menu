package emu

import "testing"

func TestParsePS(t *testing.T) {
	out := `  101 /usr/lib/systemd/systemd --user
 2001 /home/u/Android/Sdk/emulator/qemu/linux-x86_64/qemu-system-x86_64-headless -avd Pixel_9_API_36 -netdelay none -netspeed full -ports 5554,5555
 2002 /home/u/Android/Sdk/emulator/crashpad_handler --database=/tmp/x
 3001 /home/u/Android/Sdk/emulator/emulator @Tablet_API_34 -no-snapshot
 3002 /home/u/Android/Sdk/emulator/qemu/darwin-aarch64/qemu-system-aarch64 -avd Mac_AVD -port 5580
 4001 grep -avd Fake
 5001 /usr/bin/emulator-check accel
 9999 /home/u/bin/avd-menu start Foo -avd Bar`
	got := parsePS(out, 9999)
	if len(got) != 3 {
		t.Fatalf("esperava 3 emuladores, veio %d: %+v", len(got), got)
	}
	p := got["Pixel_9_API_36"]
	if p.Port != 5554 || p.Serial != "emulator-5554" || len(p.PIDs) != 1 || p.PIDs[0] != 2001 {
		t.Errorf("Pixel: %+v", p)
	}
	if tab := got["Tablet_API_34"]; tab.Name != "Tablet_API_34" || tab.Port != 0 || tab.Serial != "" {
		t.Errorf("Tablet: %+v", tab)
	}
	if m := got["Mac_AVD"]; m.Port != 5580 {
		t.Errorf("Mac: %+v", m)
	}
}

func TestWMClass(t *testing.T) {
	if got := WMClass("Pixel_9 API.36"); got != "android-emulator-pixel-9-api-36" {
		t.Errorf("WMClass = %q", got)
	}
}

func TestParseLspciName(t *testing.T) {
	cases := map[string]string{
		`0000:12:00.0 "VGA compatible controller" "Advanced Micro Devices, Inc. [AMD/ATI]" "Navi 33 [Radeon RX 7600/7600 XT/7600M XT]" -rc1 "Device 1eae" "Device 7605"`: "AMD Radeon RX 7600",
		`01:00.0 "VGA compatible controller" "NVIDIA Corporation" "AD104 [GeForce RTX 4070]" -ra1`:                                                                       "NVIDIA GeForce RTX 4070",
		`00:02.0 "VGA compatible controller" "Intel Corporation" "Alder Lake-P GT2 [Iris Xe Graphics]" -r0c`:                                                             "Intel Iris Xe Graphics",
		`lixo`: "",
	}
	for in, want := range cases {
		if got := parseLspciName(in); got != want {
			t.Errorf("parseLspciName(%q) = %q, quer %q", in, got, want)
		}
	}
}

func TestInstallHint(t *testing.T) {
	if h := installHint([]string{"libxcb-cursor.so.0", "libdesconhecida.so"}); h == "" {
		t.Error("deveria sugerir um comando para libxcb-cursor")
	}
	if h := installHint([]string{"libdesconhecida.so"}); h != "" {
		t.Errorf("sem pacote conhecido não deveria sugerir nada: %q", h)
	}
}
