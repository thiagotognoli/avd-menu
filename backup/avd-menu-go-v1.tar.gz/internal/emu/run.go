// Package emu inicia, para e acompanha emuladores Android, além de diagnosticar
// o que costuma impedi-los de funcionar (KVM, bibliotecas, GPU).
package emu

import (
	"bufio"
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"syscall"
	"time"

	"avdmenu/internal/platform"
	"avdmenu/internal/sdk"
)

// Instance é um emulador em execução.
type Instance struct {
	Name   string `json:"name"`
	PIDs   []int  `json:"pids"`
	Port   int    `json:"port,omitempty"`   // porta do console (5554...)
	Serial string `json:"serial,omitempty"` // emulator-5554
}

var (
	avdArgRe = regexp.MustCompile(`(?:^|\s)-avd\s+(\S+)`)
	atArgRe  = regexp.MustCompile(`(?:^|\s)@(\S+)`)
	portsRe  = regexp.MustCompile(`(?:^|\s)-ports\s+(\d+),(\d+)`)
	portRe   = regexp.MustCompile(`(?:^|\s)-port\s+(\d+)`)
	psLineRe = regexp.MustCompile(`^\s*(\d+)\s+(.*)$`)
	emuBinRe = regexp.MustCompile(`(?:^|/)(emulator(?:64-\w+)?|qemu-system-[\w-]+)(?:\s|$)`)
)

// WMClass é o WM_CLASS/StartupWMClass usado para vincular a janela do emulador
// ao atalho do AVD no GNOME (mesmo valor que o atalho .desktop declara).
func WMClass(avdName string) string {
	return "android-emulator-" + platform.Slugify(avdName)
}

// Running lista os emuladores ativos (inclusive os iniciados pelo Android
// Studio ou por um terminal), agrupados por nome de AVD.
func Running() map[string]Instance {
	b, err := exec.Command("ps", "-axww", "-o", "pid=,args=").Output()
	if err != nil {
		return map[string]Instance{}
	}
	return parsePS(string(b), os.Getpid())
}

// parsePS interpreta a saída de `ps -axww -o pid=,args=`.
func parsePS(out string, self int) map[string]Instance {
	res := map[string]Instance{}
	sc := bufio.NewScanner(strings.NewReader(out))
	sc.Buffer(make([]byte, 1<<20), 1<<20)
	for sc.Scan() {
		m := psLineRe.FindStringSubmatch(sc.Text())
		if m == nil {
			continue
		}
		pid, _ := strconv.Atoi(m[1])
		args := m[2]
		fields := strings.Fields(args)
		if pid == self || len(fields) == 0 || !emuBinRe.MatchString(fields[0]+" ") {
			continue
		}
		name := ""
		if a := avdArgRe.FindStringSubmatch(args); a != nil {
			name = a[1]
		} else if a := atArgRe.FindStringSubmatch(args); a != nil {
			name = a[1]
		}
		if name == "" {
			continue
		}
		inst := res[name]
		inst.Name = name
		inst.PIDs = append(inst.PIDs, pid)
		if p := portsRe.FindStringSubmatch(args); p != nil {
			inst.Port, _ = strconv.Atoi(p[1])
		} else if p := portRe.FindStringSubmatch(args); p != nil {
			inst.Port, _ = strconv.Atoi(p[1])
		}
		if inst.Port > 0 {
			inst.Serial = "emulator-" + strconv.Itoa(inst.Port)
		}
		res[name] = inst
	}
	return res
}

// StartOptions controla como o emulador é iniciado.
type StartOptions struct {
	Mode      string   `json:"mode"`      // "" / "normal" | "cold" | "wipe"
	GPU       string   `json:"gpu"`       // "" (padrão) | "dedicated"
	Headless  bool     `json:"headless"`  // sem janela
	ExtraArgs []string `json:"extraArgs"` // argumentos livres
}

// LogPath é o arquivo de log da última execução do AVD.
func LogPath(name string) string {
	return filepath.Join(platform.StateDir(), "logs", name+".log")
}

// Start inicia o emulador do AVD, desacoplado do nosso processo (continua
// rodando se fecharmos o AVD Menu). Devolve o PID do lançador.
func Start(s sdk.SDK, name string, opt StartOptions) (int, error) {
	bin := s.Emulator()
	if !platform.IsExecutable(bin) {
		return 0, platform.Errorf("o emulador não está instalado em %s — instale o pacote \"Android Emulator\" no SDK Manager", "the emulator is not installed at %s — install the \"Android Emulator\" package in the SDK Manager", bin)
	}
	if _, ok := Running()[name]; ok {
		return 0, platform.Errorf("o emulador %q já está em execução", "emulator %q is already running", name)
	}
	args := []string{"-avd", name}
	switch opt.Mode {
	case "cold":
		args = append(args, "-no-snapshot-load")
	case "wipe":
		args = append(args, "-wipe-data")
	}
	if opt.Headless {
		args = append(args, "-no-window", "-no-audio")
	}
	args = append(args, opt.ExtraArgs...)

	env := []string{
		"ANDROID_SDK_ROOT=" + s.Root,
		"RESOURCE_NAME=" + WMClass(name),
	}
	if opt.GPU == "dedicated" {
		if e := DedicatedGPUEnv(); len(e) > 0 {
			env = append(env, e...)
		}
	}

	if err := os.MkdirAll(filepath.Dir(LogPath(name)), 0o755); err != nil {
		return 0, err
	}
	logf, err := os.OpenFile(LogPath(name), os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o644)
	if err != nil {
		return 0, err
	}
	fmt.Fprintf(logf, "$ %s %s\n", bin, strings.Join(args, " "))
	cmd := exec.Command(bin, args...)
	cmd.Env = platform.CleanEnv(env...)
	cmd.Dir = filepath.Dir(bin)
	cmd.Stdout = logf
	cmd.Stderr = logf
	cmd.SysProcAttr = &syscall.SysProcAttr{Setsid: true}
	if err := cmd.Start(); err != nil {
		logf.Close()
		return 0, err
	}
	done := make(chan error, 1)
	go func() {
		err := cmd.Wait()
		logf.Close()
		done <- err
	}()
	// Se morrer logo de cara, quase sempre é erro de configuração: mostra o log.
	select {
	case err := <-done:
		tail := strings.TrimSpace(ReadLogTail(name, 12))
		if err == nil {
			err = platform.Errorf("o emulador terminou imediatamente", "the emulator exited immediately")
		}
		return 0, fmt.Errorf("%v\n%s", err, tail)
	case <-time.After(2500 * time.Millisecond):
	}
	return cmd.Process.Pid, nil
}

// ReadLogTail devolve as últimas n linhas do log do AVD.
func ReadLogTail(name string, n int) string {
	b, err := os.ReadFile(LogPath(name))
	if err != nil {
		return ""
	}
	if len(b) > 256<<10 {
		b = b[len(b)-(256<<10):]
	}
	lines := strings.Split(strings.TrimRight(string(b), "\n"), "\n")
	if len(lines) > n {
		lines = lines[len(lines)-n:]
	}
	return strings.Join(lines, "\n")
}

// Stop pede ao emulador para desligar. Usa o console (adb emu kill) quando
// possível — o mesmo que o Android Studio faz — e cai para SIGTERM/SIGKILL.
func Stop(s sdk.SDK, name string) error {
	inst, ok := Running()[name]
	if !ok {
		return platform.Errorf("o emulador %q não está em execução", "emulator %q is not running", name)
	}
	if inst.Serial != "" && s.HasAdb() {
		ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
		defer cancel()
		if err := exec.CommandContext(ctx, s.Adb(), "-s", inst.Serial, "emu", "kill").Run(); err == nil {
			if waitGone(name, 12*time.Second) {
				return nil
			}
		}
	}
	for _, pid := range inst.PIDs {
		_ = syscall.Kill(pid, syscall.SIGTERM)
	}
	if waitGone(name, 10*time.Second) {
		return nil
	}
	for _, pid := range inst.PIDs {
		_ = syscall.Kill(pid, syscall.SIGKILL)
	}
	if waitGone(name, 5*time.Second) {
		return nil
	}
	return platform.Errorf("não consegui encerrar o emulador %q", "could not stop emulator %q", name)
}

func waitGone(name string, d time.Duration) bool {
	deadline := time.Now().Add(d)
	for time.Now().Before(deadline) {
		if _, ok := Running()[name]; !ok {
			return true
		}
		time.Sleep(400 * time.Millisecond)
	}
	return false
}
