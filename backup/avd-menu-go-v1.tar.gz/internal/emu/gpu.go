package emu

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"

	"avdmenu/internal/platform"
)

// GPU é uma placa de vídeo detectada.
type GPU struct {
	Node   string `json:"node"`   // renderD128
	Vendor string `json:"vendor"` // nvidia | amd | intel | other
	Driver string `json:"driver,omitempty"`
	Name   string `json:"name"`
}

// ListGPUs lista as GPUs com nó de renderização (Linux).
func ListGPUs() []GPU {
	nodes, _ := filepath.Glob("/sys/class/drm/renderD*")
	var out []GPU
	for _, n := range nodes {
		dev := filepath.Join(n, "device")
		g := GPU{Node: filepath.Base(n), Vendor: "other"}
		if b, err := os.ReadFile(filepath.Join(dev, "vendor")); err == nil {
			switch strings.TrimSpace(string(b)) {
			case "0x10de":
				g.Vendor = "nvidia"
			case "0x1002":
				g.Vendor = "amd"
			case "0x8086":
				g.Vendor = "intel"
			}
		}
		slot := ""
		if b, err := os.ReadFile(filepath.Join(dev, "uevent")); err == nil {
			for _, line := range strings.Split(string(b), "\n") {
				if v, ok := strings.CutPrefix(line, "DRIVER="); ok {
					g.Driver = v
				}
				if v, ok := strings.CutPrefix(line, "PCI_SLOT_NAME="); ok {
					slot = v
				}
			}
		}
		g.Name = strings.ToUpper(g.Vendor[:1]) + g.Vendor[1:]
		if slot != "" && platform.Which("lspci") != "" {
			if b, err := exec.Command("lspci", "-mm", "-s", slot).Output(); err == nil {
				if name := parseLspciName(string(b)); name != "" {
					g.Name = name
				}
			}
		}
		out = append(out, g)
	}
	return out
}

// parseLspciName extrai um nome curto ("AMD Radeon RX 7600") de uma linha de
// `lspci -mm`: campos entre aspas = classe, fabricante, dispositivo...
func parseLspciName(line string) string {
	var fields []string
	var cur strings.Builder
	inQ := false
	for _, r := range line {
		switch {
		case r == '"':
			inQ = !inQ
			if !inQ {
				fields = append(fields, cur.String())
				cur.Reset()
			}
		case inQ:
			cur.WriteRune(r)
		}
	}
	if len(fields) < 3 {
		return ""
	}
	vendor, dev := fields[1], fields[2]
	switch {
	case strings.Contains(vendor, "AMD"), strings.Contains(vendor, "Advanced Micro"):
		vendor = "AMD"
	case strings.Contains(vendor, "NVIDIA"):
		vendor = "NVIDIA"
	case strings.Contains(vendor, "Intel"):
		vendor = "Intel"
	}
	// "Navi 33 [Radeon RX 7600/7600 XT]" -> "Radeon RX 7600"
	if a, b := strings.LastIndex(dev, "["), strings.LastIndex(dev, "]"); a >= 0 && b > a {
		dev = dev[a+1 : b]
	}
	if k := strings.Index(dev, "/"); k > 0 {
		dev = dev[:k]
	}
	return strings.TrimSpace(vendor + " " + strings.TrimSpace(dev))
}

// DedicatedGPUEnv devolve as variáveis que fazem o OpenGL/Vulkan usar a GPU
// dedicada em notebooks híbridos, ou nil quando só há uma GPU (ou no macOS).
//
// O emulador já escolhe a GPU discreta para o Vulkan, mas o caminho OpenGL ES
// continua na GPU padrão (a integrada) — daí a diferença de desempenho. São as
// mesmas variáveis que o switcheroo-control usa. Não dá para juntar as duas
// famílias: em máquina AMD/Intel, definir __GLX_VENDOR_LIBRARY_NAME=nvidia faz
// o libglvnd procurar libGLX_nvidia.so.0 e quebrar o GLX.
func DedicatedGPUEnv() []string {
	if !platform.IsLinux() {
		return nil
	}
	gpus := ListGPUs()
	if len(gpus) < 2 {
		return nil
	}
	for _, g := range gpus {
		if g.Vendor == "nvidia" {
			return []string{"__NV_PRIME_RENDER_OFFLOAD=1", "__GLX_VENDOR_LIBRARY_NAME=nvidia", "__VK_LAYER_NV_optimus=NVIDIA_only"}
		}
	}
	return []string{"DRI_PRIME=1"}
}
