// Package devices contém as definições de hardware (Pixel, Nexus, Wear OS, TV,
// Automotive...) usadas para criar AVDs — as mesmas do Android Studio.
//
// O devices.json é gerado por tools/gen_devices.py a partir dos XMLs do sdklib
// (AOSP, Apache 2.0) e do próprio avdmanager, que serve de referência para as
// chaves hw.* de cada aparelho.
package devices

import (
	_ "embed"
	"encoding/json"
	"math"
	"regexp"
	"strconv"
	"strings"
	"sync"

	"avdmenu/internal/platform"
)

//go:embed devices.json
var raw []byte

// Device é um perfil de hardware.
type Device struct {
	ID           string             `json:"id"`
	Name         string             `json:"name"`
	Manufacturer string             `json:"manufacturer"`
	Category     string             `json:"category"` // phone, tablet, wear, tv, automotive, desktop, xr
	Deprecated   bool               `json:"deprecated,omitempty"`
	PlayStore    bool               `json:"playstore,omitempty"`
	Diag         float64            `json:"diag"`
	W            int                `json:"w"`
	H            int                `json:"h"`
	Density      int                `json:"density"`
	RAMMB        int                `json:"ramMB"`
	DeviceRAMMB  int                `json:"deviceRamMB,omitempty"`
	Sensors      []string           `json:"sensors,omitempty"`
	Front        bool               `json:"front,omitempty"`
	Back         bool               `json:"back,omitempty"`
	Foldable     bool               `json:"foldable,omitempty"`
	Round        bool               `json:"round,omitempty"`
	Skin         string             `json:"skin,omitempty"`
	Tags         []string           `json:"tags,omitempty"`
	ABIs         []string           `json:"abis,omitempty"`
	Cfg          map[string]*string `json:"cfg,omitempty"`
	User         bool               `json:"user,omitempty"`
}

type file struct {
	Defaults map[string]string `json:"defaults"`
	Devices  []Device          `json:"devices"`
}

var (
	once sync.Once
	data file
)

func load() {
	once.Do(func() {
		if err := json.Unmarshal(raw, &data); err != nil {
			panic("devices.json inválido: " + err.Error())
		}
	})
}

// Builtin devolve os dispositivos que acompanham o SDK.
func Builtin() []Device {
	load()
	out := make([]Device, len(data.Devices))
	copy(out, data.Devices)
	return out
}

// Defaults devolve o config.ini base que o avdmanager gera.
func Defaults() map[string]string {
	load()
	m := make(map[string]string, len(data.Defaults))
	for k, v := range data.Defaults {
		m[k] = v
	}
	return m
}

// All devolve os dispositivos embutidos e os criados pelo usuário.
func All() []Device {
	out := Builtin()
	out = append(out, Users()...)
	return out
}

// Get procura um dispositivo pelo ID.
func Get(id string) (Device, bool) {
	for _, d := range All() {
		if d.ID == id {
			return d, true
		}
	}
	return Device{}, false
}

// HWConfig devolve as chaves do config.ini que o dispositivo define
// (defaults + diferenças do aparelho).
func (d Device) HWConfig() map[string]string {
	m := Defaults()
	for k, v := range d.Cfg {
		if v == nil {
			delete(m, k)
		} else {
			m[k] = *v
		}
	}
	m["hw.device.name"] = d.ID
	if _, ok := m["hw.device.manufacturer"]; !ok || d.User {
		m["hw.device.manufacturer"] = d.Manufacturer
	}
	// A câmera do avdmanager é sempre "none" na frente; o Studio usa a
	// câmera emulada quando o aparelho tem, e a cena virtual na traseira.
	if d.Back {
		m["hw.camera.back"] = "virtualscene"
	} else {
		m["hw.camera.back"] = "none"
	}
	if d.Front {
		m["hw.camera.front"] = "emulated"
	} else {
		m["hw.camera.front"] = "none"
	}
	return m
}

// TagAllowed informa se uma imagem com esta tag (google_apis, android-wear...)
// serve para o dispositivo — o mesmo filtro da etapa "System Image" do Studio.
func (d Device) TagAllowed(tag string) bool {
	switch d.Category {
	case "wear":
		return strings.HasPrefix(tag, "android-wear")
	case "tv":
		return tag == "android-tv" || tag == "google-tv"
	case "automotive":
		if len(d.Tags) > 0 {
			for _, t := range d.Tags {
				if tag == t || strings.HasPrefix(tag, t) {
					return true
				}
			}
			return false
		}
		return strings.HasPrefix(tag, "android-automotive")
	case "desktop":
		return tag == "android-desktop"
	case "xr":
		return strings.Contains(tag, "xr") || strings.Contains(tag, "glasses")
	}
	// Celulares e tablets.
	switch tag {
	case "default", "google_apis", "google_apis_playstore", "google_atd", "aosp_atd",
		"google_apis_tablet", "aosp_tablet", "google_playstore_tablet", "android-desktop-phone":
		return true
	}
	return strings.HasPrefix(tag, "google_apis_playstore") || strings.HasPrefix(tag, "google_apis")
}

// ---- dispositivos do usuário ---------------------------------------------------

// Users devolve os perfis criados pelo usuário.
func Users() []Device {
	cfg := platform.LoadConfig()
	var out []Device
	for _, r := range cfg.UserDevices {
		var d Device
		if json.Unmarshal(r, &d) == nil && d.ID != "" {
			d.User = true
			out = append(out, d)
		}
	}
	return out
}

var idRe = regexp.MustCompile(`[^A-Za-z0-9_]+`)

// SaveUser valida e grava um perfil de hardware do usuário (novo ou existente).
func SaveUser(d Device) (Device, error) {
	d.Name = strings.TrimSpace(d.Name)
	if d.Name == "" {
		return d, platform.Errorf("informe um nome para o dispositivo", "enter a name for the device")
	}
	if d.W < 100 || d.H < 100 || d.W > 10000 || d.H > 10000 {
		return d, platform.Errorf("resolução inválida (%dx%d)", "invalid resolution (%dx%d)", d.W, d.H)
	}
	if d.Density < 100 || d.Density > 1000 {
		return d, platform.Errorf("densidade inválida (%d dpi)", "invalid density (%d dpi)", d.Density)
	}
	if d.RAMMB < 128 {
		d.RAMMB = 2048
	}
	if d.ID == "" {
		d.ID = "user_" + strings.Trim(idRe.ReplaceAllString(strings.ToLower(d.Name), "_"), "_")
	}
	for _, b := range Builtin() {
		if b.ID == d.ID {
			return d, platform.Errorf("já existe um dispositivo embutido com o ID %q", "a built-in device with ID %q already exists", d.ID)
		}
	}
	if d.Category == "" {
		d.Category = "phone"
	}
	if d.Manufacturer == "" {
		d.Manufacturer = "User"
	}
	if d.Diag <= 0 {
		// diagonal aproximada em polegadas a partir da resolução e densidade
		d.Diag = round2(math.Hypot(float64(d.W), float64(d.H)) / float64(d.Density))
	}
	d.User = true
	d.Cfg = map[string]*string{
		"hw.lcd.width":   sp(strconv.Itoa(d.W)),
		"hw.lcd.height":  sp(strconv.Itoa(d.H)),
		"hw.lcd.density": sp(strconv.Itoa(d.Density)),
		"hw.ramSize":     sp(strconv.Itoa(d.RAMMB)),
		"hw.sdCard":      sp("yes"),
	}
	d.Sensors = nil
	b, err := json.Marshal(d)
	if err != nil {
		return d, err
	}
	_, err = platform.UpdateConfig(func(c *platform.Config) {
		replaced := false
		for i, r := range c.UserDevices {
			var o Device
			if json.Unmarshal(r, &o) == nil && o.ID == d.ID {
				c.UserDevices[i] = b
				replaced = true
			}
		}
		if !replaced {
			c.UserDevices = append(c.UserDevices, b)
		}
	})
	return d, err
}

// DeleteUser remove um perfil do usuário.
func DeleteUser(id string) error {
	_, err := platform.UpdateConfig(func(c *platform.Config) {
		var keep []json.RawMessage
		for _, r := range c.UserDevices {
			var o Device
			if json.Unmarshal(r, &o) == nil && o.ID == id {
				continue
			}
			keep = append(keep, r)
		}
		c.UserDevices = keep
	})
	return err
}

func sp(s string) *string { return &s }

func round2(f float64) float64 { return math.Round(f*100) / 100 }
