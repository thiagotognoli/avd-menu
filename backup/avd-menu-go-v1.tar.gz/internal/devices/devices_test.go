package devices

import (
	"testing"

	"avdmenu/internal/platform"
)

func TestBuiltinCatalog(t *testing.T) {
	all := Builtin()
	if len(all) < 80 {
		t.Fatalf("poucos dispositivos: %d", len(all))
	}
	seen := map[string]bool{}
	for _, d := range all {
		if d.ID == "" || d.Name == "" || d.W <= 0 || d.H <= 0 || d.Density <= 0 || d.Category == "" {
			t.Errorf("dispositivo incompleto: %+v", d)
		}
		if seen[d.ID] {
			t.Errorf("ID repetido: %s", d.ID)
		}
		seen[d.ID] = true
	}
	p9, ok := Get("pixel_9")
	if !ok || p9.W != 1080 || p9.H != 2424 || p9.Density != 420 || !p9.PlayStore || p9.Category != "phone" {
		t.Fatalf("pixel_9: %+v", p9)
	}
}

func TestHWConfig(t *testing.T) {
	d, _ := Get("pixel_9")
	cfg := d.HWConfig()
	for k, want := range map[string]string{"hw.lcd.width": "1080", "hw.lcd.height": "2424", "hw.lcd.density": "420", "hw.device.name": "pixel_9", "hw.camera.back": "virtualscene", "hw.camera.front": "emulated"} {
		if cfg[k] != want {
			t.Errorf("%s = %q, quer %q", k, cfg[k], want)
		}
	}
	fold, _ := Get("pixel_9_pro_fold")
	if fc := fold.HWConfig(); fc["hw.sensor.hinge"] != "yes" || fc["hw.sensor.hinge.count"] != "1" {
		t.Errorf("dobradiça do fold: %v", fc["hw.sensor.hinge"])
	}
	// o config base não pode ser alterado por quem consome o resultado
	cfg["hw.lcd.width"] = "1"
	if Defaults()["hw.lcd.width"] == "1" {
		t.Error("Defaults() devolveu o mapa interno")
	}
}

func TestTagAllowed(t *testing.T) {
	phone, _ := Get("pixel_9")
	wear, _ := Get("wearos_small_round")
	tv, _ := Get("tv_1080p")
	auto, _ := Get("automotive_1024p_landscape")
	cases := []struct {
		d    Device
		tag  string
		want bool
	}{
		{phone, "google_apis", true}, {phone, "google_apis_playstore", true}, {phone, "default", true}, {phone, "google_apis_ps16k", true},
		{phone, "android-wear", false}, {phone, "android-tv", false}, {phone, "android-automotive", false},
		{wear, "android-wear", true}, {wear, "android-wear-signed", true}, {wear, "google_apis", false},
		{tv, "android-tv", true}, {tv, "google-tv", true}, {tv, "google_apis", false},
		{auto, "android-automotive-playstore", true}, {auto, "google_apis", false},
	}
	for _, c := range cases {
		if got := c.d.TagAllowed(c.tag); got != c.want {
			t.Errorf("%s com %s = %v, quer %v", c.d.ID, c.tag, got, c.want)
		}
	}
}

func TestUserDevices(t *testing.T) {
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	t.Setenv("HOME", t.TempDir())
	_ = platform.LoadConfig()
	d, err := SaveUser(Device{Name: "Meu Aparelho", W: 1000, H: 2000, Density: 400, RAMMB: 3072, PlayStore: true})
	if err != nil {
		t.Fatal(err)
	}
	if d.ID != "user_meu_aparelho" || !d.User || d.Diag < 5 || d.Diag > 6 {
		t.Errorf("salvo: %+v", d)
	}
	got, ok := Get(d.ID)
	if !ok || got.HWConfig()["hw.ramSize"] != "3072" || got.HWConfig()["hw.lcd.width"] != "1000" {
		t.Errorf("recarregado: %+v %v", got, got.HWConfig())
	}
	if _, err := SaveUser(Device{Name: "", W: 1000, H: 2000, Density: 400}); err == nil {
		t.Error("nome vazio deveria falhar")
	}
	if _, err := SaveUser(Device{Name: "x", W: 10, H: 2000, Density: 400}); err == nil {
		t.Error("resolução inválida deveria falhar")
	}
	if _, err := SaveUser(Device{ID: "pixel_9", Name: "x", W: 1000, H: 2000, Density: 400}); err == nil {
		t.Error("ID de dispositivo embutido deveria falhar")
	}
	if err := DeleteUser(d.ID); err != nil {
		t.Fatal(err)
	}
	if _, ok := Get(d.ID); ok {
		t.Error("deveria ter sido removido")
	}
}
