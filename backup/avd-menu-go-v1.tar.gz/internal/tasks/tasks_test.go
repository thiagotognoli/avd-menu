package tasks

import (
	"context"
	"errors"
	"sync"
	"testing"
	"time"
)

func waitState(t *testing.T, m *Manager, id string, want State) Task {
	t.Helper()
	deadline := time.Now().Add(3 * time.Second)
	for time.Now().Before(deadline) {
		for _, tk := range m.List() {
			if tk.ID == id && tk.State == want {
				return tk
			}
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatalf("tarefa %s não chegou ao estado %s: %+v", id, want, m.List())
	return Task{}
}

func TestSuccessFailureAndPanic(t *testing.T) {
	var mu sync.Mutex
	var events []State
	m := New(func(tk Task) { mu.Lock(); events = append(events, tk.State); mu.Unlock() })

	ok := m.Start("install", "ok", []string{"a"}, false, func(ctx context.Context, h *Handle) error {
		h.Progress(0.5, "download", "x", 5, 10)
		h.Logf("linha %d", 1)
		return nil
	})
	done := waitState(t, m, ok.ID, Done)
	if done.Progress != 1 || len(done.Log) != 1 || done.Log[0] != "linha 1" || done.Paths[0] != "a" {
		t.Errorf("tarefa concluída: %+v", done)
	}

	bad := m.Start("install", "bad", nil, false, func(ctx context.Context, h *Handle) error { return errors.New("falhou") })
	if tk := waitState(t, m, bad.ID, Failed); tk.Err != "falhou" {
		t.Errorf("erro = %q", tk.Err)
	}

	pn := m.Start("install", "panic", nil, false, func(ctx context.Context, h *Handle) error { panic("boom") })
	if tk := waitState(t, m, pn.ID, Failed); tk.Err == "" {
		t.Error("pânico deveria virar erro")
	}
	mu.Lock()
	defer mu.Unlock()
	if len(events) < 6 {
		t.Errorf("poucos eventos: %v", events)
	}
}

func TestSerialQueueAndCancel(t *testing.T) {
	m := New(nil)
	release := make(chan struct{})
	first := m.Start("install", "primeira", nil, true, func(ctx context.Context, h *Handle) error {
		select {
		case <-release:
			return nil
		case <-ctx.Done():
			return ctx.Err()
		}
	})
	waitState(t, m, first.ID, Running)
	second := m.Start("install", "segunda", nil, true, func(ctx context.Context, h *Handle) error { return nil })
	time.Sleep(50 * time.Millisecond)
	for _, tk := range m.List() {
		if tk.ID == second.ID && tk.State != Queued {
			t.Fatalf("a segunda deveria esperar na fila, estado %s", tk.State)
		}
	}
	if !m.Active() {
		t.Error("Active deveria ser verdadeiro")
	}
	close(release)
	waitState(t, m, first.ID, Done)
	waitState(t, m, second.ID, Done)

	third := m.Start("install", "terceira", nil, false, func(ctx context.Context, h *Handle) error {
		<-ctx.Done()
		return ctx.Err()
	})
	waitState(t, m, third.ID, Running)
	if !m.Cancel(third.ID) || m.Cancel("nao-existe") {
		t.Error("Cancel devolveu valores inesperados")
	}
	waitState(t, m, third.ID, Canceled)
	m.Clear()
	if len(m.List()) != 0 {
		t.Errorf("Clear deveria limpar: %+v", m.List())
	}
}
