// Package tasks executa operações demoradas (downloads, instalações) em segundo
// plano e publica o andamento para a interface.
package tasks

import (
	"avdmenu/internal/platform"
	"context"
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"sync"
	"time"
)

// State é a situação de uma tarefa.
type State string

const (
	Queued   State = "queued"
	Running  State = "running"
	Done     State = "done"
	Failed   State = "error"
	Canceled State = "canceled"
)

// Task é o retrato (serializável) de uma tarefa.
type Task struct {
	ID       string    `json:"id"`
	Kind     string    `json:"kind"`
	Title    string    `json:"title"`
	Paths    []string  `json:"paths,omitempty"` // pacotes do SDK envolvidos
	State    State     `json:"state"`
	Progress float64   `json:"progress"` // 0..1
	Phase    string    `json:"phase,omitempty"`
	Detail   string    `json:"detail,omitempty"`
	Done     int64     `json:"done,omitempty"`
	Total    int64     `json:"total,omitempty"`
	Err      string    `json:"error,omitempty"`
	Log      []string  `json:"log,omitempty"`
	Started  time.Time `json:"started"`
	Ended    time.Time `json:"ended,omitempty"`
}

type entry struct {
	t      Task
	cancel context.CancelFunc
}

// Manager guarda as tarefas e notifica mudanças.
type Manager struct {
	mu       sync.Mutex
	tasks    map[string]*entry
	order    []string
	notify   func(Task)
	serial   sync.Mutex // tarefas "serial" rodam uma por vez
	lastSent map[string]time.Time
}

// New cria um gerenciador; notify é chamado a cada mudança relevante.
func New(notify func(Task)) *Manager {
	return &Manager{tasks: map[string]*entry{}, notify: notify, lastSent: map[string]time.Time{}}
}

// Handle é o que a função da tarefa usa para reportar andamento.
type Handle struct {
	m  *Manager
	id string
}

func newID() string {
	b := make([]byte, 6)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}

// Start dispara a tarefa em segundo plano. Com serial=true ela espera as
// outras tarefas seriais terminarem (instalações no SDK não podem se misturar).
func (m *Manager) Start(kind, title string, paths []string, serial bool, fn func(ctx context.Context, h *Handle) error) Task {
	ctx, cancel := context.WithCancel(context.Background())
	id := newID()
	e := &entry{t: Task{ID: id, Kind: kind, Title: title, Paths: paths, State: Queued, Started: time.Now()}, cancel: cancel}
	m.mu.Lock()
	m.tasks[id] = e
	m.order = append(m.order, id)
	snap := e.t
	m.mu.Unlock()
	m.publish(snap, true)

	go func() {
		if serial {
			m.serial.Lock()
			defer m.serial.Unlock()
		}
		if ctx.Err() != nil {
			m.finish(id, ctx.Err())
			return
		}
		m.update(id, func(t *Task) { t.State = Running }, true)
		h := &Handle{m: m, id: id}
		err := func() (err error) {
			defer func() {
				if r := recover(); r != nil {
					err = platform.Errorf("erro interno: %v", "internal error: %v", r)
				}
			}()
			return fn(ctx, h)
		}()
		m.finish(id, err)
	}()
	return snap
}

func (m *Manager) finish(id string, err error) {
	m.update(id, func(t *Task) {
		t.Ended = time.Now()
		switch {
		case err == nil:
			t.State = Done
			t.Progress = 1
		case err == context.Canceled:
			t.State = Canceled
		default:
			t.State = Failed
			t.Err = err.Error()
			t.Log = appendLog(t.Log, "ERRO: "+err.Error())
		}
	}, true)
}

func appendLog(l []string, s string) []string {
	l = append(l, s)
	if len(l) > 300 {
		l = l[len(l)-300:]
	}
	return l
}

func (m *Manager) update(id string, fn func(*Task), force bool) {
	m.mu.Lock()
	e, ok := m.tasks[id]
	if !ok {
		m.mu.Unlock()
		return
	}
	fn(&e.t)
	snap := e.t
	snap.Log = append([]string(nil), e.t.Log...)
	m.mu.Unlock()
	m.publish(snap, force)
}

func (m *Manager) publish(t Task, force bool) {
	if m.notify == nil {
		return
	}
	m.mu.Lock()
	last := m.lastSent[t.ID]
	if !force && time.Since(last) < 200*time.Millisecond {
		m.mu.Unlock()
		return
	}
	m.lastSent[t.ID] = time.Now()
	m.mu.Unlock()
	m.notify(t)
}

// Progress atualiza o andamento geral (0..1) e os detalhes.
func (h *Handle) Progress(frac float64, phase, detail string, done, total int64) {
	h.m.update(h.id, func(t *Task) {
		if frac > 1 {
			frac = 1
		}
		if frac >= 0 {
			t.Progress = frac
		}
		t.Phase, t.Detail, t.Done, t.Total = phase, detail, done, total
	}, false)
}

// Logf acrescenta uma linha ao log da tarefa.
func (h *Handle) Logf(format string, a ...any) {
	line := fmt.Sprintf(format, a...)
	h.m.update(h.id, func(t *Task) { t.Log = appendLog(t.Log, line) }, true)
}

// Cancel pede o cancelamento de uma tarefa.
func (m *Manager) Cancel(id string) bool {
	m.mu.Lock()
	e, ok := m.tasks[id]
	m.mu.Unlock()
	if !ok {
		return false
	}
	e.cancel()
	return true
}

// List devolve as tarefas em ordem de criação (as 50 mais recentes).
func (m *Manager) List() []Task {
	m.mu.Lock()
	defer m.mu.Unlock()
	start := 0
	if len(m.order) > 50 {
		start = len(m.order) - 50
	}
	out := make([]Task, 0, len(m.order)-start)
	for _, id := range m.order[start:] {
		t := m.tasks[id].t
		t.Log = append([]string(nil), t.Log...)
		out = append(out, t)
	}
	return out
}

// Clear remove as tarefas já terminadas.
func (m *Manager) Clear() {
	m.mu.Lock()
	defer m.mu.Unlock()
	var keep []string
	for _, id := range m.order {
		e := m.tasks[id]
		if e.t.State == Queued || e.t.State == Running {
			keep = append(keep, id)
		} else {
			delete(m.tasks, id)
			delete(m.lastSent, id)
		}
	}
	m.order = keep
}

// Active informa se há tarefas em andamento.
func (m *Manager) Active() bool {
	m.mu.Lock()
	defer m.mu.Unlock()
	for _, e := range m.tasks {
		if e.t.State == Queued || e.t.State == Running {
			return true
		}
	}
	return false
}
