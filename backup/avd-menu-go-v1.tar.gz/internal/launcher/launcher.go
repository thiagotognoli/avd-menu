// Package launcher abre a interface do AVD Menu numa janela própria (modo
// "aplicativo" de um navegador Chromium, se houver) ou no navegador padrão.
package launcher

import (
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"

	"avdmenu/internal/platform"
)

// WMClass é o WM_CLASS das janelas abertas em modo aplicativo (Linux); o
// atalho do AVD Menu declara o mesmo valor em StartupWMClass.
const WMClass = "AvdMenu"

// chromium candidates
var linuxChromes = []string{
	"google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "microsoft-edge",
	"microsoft-edge-stable", "brave-browser", "brave", "vivaldi", "vivaldi-stable", "opera",
	"/snap/bin/chromium", "/opt/google/chrome/chrome", "/usr/bin/chrome",
}

var macChromes = []string{
	"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
	"/Applications/Chromium.app/Contents/MacOS/Chromium",
	"/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
	"/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
	"/Applications/Vivaldi.app/Contents/MacOS/Vivaldi",
	"/Applications/Arc.app/Contents/MacOS/Arc",
}

func findChromium() string {
	if p := os.Getenv("AVDMENU_BROWSER"); p != "" {
		return p
	}
	if runtime.GOOS == "darwin" {
		home := platform.Home()
		for _, c := range macChromes {
			if platform.IsExecutable(c) {
				return c
			}
			if alt := filepath.Join(home, c); platform.IsExecutable(alt) {
				return alt
			}
		}
		return ""
	}
	for _, c := range linuxChromes {
		if strings.HasPrefix(c, "/") {
			if platform.IsExecutable(c) {
				return c
			}
			continue
		}
		if p := platform.Which(c); p != "" {
			return p
		}
	}
	// Flatpak
	if platform.Which("flatpak") != "" {
		for _, id := range []string{"com.google.Chrome", "org.chromium.Chromium", "com.brave.Browser", "com.microsoft.Edge"} {
			if exec.Command("flatpak", "info", id).Run() == nil {
				return "flatpak:" + id
			}
		}
	}
	return ""
}

// Open abre url numa janela de aplicativo. Devolve o nome do método usado.
func Open(url string) (string, error) {
	if os.Getenv("AVDMENU_NO_BROWSER") != "" {
		return "none", nil
	}
	if b := findChromium(); b != "" {
		flags := []string{
			"--app=" + url,
			"--no-first-run", "--no-default-browser-check",
			"--window-size=1240,820",
			"--disable-features=Translate,MediaRouter",
			"--class=" + WMClass, "--name=" + WMClass,
		}
		// Um perfil próprio isola a janela do navegador do dia a dia, mas
		// browsers em snap/flatpak não conseguem usar pastas ocultas do HOME.
		resolved := b
		if r, err := filepath.EvalSymlinks(b); err == nil {
			resolved = r
		}
		if !strings.HasPrefix(b, "flatpak:") && !strings.Contains(resolved, "/snap/") {
			profile := filepath.Join(platform.CacheDir(), "browser-profile")
			_ = os.MkdirAll(profile, 0o755)
			flags = append(flags, "--user-data-dir="+profile)
		}
		var cmd *exec.Cmd
		if strings.HasPrefix(b, "flatpak:") {
			args := append([]string{"run", strings.TrimPrefix(b, "flatpak:")}, flags...)
			cmd = exec.Command("flatpak", args...)
		} else {
			cmd = exec.Command(b, flags...)
		}
		cmd.Env = platform.CleanEnv()
		cmd.SysProcAttr = &syscall.SysProcAttr{Setsid: true}
		if err := cmd.Start(); err == nil {
			go cmd.Wait()
			return "app:" + filepath.Base(b), nil
		}
	}
	return openDefault(url)
}

func openDefault(url string) (string, error) {
	var candidates [][]string
	if runtime.GOOS == "darwin" {
		candidates = [][]string{{"open", url}}
	} else {
		candidates = [][]string{{"xdg-open", url}, {"gio", "open", url}, {"sensible-browser", url}, {"x-www-browser", url}, {"firefox", url}}
	}
	for _, c := range candidates {
		p := platform.Which(c[0])
		if p == "" {
			continue
		}
		cmd := exec.Command(p, c[1:]...)
		cmd.Env = platform.CleanEnv()
		cmd.SysProcAttr = &syscall.SysProcAttr{Setsid: true}
		if err := cmd.Start(); err == nil {
			go cmd.Wait()
			return "browser:" + c[0], nil
		}
	}
	return "", platform.Errorf("não encontrei um navegador; abra manualmente: %s", "no browser found; open this manually: %s", url)
}

// OpenPath abre um arquivo ou pasta no gerenciador de arquivos.
func OpenPath(p string) error {
	name := "xdg-open"
	if runtime.GOOS == "darwin" {
		name = "open"
	}
	bin := platform.Which(name)
	if bin == "" {
		return platform.Errorf("%s não encontrado", "%s not found", name)
	}
	cmd := exec.Command(bin, p)
	cmd.Env = platform.CleanEnv()
	cmd.SysProcAttr = &syscall.SysProcAttr{Setsid: true}
	if err := cmd.Start(); err != nil {
		return err
	}
	go cmd.Wait()
	return nil
}
