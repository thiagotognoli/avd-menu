package shortcut

import (
	"bytes"
	"encoding/binary"
	"image"
	"image/color"
	"image/png"
	"math"
)

// Resize reamostra img para size x size (filtro de área ao reduzir, bilinear ao
// ampliar). Basta para ícones; evita depender de bibliotecas externas.
func Resize(src image.Image, size int) *image.NRGBA {
	b := src.Bounds()
	sw, sh := b.Dx(), b.Dy()
	dst := image.NewNRGBA(image.Rect(0, 0, size, size))
	fx, fy := float64(sw)/float64(size), float64(sh)/float64(size)
	for y := 0; y < size; y++ {
		for x := 0; x < size; x++ {
			x0, x1 := float64(x)*fx, float64(x+1)*fx
			y0, y1 := float64(y)*fy, float64(y+1)*fy
			var r, g, bl, a, wsum float64
			for sy := int(math.Floor(y0)); sy < int(math.Ceil(y1)) && sy < sh; sy++ {
				wy := math.Min(y1, float64(sy+1)) - math.Max(y0, float64(sy))
				for sx := int(math.Floor(x0)); sx < int(math.Ceil(x1)) && sx < sw; sx++ {
					wx := math.Min(x1, float64(sx+1)) - math.Max(x0, float64(sx))
					w := wx * wy
					c := color.NRGBAModel.Convert(src.At(b.Min.X+sx, b.Min.Y+sy)).(color.NRGBA)
					pa := float64(c.A) * w
					r += float64(c.R) * pa
					g += float64(c.G) * pa
					bl += float64(c.B) * pa
					a += pa
					wsum += w
				}
			}
			if a > 0 && wsum > 0 {
				dst.SetNRGBA(x, y, color.NRGBA{
					R: uint8(r/a + 0.5), G: uint8(g/a + 0.5), B: uint8(bl/a + 0.5), A: uint8(a/wsum + 0.5),
				})
			}
		}
	}
	return dst
}

// ICNS converte um PNG em um arquivo .icns (formato de ícone do macOS) com os
// tamanhos 16 a 1024 px.
func ICNS(pngData []byte) ([]byte, error) {
	src, err := png.Decode(bytes.NewReader(pngData))
	if err != nil {
		return nil, err
	}
	types := []struct {
		kind string
		size int
	}{
		{"icp4", 16}, {"icp5", 32}, {"icp6", 64}, {"ic07", 128},
		{"ic08", 256}, {"ic09", 512}, {"ic10", 1024},
	}
	var body bytes.Buffer
	for _, t := range types {
		var enc bytes.Buffer
		if err := png.Encode(&enc, Resize(src, t.size)); err != nil {
			return nil, err
		}
		body.WriteString(t.kind)
		_ = binary.Write(&body, binary.BigEndian, uint32(enc.Len()+8))
		body.Write(enc.Bytes())
	}
	var out bytes.Buffer
	out.WriteString("icns")
	_ = binary.Write(&out, binary.BigEndian, uint32(body.Len()+8))
	out.Write(body.Bytes())
	return out.Bytes(), nil
}
