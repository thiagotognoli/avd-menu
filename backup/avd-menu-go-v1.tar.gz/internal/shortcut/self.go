package shortcut

import (
	"os"
	"path/filepath"
	"runtime"
	"time"

	"avdmenu/internal/assets"
	"avdmenu/internal/platform"
)

func timeNow() time.Time { return time.Now() }

// SelfID é o identificador do atalho do próprio AVD Menu.
const SelfID = "avd-menu"

// SelfWMClass é o WM_CLASS da janela do aplicativo (ver launcher).
const SelfWMClass = "AvdMenu"

// SelfInfo informa se o AVD Menu está no menu de aplicativos.
func SelfInfo() Info {
	if runtime.GOOS != "linux" {
		return Info{}
	}
	p := filepath.Join(appsDir(), SelfID+".desktop")
	if !platform.FileExists(p) {
		return Info{}
	}
	return Info{Exists: true, Path: p, DisplayName: desktopValue(p, "Name")}
}

// InstallSelf adiciona o AVD Menu ao menu de aplicativos (Linux). No macOS o
// usuário arrasta o .app para a pasta Aplicativos.
func InstallSelf() (Result, error) {
	if runtime.GOOS != "linux" {
		return Result{}, platform.Errorf("no macOS, arraste o AVD Menu para a pasta Aplicativos", "on macOS, drag AVD Menu to the Applications folder")
	}
	iconName, err := installIcon(iconSource{Data: assets.IconSVG, Ext: "svg"}, SelfID)
	if err != nil {
		return Result{}, err
	}
	exe := platform.Exe()
	content := "[Desktop Entry]\n" +
		"Version=1.0\nType=Application\n" +
		"Name=AVD Menu\n" +
		"GenericName=Android Virtual Devices\n" +
		"Comment=Create, start and manage Android emulators\n" +
		"Comment[pt]=Crie, inicie e gerencie emuladores Android\n" +
		"Comment[pt_BR]=Crie, inicie e gerencie emuladores Android\n" +
		"Exec=" + execQuote(exe) + " ui\n" +
		"Icon=" + iconName + "\n" +
		"Terminal=false\n" +
		"Categories=Development;IDE;\n" +
		"Keywords=android;emulator;avd;sdk;device manager;emulador;\n" +
		"StartupNotify=false\n" +
		"StartupWMClass=" + SelfWMClass + "\n"
	if err := os.MkdirAll(appsDir(), 0o755); err != nil {
		return Result{}, err
	}
	p := filepath.Join(appsDir(), SelfID+".desktop")
	if err := os.WriteFile(p, []byte(content), 0o644); err != nil {
		return Result{}, err
	}
	validate(p)
	refreshCaches()
	return Result{Path: p, DisplayName: "AVD Menu", Icon: iconName}, nil
}

// UninstallSelf remove o AVD Menu do menu de aplicativos.
func UninstallSelf() error {
	p := filepath.Join(appsDir(), SelfID+".desktop")
	if !platform.FileExists(p) {
		return platform.Errorf("o AVD Menu não está instalado no menu", "AVD Menu is not installed in the menu")
	}
	_ = os.Remove(p)
	_ = os.Remove(filepath.Join(iconsDir(), "scalable", "apps", SelfID+".svg"))
	refreshCaches()
	return nil
}
