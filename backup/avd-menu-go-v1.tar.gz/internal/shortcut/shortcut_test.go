package shortcut

import (
	"avdmenu/internal/assets"
	"bytes"
	"encoding/base64"
	"encoding/binary"
	"image"
	"image/color"
	"image/png"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"

	"avdmenu/internal/avd"
	"avdmenu/internal/sdk"
)

func TestExecQuote(t *testing.T) {
	cases := map[string]string{
		"simple":          "simple",
		"/opt/My SDK/emu": `"/opt/My SDK/emu"`,
		"100%":            "100%%",
		`a"b`:             `"a\"b"`,
		"$HOME":           `"\$HOME"`,
		"":                `""`,
	}
	for in, want := range cases {
		if got := execQuote(in); got != want {
			t.Errorf("execQuote(%q) = %q, quer %q", in, got, want)
		}
	}
}

func TestICNS(t *testing.T) {
	img := image.NewNRGBA(image.Rect(0, 0, 64, 64))
	for y := 0; y < 64; y++ {
		for x := 0; x < 64; x++ {
			img.Set(x, y, color.NRGBA{R: 61, G: 220, B: 132, A: 255})
		}
	}
	var buf bytes.Buffer
	_ = png.Encode(&buf, img)
	out, err := ICNS(buf.Bytes())
	if err != nil {
		t.Fatal(err)
	}
	if string(out[:4]) != "icns" || int(binary.BigEndian.Uint32(out[4:8])) != len(out) {
		t.Fatalf("cabeçalho icns inválido")
	}
	for _, tag := range []string{"icp4", "icp5", "icp6", "ic07", "ic08", "ic09", "ic10"} {
		if !bytes.Contains(out, []byte(tag)) {
			t.Errorf("faltou o tipo %s", tag)
		}
	}
}

func TestResizeKeepsAlpha(t *testing.T) {
	src := image.NewNRGBA(image.Rect(0, 0, 4, 4))
	src.Set(0, 0, color.NRGBA{R: 255, A: 255})
	out := Resize(src, 2)
	if out.NRGBAAt(0, 0).A == 0 || out.NRGBAAt(1, 1).A != 0 {
		t.Errorf("alpha incorreto: %v %v", out.NRGBAAt(0, 0), out.NRGBAAt(1, 1))
	}
}

func TestCreateAndRemoveLinux(t *testing.T) {
	if runtime.GOOS != "linux" {
		t.Skip("somente Linux")
	}
	data := t.TempDir()
	t.Setenv("XDG_DATA_HOME", data)
	t.Setenv("HOME", t.TempDir())
	t.Setenv("ANDROID_AVD_HOME", filepath.Join(t.TempDir(), "avd"))
	t.Setenv("PATH", "/usr/bin:/bin") // sem gsettings de verdade

	// SDK falso com emulador e um AVD
	root := t.TempDir()
	_ = os.MkdirAll(filepath.Join(root, "emulator"), 0o755)
	_ = os.WriteFile(filepath.Join(root, "emulator", "emulator"), []byte("#!/bin/sh\n"), 0o755)
	img := filepath.Join(root, "system-images", "android-36", "google_apis", "x86_64")
	_ = os.MkdirAll(img, 0o755)
	_ = os.WriteFile(filepath.Join(img, "source.properties"), []byte("SystemImage.TagId=google_apis\nSystemImage.Abi=x86_64\nAndroidVersion.ApiLevel=36\n"), 0o644)
	s := sdk.SDK{Root: root}
	if _, err := avd.Create(s, avd.CreateSpec{Name: "My_AVD", DeviceID: "pixel_9", ImagePkg: "system-images;android-36;google_apis;x86_64"}); err != nil {
		t.Fatal(err)
	}

	res, err := Create(s, Options{AVD: "My_AVD", DisplayName: "Meu Emulador"})
	if err != nil {
		t.Fatal(err)
	}
	b, err := os.ReadFile(res.Path)
	if err != nil {
		t.Fatal(err)
	}
	txt := string(b)
	for _, want := range []string{
		"Name=Meu Emulador", "StartupWMClass=android-emulator-my-avd", "X-AVDMenu-AVD=My_AVD",
		"Exec=env RESOURCE_NAME=android-emulator-my-avd ", filepath.Join(root, "emulator", "emulator") + " -avd My_AVD",
		"[Desktop Action cold-boot]", "-no-snapshot-load", "[Desktop Action wipe-data]", "-wipe-data",
	} {
		if !strings.Contains(txt, want) {
			t.Errorf(".desktop sem %q:\n%s", want, txt)
		}
	}
	if !Lookup("My_AVD").Exists {
		t.Error("Lookup deveria achar o atalho")
	}
	if _, err := os.Stat(filepath.Join(data, "icons", "hicolor", "scalable", "apps", DesktopID("My_AVD")+".svg")); err != nil {
		t.Error("ícone svg não instalado")
	}
	// ícone PNG customizado substitui o SVG
	var pngBuf bytes.Buffer
	_ = png.Encode(&pngBuf, image.NewNRGBA(image.Rect(0, 0, 8, 8)))
	if _, err := Create(s, Options{AVD: "My_AVD", IconData: "data:image/png;base64," + b64(pngBuf.Bytes())}); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(data, "icons", "hicolor", "256x256", "apps", DesktopID("My_AVD")+".png")); err != nil {
		t.Error("ícone png não instalado")
	}
	if _, err := os.Stat(filepath.Join(data, "icons", "hicolor", "scalable", "apps", DesktopID("My_AVD")+".svg")); err == nil {
		t.Error("o svg antigo deveria ter sido removido")
	}
	if _, err := Create(s, Options{AVD: "Nao_Existe"}); err == nil {
		t.Error("AVD inexistente deveria falhar")
	}
	if _, err := Create(s, Options{AVD: "My_AVD", IconData: "data:image/png;base64,naoebase64!!"}); err == nil {
		t.Error("ícone inválido deveria falhar")
	}
	if err := Remove("My_AVD"); err != nil {
		t.Fatal(err)
	}
	if Lookup("My_AVD").Exists {
		t.Error("atalho deveria ter sido removido")
	}
	if err := Remove("My_AVD"); err == nil {
		t.Error("remover duas vezes deveria falhar")
	}
}

func TestSelfInstall(t *testing.T) {
	if runtime.GOOS != "linux" {
		t.Skip("somente Linux")
	}
	t.Setenv("XDG_DATA_HOME", t.TempDir())
	t.Setenv("PATH", "/usr/bin:/bin")
	res, err := InstallSelf()
	if err != nil {
		t.Fatal(err)
	}
	b, _ := os.ReadFile(res.Path)
	if !strings.Contains(string(b), "StartupWMClass=AvdMenu") || !strings.Contains(string(b), " ui\n") {
		t.Errorf("desktop do AVD Menu:\n%s", b)
	}
	if !SelfInfo().Exists {
		t.Error("SelfInfo deveria existir")
	}
	if err := UninstallSelf(); err != nil || SelfInfo().Exists {
		t.Errorf("UninstallSelf: %v", err)
	}
}

func b64(b []byte) string { return base64.StdEncoding.EncodeToString(b) }

func TestMacBundle(t *testing.T) {
	home := t.TempDir()
	t.Setenv("HOME", home)
	t.Setenv("ANDROID_AVD_HOME", "")
	root := t.TempDir()
	s := sdk.SDK{Root: root}
	res, err := macCreate(s, Options{AVD: "Pixel_9"}, "Meu Pixel/9", iconSource{Data: assetsPNG(t), Ext: "png"})
	if err != nil {
		t.Fatal(err)
	}
	if filepath.Base(res.Path) != "Meu Pixel-9.app" {
		t.Errorf("nome do bundle = %q", filepath.Base(res.Path))
	}
	launcher := filepath.Join(res.Path, "Contents", "MacOS", "launcher")
	b, err := os.ReadFile(launcher)
	if err != nil {
		t.Fatal(err)
	}
	if st, _ := os.Stat(launcher); st.Mode()&0o111 == 0 {
		t.Error("launcher precisa ser executável")
	}
	if !strings.Contains(string(b), "exec '"+filepath.Join(root, "emulator", "emulator")+"' -avd 'Pixel_9'") {
		t.Errorf("launcher:\n%s", b)
	}
	plist, _ := os.ReadFile(filepath.Join(res.Path, "Contents", "Info.plist"))
	if !strings.Contains(string(plist), "<key>AVDMenuAVD</key><string>Pixel_9</string>") || !strings.Contains(string(plist), "app.avdmenu.avd.pixel-9") {
		t.Errorf("Info.plist:\n%s", plist)
	}
	icns, err := os.ReadFile(filepath.Join(res.Path, "Contents", "Resources", "icon.icns"))
	if err != nil || string(icns[:4]) != "icns" {
		t.Errorf("icon.icns inválido: %v", err)
	}
	if info := macLookup("Pixel_9"); !info.Exists || info.Path != res.Path {
		t.Errorf("macLookup: %+v", info)
	}
	// recriar com outro nome apaga o bundle antigo
	res2, err := macCreate(s, Options{AVD: "Pixel_9"}, "Outro Nome", iconSource{Data: assets.IconSVG, Ext: "svg"})
	if err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(res.Path); err == nil {
		t.Error("o bundle antigo deveria ter sido removido")
	}
	if err := macRemove("Pixel_9"); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(res2.Path); err == nil {
		t.Error("macRemove deveria apagar o bundle")
	}
}

func assetsPNG(t *testing.T) []byte {
	t.Helper()
	return assets.IconPNG
}
