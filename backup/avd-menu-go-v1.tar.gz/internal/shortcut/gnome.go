package shortcut

import (
	"context"
	"os/exec"
	"regexp"
	"strings"
	"time"

	"avdmenu/internal/platform"
)

var favRe = regexp.MustCompile(`'([^']*)'`)

func gsettings(args ...string) (string, error) {
	p := platform.Which("gsettings")
	if p == "" {
		return "", exec.ErrNotFound
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	out, err := exec.CommandContext(ctx, p, args...).Output()
	return strings.TrimSpace(string(out)), err
}

func favorites() ([]string, bool) {
	out, err := gsettings("get", "org.gnome.shell", "favorite-apps")
	if err != nil {
		return nil, false
	}
	var fav []string
	for _, m := range favRe.FindAllStringSubmatch(out, -1) {
		fav = append(fav, m[1])
	}
	return fav, true
}

func setFavorites(fav []string) bool {
	quoted := make([]string, len(fav))
	for i, f := range fav {
		quoted[i] = "'" + strings.ReplaceAll(f, "'", "") + "'"
	}
	_, err := gsettings("set", "org.gnome.shell", "favorite-apps", "["+strings.Join(quoted, ", ")+"]")
	return err == nil
}

func isPinned(desktopFile string) bool {
	fav, ok := favorites()
	if !ok {
		return false
	}
	for _, f := range fav {
		if f == desktopFile {
			return true
		}
	}
	return false
}

// pin fixa o atalho na dock do GNOME (favorite-apps).
func pin(desktopFile string) bool {
	fav, ok := favorites()
	if !ok {
		return false
	}
	for _, f := range fav {
		if f == desktopFile {
			return true
		}
	}
	return setFavorites(append(fav, desktopFile))
}

func unpin(desktopFile string) {
	fav, ok := favorites()
	if !ok {
		return
	}
	var keep []string
	changed := false
	for _, f := range fav {
		if f == desktopFile {
			changed = true
			continue
		}
		keep = append(keep, f)
	}
	if changed {
		setFavorites(keep)
	}
}
