// Package shortcut cria atalhos de emuladores no menu de aplicativos: um
// arquivo .desktop no Linux (GNOME, KDE...) e um pacote .app no macOS.
package shortcut

import (
	"bytes"
	"encoding/base64"
	"fmt"
	"image"
	"image/png"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strings"

	_ "image/gif"
	_ "image/jpeg"

	"avdmenu/internal/assets"
	"avdmenu/internal/avd"
	"avdmenu/internal/emu"
	"avdmenu/internal/platform"
	"avdmenu/internal/sdk"
)

// Options descreve o atalho a criar.
type Options struct {
	AVD         string
	DisplayName string // nome no menu; vazio = "Android Emulator <AVD>"
	// Ícone: caminho de arquivo OU data URL (PNG/SVG) vindo da interface.
	IconPath string
	IconData string
	Pin      bool // fixar na dock do GNOME
}

// Result informa o que foi criado.
type Result struct {
	Path        string `json:"path"`
	DisplayName string `json:"displayName"`
	Icon        string `json:"icon"`
	Pinned      bool   `json:"pinned"`
	GPUAction   bool   `json:"gpuAction"`
}

// Info descreve um atalho existente.
type Info struct {
	Exists      bool   `json:"exists"`
	Path        string `json:"path,omitempty"`
	DisplayName string `json:"displayName,omitempty"`
}

// Pinned informa se o atalho do AVD está fixo na dock do GNOME.
func Pinned(avdName string) bool {
	return runtime.GOOS == "linux" && isPinned(DesktopID(avdName)+".desktop")
}

// Supported informa se criamos atalhos nesta plataforma.
func Supported() bool { return runtime.GOOS == "linux" || runtime.GOOS == "darwin" }

// DesktopID é o identificador do atalho de um AVD (compatível com o avd-menu.sh).
func DesktopID(avdName string) string { return "android-emulator-" + platform.Slugify(avdName) }

func appsDir() string  { return filepath.Join(platform.DataHome(), "applications") }
func iconsDir() string { return filepath.Join(platform.DataHome(), "icons", "hicolor") }

// Lookup procura o atalho de um AVD.
func Lookup(avdName string) Info {
	switch runtime.GOOS {
	case "darwin":
		return macLookup(avdName)
	case "linux":
		p := filepath.Join(appsDir(), DesktopID(avdName)+".desktop")
		if !platform.FileExists(p) {
			return Info{}
		}
		return Info{Exists: true, Path: p, DisplayName: desktopValue(p, "Name")}
	}
	return Info{}
}

// Create cria (ou recria) o atalho do AVD.
func Create(s sdk.SDK, opt Options) (Result, error) {
	if !Supported() {
		return Result{}, platform.Errorf("atalhos não são suportados neste sistema", "shortcuts are not supported on this system")
	}
	if !avd.ValidName(opt.AVD) {
		return Result{}, platform.Errorf("nome de AVD inválido: %q", "invalid AVD name: %q", opt.AVD)
	}
	if !s.HasEmulator() {
		return Result{}, platform.Errorf("instale o pacote \"Android Emulator\" antes de criar o atalho", "install the \"Android Emulator\" package before creating the shortcut")
	}
	if _, err := avd.Load(s, opt.AVD); err != nil {
		return Result{}, platform.Errorf("o AVD %q não existe", "AVD %q does not exist", opt.AVD)
	}
	name := strings.TrimSpace(opt.DisplayName)
	if name == "" {
		name = "Android Emulator " + opt.AVD
	}
	if strings.ContainsAny(name, "\n\r\x00") {
		return Result{}, platform.Errorf("nome inválido", "invalid name")
	}
	icon, err := resolveIcon(opt)
	if err != nil {
		return Result{}, err
	}
	switch runtime.GOOS {
	case "darwin":
		return macCreate(s, opt, name, icon)
	default:
		return linuxCreate(s, opt, name, icon)
	}
}

// Remove apaga o atalho de um AVD (e o ícone instalado).
func Remove(avdName string) error {
	switch runtime.GOOS {
	case "darwin":
		return macRemove(avdName)
	case "linux":
		id := DesktopID(avdName)
		p := filepath.Join(appsDir(), id+".desktop")
		if !platform.FileExists(p) {
			return platform.Errorf("nenhum atalho encontrado para o AVD %q", "no shortcut found for AVD %q", avdName)
		}
		unpin(id + ".desktop")
		_ = os.Remove(p)
		_ = os.Remove(filepath.Join(iconsDir(), "scalable", "apps", id+".svg"))
		_ = os.Remove(filepath.Join(iconsDir(), "256x256", "apps", id+".png"))
		refreshCaches()
		return nil
	}
	return platform.Errorf("sem suporte", "unsupported")
}

// ---- ícone ----------------------------------------------------------------------

// iconSource é o ícone resolvido: bytes + extensão ("svg" ou "png").
type iconSource struct {
	Data []byte
	Ext  string
}

var dataURLRe = regexp.MustCompile(`^data:([a-zA-Z0-9/+.-]+);base64,(.*)$`)

func resolveIcon(opt Options) (iconSource, error) {
	switch {
	case opt.IconData != "":
		m := dataURLRe.FindStringSubmatch(opt.IconData)
		if m == nil {
			return iconSource{}, platform.Errorf("ícone inválido", "invalid icon")
		}
		raw, err := base64.StdEncoding.DecodeString(m[2])
		if err != nil || len(raw) == 0 || len(raw) > 8<<20 {
			return iconSource{}, platform.Errorf("ícone inválido ou grande demais", "invalid or too large icon")
		}
		return classifyIcon(raw)
	case opt.IconPath != "":
		raw, err := os.ReadFile(opt.IconPath)
		if err != nil {
			return iconSource{}, platform.Errorf("não foi possível ler o ícone: %w", "could not read the icon: %w", err)
		}
		return classifyIcon(raw)
	}
	return iconSource{Data: assets.IconSVG, Ext: "svg"}, nil
}

func classifyIcon(raw []byte) (iconSource, error) {
	head := bytes.TrimSpace(raw)
	if len(head) > 512 {
		head = head[:512]
	}
	if bytes.Contains(head, []byte("<svg")) || (bytes.HasPrefix(head, []byte("<?xml")) && bytes.Contains(raw, []byte("<svg"))) {
		return iconSource{Data: raw, Ext: "svg"}, nil
	}
	img, _, err := image.Decode(bytes.NewReader(raw))
	if err != nil {
		return iconSource{}, platform.Errorf("formato de imagem não suportado (use PNG, JPG, GIF ou SVG)", "unsupported image format (use PNG, JPG, GIF or SVG)")
	}
	var buf bytes.Buffer
	if err := png.Encode(&buf, img); err != nil {
		return iconSource{}, err
	}
	return iconSource{Data: buf.Bytes(), Ext: "png"}, nil
}

// ---- Linux ------------------------------------------------------------------------

// execQuote aplica as regras de aspas do campo Exec do .desktop.
func execQuote(arg string) string {
	if arg == "" {
		return `""`
	}
	needs := strings.ContainsAny(arg, " \t\n\"'\\><~|&;$*?#()`")
	arg = strings.ReplaceAll(arg, "%", "%%")
	if !needs {
		return arg
	}
	r := strings.NewReplacer(`\`, `\\`, `"`, `\"`, "`", "\\`", "$", `\$`)
	return `"` + r.Replace(arg) + `"`
}

func execLine(envs []string, argv ...string) string {
	parts := []string{"env"}
	for _, e := range envs {
		parts = append(parts, execQuote(e))
	}
	for _, a := range argv {
		parts = append(parts, execQuote(a))
	}
	return strings.Join(parts, " ")
}

func installIcon(src iconSource, name string) (string, error) {
	var dest string
	switch src.Ext {
	case "svg":
		dest = filepath.Join(iconsDir(), "scalable", "apps", name+".svg")
	default:
		dest = filepath.Join(iconsDir(), "256x256", "apps", name+".png")
	}
	if err := os.MkdirAll(filepath.Dir(dest), 0o755); err != nil {
		return "", err
	}
	if err := os.WriteFile(dest, src.Data, 0o644); err != nil {
		return "", err
	}
	// Não deixa um ícone antigo do outro formato sobrescrevendo este.
	if src.Ext == "svg" {
		_ = os.Remove(filepath.Join(iconsDir(), "256x256", "apps", name+".png"))
	} else {
		_ = os.Remove(filepath.Join(iconsDir(), "scalable", "apps", name+".svg"))
	}
	return name, nil
}

func linuxCreate(s sdk.SDK, opt Options, name string, icon iconSource) (Result, error) {
	id := DesktopID(opt.AVD)
	iconName, err := installIcon(icon, id)
	if err != nil {
		return Result{}, err
	}
	emulator := s.Emulator()
	// O GNOME vincula a janela ao atalho comparando o WM_CLASS com
	// StartupWMClass. O emulador (Qt/xcb) usa o mesmo WM_CLASS para todos os
	// AVDs; RESOURCE_NAME troca a parte "instância", dando um nome por AVD.
	envs := []string{"RESOURCE_NAME=" + emu.WMClass(opt.AVD)}
	if h := os.Getenv("ANDROID_AVD_HOME"); h != "" {
		envs = append(envs, "ANDROID_AVD_HOME="+h)
	}
	dgpu := emu.DedicatedGPUEnv()

	actions := []string{"cold-boot", "wipe-data"}
	if len(dgpu) > 0 {
		actions = append([]string{"gpu-dedicada"}, actions...)
	}

	var b strings.Builder
	w := func(format string, a ...any) { fmt.Fprintf(&b, format+"\n", a...) }
	w("[Desktop Entry]")
	w("Version=1.0")
	w("Type=Application")
	w("Name=%s", name)
	w("GenericName=Android Emulator")
	w("Comment=Starts the Android emulator %s", opt.AVD)
	w("Comment[pt]=Inicia o emulador Android %s", opt.AVD)
	w("Comment[pt_BR]=Inicia o emulador Android %s", opt.AVD)
	w("Exec=%s", execLine(envs, emulator, "-avd", opt.AVD))
	w("Icon=%s", iconName)
	w("Terminal=false")
	w("Categories=Development;IDE;")
	w("Keywords=android;emulator;avd;%s;", opt.AVD)
	w("StartupNotify=true")
	w("StartupWMClass=%s", emu.WMClass(opt.AVD))
	w("X-AVDMenu-AVD=%s", opt.AVD)
	w("Actions=%s;", strings.Join(actions, ";"))
	w("")
	w("[Desktop Action cold-boot]")
	w("Name=Cold boot")
	w("Name[pt]=Iniciar com cold boot")
	w("Name[pt_BR]=Iniciar com cold boot")
	w("Exec=%s", execLine(envs, emulator, "-avd", opt.AVD, "-no-snapshot-load"))
	w("")
	w("[Desktop Action wipe-data]")
	w("Name=Wipe data and start")
	w("Name[pt]=Iniciar apagando os dados")
	w("Name[pt_BR]=Iniciar apagando os dados")
	w("Exec=%s", execLine(envs, emulator, "-avd", opt.AVD, "-wipe-data"))
	if len(dgpu) > 0 {
		// O GNOME oferece "Iniciar usando placa de vídeo dedicada" sozinho, mas
		// só enquanto considera o app parado — com o atalho vinculado à janela o
		// item some quando o emulador sobe. Esta ação fica sempre disponível.
		w("")
		w("[Desktop Action gpu-dedicada]")
		w("Name=Start with dedicated GPU")
		w("Name[pt]=Iniciar com placa de vídeo dedicada")
		w("Name[pt_BR]=Iniciar com placa de vídeo dedicada")
		w("Exec=%s", execLine(append(append([]string{}, envs...), dgpu...), emulator, "-avd", opt.AVD))
	}

	if err := os.MkdirAll(appsDir(), 0o755); err != nil {
		return Result{}, err
	}
	path := filepath.Join(appsDir(), id+".desktop")
	if err := os.WriteFile(path, []byte(b.String()), 0o644); err != nil {
		return Result{}, err
	}
	validate(path)
	refreshCaches()
	res := Result{Path: path, DisplayName: name, Icon: iconName, GPUAction: len(dgpu) > 0}
	if opt.Pin {
		res.Pinned = pin(id + ".desktop")
	}
	return res, nil
}

// validate roda o desktop-file-validate, se existir, só para avisar no stderr.
func validate(path string) {
	if p := platform.Which("desktop-file-validate"); p != "" {
		_ = exec.Command(p, path).Run()
	}
}

func refreshCaches() {
	if p := platform.Which("update-desktop-database"); p != "" {
		_ = exec.Command(p, appsDir()).Run()
	}
	if p := platform.Which("gtk-update-icon-cache"); p != "" {
		_ = exec.Command(p, "-f", "-t", iconsDir()).Run()
	}
}

// desktopValue lê uma chave da seção [Desktop Entry] de um .desktop.
func desktopValue(path, key string) string {
	b, err := os.ReadFile(path)
	if err != nil {
		return ""
	}
	inMain := false
	for _, line := range strings.Split(string(b), "\n") {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "[") {
			inMain = line == "[Desktop Entry]"
			continue
		}
		if inMain && strings.HasPrefix(line, key+"=") {
			return strings.TrimPrefix(line, key+"=")
		}
	}
	return ""
}
