package shortcut

import (
	"os"
	"path/filepath"
	"strings"

	"avdmenu/internal/assets"
	"avdmenu/internal/emu"
	"avdmenu/internal/platform"
	"avdmenu/internal/sdk"
)

func macAppsDir() string { return filepath.Join(platform.Home(), "Applications") }

func plistEsc(s string) string {
	return strings.NewReplacer("&", "&amp;", "<", "&lt;", ">", "&gt;").Replace(s)
}

func shQuote(s string) string { return "'" + strings.ReplaceAll(s, "'", `'\''`) + "'" }

func macBundleName(display string) string {
	r := strings.NewReplacer("/", "-", ":", "-", "\x00", "")
	return strings.TrimSpace(r.Replace(display)) + ".app"
}

func macLookup(avdName string) Info {
	entries, err := os.ReadDir(macAppsDir())
	if err != nil {
		return Info{}
	}
	marker := "<key>AVDMenuAVD</key><string>" + plistEsc(avdName) + "</string>"
	for _, e := range entries {
		if !strings.HasSuffix(e.Name(), ".app") {
			continue
		}
		b, err := os.ReadFile(filepath.Join(macAppsDir(), e.Name(), "Contents", "Info.plist"))
		if err == nil && strings.Contains(string(b), marker) {
			return Info{Exists: true, Path: filepath.Join(macAppsDir(), e.Name()), DisplayName: strings.TrimSuffix(e.Name(), ".app")}
		}
	}
	return Info{}
}

func macCreate(s sdk.SDK, opt Options, name string, icon iconSource) (Result, error) {
	// Recria: remove um atalho anterior do mesmo AVD (o nome pode ter mudado).
	if old := macLookup(opt.AVD); old.Exists {
		_ = os.RemoveAll(old.Path)
	}
	app := filepath.Join(macAppsDir(), macBundleName(name))
	macos := filepath.Join(app, "Contents", "MacOS")
	res := filepath.Join(app, "Contents", "Resources")
	if err := os.MkdirAll(macos, 0o755); err != nil {
		return Result{}, err
	}
	if err := os.MkdirAll(res, 0o755); err != nil {
		return Result{}, err
	}
	pngData := icon.Data
	if icon.Ext != "png" {
		pngData = assets.IconPNG // o macOS não lê SVG em .icns: usa o ícone padrão
	}
	icns, err := ICNS(pngData)
	if err != nil {
		return Result{}, err
	}
	if err := os.WriteFile(filepath.Join(res, "icon.icns"), icns, 0o644); err != nil {
		return Result{}, err
	}
	env := "export ANDROID_SDK_ROOT=" + shQuote(s.Root) + "\n"
	if h := os.Getenv("ANDROID_AVD_HOME"); h != "" {
		env += "export ANDROID_AVD_HOME=" + shQuote(h) + "\n"
	}
	script := "#!/bin/bash\n" + env + "exec " + shQuote(s.Emulator()) + " -avd " + shQuote(opt.AVD) + "\n"
	if err := os.WriteFile(filepath.Join(macos, "launcher"), []byte(script), 0o755); err != nil {
		return Result{}, err
	}
	plist := `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleName</key><string>` + plistEsc(name) + `</string>
<key>CFBundleDisplayName</key><string>` + plistEsc(name) + `</string>
<key>CFBundleIdentifier</key><string>app.avdmenu.avd.` + platform.Slugify(opt.AVD) + `</string>
<key>CFBundleExecutable</key><string>launcher</string>
<key>CFBundleIconFile</key><string>icon</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleVersion</key><string>1</string>
<key>LSMinimumSystemVersion</key><string>11.0</string>
<key>AVDMenuAVD</key><string>` + plistEsc(opt.AVD) + `</string>
</dict></plist>
`
	if err := os.WriteFile(filepath.Join(app, "Contents", "Info.plist"), []byte(plist), 0o644); err != nil {
		return Result{}, err
	}
	_ = emu.WMClass // (o macOS não usa WM_CLASS)
	touch(app)
	return Result{Path: app, DisplayName: name, Icon: "icon.icns"}, nil
}

// touch avisa o Finder/LaunchServices de que o pacote mudou.
func touch(p string) {
	now := timeNow()
	_ = os.Chtimes(p, now, now)
}

func macRemove(avdName string) error {
	info := macLookup(avdName)
	if !info.Exists {
		return platform.Errorf("nenhum atalho encontrado para o AVD %q", "no shortcut found for AVD %q", avdName)
	}
	return os.RemoveAll(info.Path)
}
