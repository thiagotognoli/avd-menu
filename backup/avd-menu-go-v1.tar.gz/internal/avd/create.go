package avd

import (
	"avdmenu/internal/platform"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"avdmenu/internal/devices"
	"avdmenu/internal/sdk"
)

// Settings são as opções editáveis de um AVD (etapa "Verify Configuration" /
// "Show Advanced Settings" do Android Studio). Ponteiros nulos = não mexer.
type Settings struct {
	DisplayName *string `json:"displayName,omitempty"`
	Orientation *string `json:"orientation,omitempty"` // portrait | landscape
	RAMMB       *int    `json:"ramMB,omitempty"`
	VMHeapMB    *int    `json:"vmHeapMB,omitempty"`
	Cores       *int    `json:"cores,omitempty"`
	DataMB      *int    `json:"dataMB,omitempty"`      // armazenamento interno
	SDCardMB    *int    `json:"sdCardMB,omitempty"`    // 0 = sem cartão SD
	CameraFront *string `json:"cameraFront,omitempty"` // none | emulated | webcam0
	CameraBack  *string `json:"cameraBack,omitempty"`  // none | emulated | virtualscene | webcam0
	NetSpeed    *string `json:"netSpeed,omitempty"`    // full | lte | hsdpa | ...
	NetLatency  *string `json:"netLatency,omitempty"`  // none | umts | gprs | ...
	GPUMode     *string `json:"gpuMode,omitempty"`     // auto | host | swiftshader_indirect | software
	BootMode    *string `json:"bootMode,omitempty"`    // quick | cold
	Keyboard    *bool   `json:"keyboard,omitempty"`    // teclado do PC
	ShowFrame   *bool   `json:"showFrame,omitempty"`
	// Extra sobrescreve chaves arbitrárias do config.ini (nil apaga).
	Extra map[string]*string `json:"extra,omitempty"`
}

func yesno(b bool) string {
	if b {
		return "yes"
	}
	return "no"
}

// Apply grava as opções no config.ini em memória.
func (st Settings) Apply(cfg *Ini) error {
	if st.DisplayName != nil {
		n := strings.TrimSpace(*st.DisplayName)
		if n == "" {
			return platform.Errorf("o nome do AVD não pode ficar vazio", "the AVD name cannot be empty")
		}
		cfg.Set("avd.ini.displayname", n)
	}
	if st.Orientation != nil {
		switch *st.Orientation {
		case "portrait", "landscape":
			cfg.Set("hw.initialOrientation", *st.Orientation)
		default:
			return platform.Errorf("orientação inválida: %q", "invalid orientation: %q", *st.Orientation)
		}
	}
	if st.RAMMB != nil {
		if *st.RAMMB < 256 || *st.RAMMB > 65536 {
			return platform.Errorf("RAM deve ficar entre 256 MB e 64 GB", "RAM must be between 256 MB and 64 GB")
		}
		cfg.Set("hw.ramSize", strconv.Itoa(*st.RAMMB))
	}
	if st.VMHeapMB != nil {
		if *st.VMHeapMB < 16 || *st.VMHeapMB > 4096 {
			return platform.Errorf("heap da VM deve ficar entre 16 MB e 4096 MB", "VM heap must be between 16 MB and 4096 MB")
		}
		cfg.Set("vm.heapSize", strconv.Itoa(*st.VMHeapMB))
	}
	if st.Cores != nil {
		if *st.Cores < 1 || *st.Cores > 64 {
			return platform.Errorf("núcleos deve ficar entre 1 e 64", "cores must be between 1 and 64")
		}
		cfg.Set("hw.cpu.ncore", strconv.Itoa(*st.Cores))
	}
	if st.DataMB != nil {
		if *st.DataMB < 512 {
			return platform.Errorf("armazenamento interno mínimo: 512 MB", "minimum internal storage: 512 MB")
		}
		cfg.Set("disk.dataPartition.size", strconv.Itoa(*st.DataMB)+"M")
	}
	if st.SDCardMB != nil {
		if *st.SDCardMB <= 0 {
			cfg.Set("hw.sdCard", "no")
			cfg.Delete("sdcard.size")
		} else {
			cfg.Set("hw.sdCard", "yes")
			cfg.Set("sdcard.size", strconv.Itoa(*st.SDCardMB)+" MB")
		}
	}
	if st.CameraFront != nil {
		cfg.Set("hw.camera.front", *st.CameraFront)
	}
	if st.CameraBack != nil {
		cfg.Set("hw.camera.back", *st.CameraBack)
	}
	if st.NetSpeed != nil {
		cfg.Set("runtime.network.speed", *st.NetSpeed)
	}
	if st.NetLatency != nil {
		cfg.Set("runtime.network.latency", *st.NetLatency)
	}
	if st.GPUMode != nil {
		mode := *st.GPUMode
		switch mode {
		case "auto", "host", "swiftshader_indirect", "software", "angle_indirect", "guest", "mesa":
		default:
			return platform.Errorf("modo gráfico inválido: %q", "invalid graphics mode: %q", mode)
		}
		cfg.Set("hw.gpu.enabled", yesno(mode != "software" && mode != "guest"))
		cfg.Set("hw.gpu.mode", mode)
	}
	if st.BootMode != nil {
		cold := *st.BootMode == "cold"
		cfg.Set("fastboot.forceColdBoot", yesno(cold))
		cfg.Set("fastboot.forceFastBoot", yesno(!cold))
	}
	if st.Keyboard != nil {
		cfg.Set("hw.keyboard", yesno(*st.Keyboard))
	}
	if st.ShowFrame != nil {
		cfg.Set("showDeviceFrame", yesno(*st.ShowFrame))
	}
	for k, v := range st.Extra {
		if strings.ContainsAny(k, "=\n\r ") || k == "" {
			return platform.Errorf("chave inválida: %q", "invalid key: %q", k)
		}
		if v == nil {
			cfg.Delete(k)
		} else {
			if strings.ContainsAny(*v, "\n\r") {
				return platform.Errorf("valor inválido para %s", "invalid value for %s", k)
			}
			cfg.Set(k, *v)
		}
	}
	return nil
}

// View são os valores atuais, no formato que o formulário de edição usa.
type View struct {
	DisplayName string `json:"displayName"`
	Orientation string `json:"orientation"`
	RAMMB       int    `json:"ramMB"`
	VMHeapMB    int    `json:"vmHeapMB"`
	Cores       int    `json:"cores"`
	DataMB      int    `json:"dataMB"`
	SDCardMB    int    `json:"sdCardMB"`
	CameraFront string `json:"cameraFront"`
	CameraBack  string `json:"cameraBack"`
	NetSpeed    string `json:"netSpeed"`
	NetLatency  string `json:"netLatency"`
	GPUMode     string `json:"gpuMode"`
	BootMode    string `json:"bootMode"`
	Keyboard    bool   `json:"keyboard"`
	ShowFrame   bool   `json:"showFrame"`
}

func orDefault(v, def string) string {
	if v == "" {
		return def
	}
	return v
}

// ViewOf extrai os valores de um config.ini.
func ViewOf(cfg *Ini, name string) View {
	v := View{
		DisplayName: orDefault(cfg.Get("avd.ini.displayname"), strings.ReplaceAll(name, "_", " ")),
		Orientation: orDefault(cfg.Get("hw.initialOrientation"), "portrait"),
		RAMMB:       ParseMB(cfg.Get("hw.ramSize")),
		VMHeapMB:    ParseMB(cfg.Get("vm.heapSize")),
		DataMB:      ParseMB(cfg.Get("disk.dataPartition.size")),
		CameraFront: orDefault(cfg.Get("hw.camera.front"), "none"),
		CameraBack:  orDefault(cfg.Get("hw.camera.back"), "none"),
		NetSpeed:    orDefault(cfg.Get("runtime.network.speed"), "full"),
		NetLatency:  orDefault(cfg.Get("runtime.network.latency"), "none"),
		GPUMode:     orDefault(cfg.Get("hw.gpu.mode"), "auto"),
		BootMode:    "quick",
		Keyboard:    cfg.Get("hw.keyboard") == "yes",
		ShowFrame:   cfg.Get("showDeviceFrame") != "no",
	}
	v.Cores, _ = strconv.Atoi(cfg.Get("hw.cpu.ncore"))
	if v.Cores == 0 {
		v.Cores = 1
	}
	if cfg.Get("hw.sdCard") != "no" {
		v.SDCardMB = ParseMB(cfg.Get("sdcard.size"))
	}
	if cfg.Get("fastboot.forceColdBoot") == "yes" {
		v.BootMode = "cold"
	}
	return v
}

// Update altera as opções de um AVD existente.
func Update(name string, st Settings) error {
	dir, err := avdDir(name)
	if err != nil {
		return err
	}
	p := filepath.Join(dir, "config.ini")
	cfg, err := ReadIni(p)
	if err != nil {
		return err
	}
	if err := st.Apply(cfg); err != nil {
		return err
	}
	return os.WriteFile(p, cfg.Bytes(), 0o644)
}

// WriteRawConfig substitui o config.ini inteiro (editor avançado). Guarda um
// backup do arquivo anterior em config.ini.bak.
func WriteRawConfig(name, content string) error {
	dir, err := avdDir(name)
	if err != nil {
		return err
	}
	p := filepath.Join(dir, "config.ini")
	if old, err := os.ReadFile(p); err == nil {
		_ = os.WriteFile(p+".bak", old, 0o644)
	}
	ini := ParseIni([]byte(content))
	if ini.Get("image.sysdir.1") == "" {
		return platform.Errorf("o config.ini precisa manter a chave image.sysdir.1", "config.ini must keep the image.sysdir.1 key")
	}
	return os.WriteFile(p, []byte(strings.ReplaceAll(content, "\r\n", "\n")), 0o644)
}

// CreateSpec descreve um AVD novo.
type CreateSpec struct {
	Name     string `json:"name"`     // identificador (sem espaços)
	DeviceID string `json:"deviceId"` // id do perfil de hardware
	ImagePkg string `json:"imagePkg"` // system-images;android-36;google_apis;x86_64
	Settings
}

func cpuArch(abi string) string {
	switch abi {
	case "arm64-v8a":
		return "arm64"
	case "armeabi-v7a":
		return "arm"
	default:
		return abi // x86, x86_64
	}
}

// BuildConfig monta o config.ini de um AVD novo: as chaves do aparelho
// (avdmanager) + as da imagem de sistema + os ajustes escolhidos.
func BuildConfig(dev devices.Device, img sdk.SysImageProps, spec CreateSpec) (*Ini, error) {
	cfg := NewIni()
	for k, v := range dev.HWConfig() {
		cfg.Set(k, v)
	}
	display := strings.ReplaceAll(spec.Name, "_", " ")
	if spec.DisplayName != nil && strings.TrimSpace(*spec.DisplayName) != "" {
		display = strings.TrimSpace(*spec.DisplayName)
	}
	cfg.Set("AvdId", spec.Name)
	cfg.Set("avd.ini.displayname", display)
	cfg.Set("avd.ini.encoding", "UTF-8")
	cfg.Set("abi.type", img.ABI)
	cfg.Set("hw.cpu.arch", cpuArch(img.ABI))
	cfg.Set("image.sysdir.1", img.Dir)
	cfg.Set("tag.id", img.TagID)
	cfg.Set("tag.ids", img.TagID)
	disp := img.TagDisplay
	if disp == "" {
		disp = img.TagID
	}
	cfg.Set("tag.display", disp)
	cfg.Set("tag.displaynames", disp)
	cfg.Set("PlayStore.enabled", strconv.FormatBool(img.PlayStore))
	cfg.Set("hw.gpu.enabled", "yes")
	cfg.Set("hw.gpu.mode", "auto")
	cfg.Set("showDeviceFrame", "yes")
	cfg.Set("fastboot.forceColdBoot", "no")
	cfg.Set("fastboot.forceFastBoot", "yes")
	if dev.Category == "wear" || dev.Category == "tv" || dev.Category == "automotive" {
		// aparelhos sem tela de toque de celular usam o teclado do PC
		cfg.Set("hw.keyboard", "yes")
	}
	// target é o nível de API (android-36); o avdmanager repete no config.ini.
	cfg.Set("target", img.Target)
	if err := spec.Settings.Apply(cfg); err != nil {
		return nil, err
	}
	if spec.DisplayName == nil {
		cfg.Set("avd.ini.displayname", display)
	}
	// O emulador prefere a RAM sem unidade ambígua.
	if ram := ParseMB(cfg.Get("hw.ramSize")); ram > 0 {
		cfg.Set("hw.ramSize", strconv.Itoa(ram))
	}
	if h := ParseMB(cfg.Get("vm.heapSize")); h > 0 {
		cfg.Set("vm.heapSize", strconv.Itoa(h))
	}
	return cfg, nil
}

// Create cria o AVD em disco e devolve o resultado lido de volta.
func Create(s sdk.SDK, spec CreateSpec) (AVD, error) {
	if !ValidName(spec.Name) {
		return AVD{}, platform.Errorf("nome inválido %q: use letras, números, ponto, hífen e sublinhado (sem espaços)", "invalid name %q: use letters, digits, dot, dash and underscore (no spaces)", spec.Name)
	}
	dev, ok := devices.Get(spec.DeviceID)
	if !ok {
		return AVD{}, platform.Errorf("dispositivo desconhecido: %q", "unknown device: %q", spec.DeviceID)
	}
	img, ok := s.ReadSysImage(spec.ImagePkg)
	if !ok {
		return AVD{}, platform.Errorf("a imagem de sistema %q não está instalada", "system image %q is not installed", spec.ImagePkg)
	}
	if !dev.TagAllowed(img.TagID) {
		return AVD{}, platform.Errorf("a imagem %s não combina com o dispositivo %s", "image %s does not fit device %s", img.TagID, dev.Name)
	}
	home := Home()
	if err := os.MkdirAll(home, 0o755); err != nil {
		return AVD{}, err
	}
	iniPath := filepath.Join(home, spec.Name+".ini")
	dir := filepath.Join(home, spec.Name+".avd")
	if _, err := os.Stat(iniPath); err == nil {
		return AVD{}, platform.Errorf("já existe um AVD chamado %q", "an AVD named %q already exists", spec.Name)
	}
	if _, err := os.Stat(dir); err == nil {
		return AVD{}, platform.Errorf("a pasta %s já existe", "the folder %s already exists", dir)
	}
	cfg, err := BuildConfig(dev, img, spec)
	if err != nil {
		return AVD{}, err
	}
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return AVD{}, err
	}
	if err := os.WriteFile(filepath.Join(dir, "config.ini"), cfg.SortedBytes(), 0o644); err != nil {
		_ = os.RemoveAll(dir)
		return AVD{}, err
	}
	if err := writeAVDIni(spec.Name, dir, img.Target); err != nil {
		_ = os.RemoveAll(dir)
		return AVD{}, err
	}
	return Load(s, spec.Name)
}
