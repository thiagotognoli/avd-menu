// Package avd lê, cria e edita os Android Virtual Devices (os arquivos em
// ~/.android/avd), sem depender do avdmanager.
package avd

import (
	"fmt"
	"io/fs"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"syscall"

	"avdmenu/internal/devices"
	"avdmenu/internal/platform"
	"avdmenu/internal/sdk"
)

// UserHome é o diretório de dados do Android do usuário (~/.android).
func UserHome() string {
	if v := os.Getenv("ANDROID_USER_HOME"); v != "" {
		return v
	}
	if v := os.Getenv("ANDROID_SDK_HOME"); v != "" {
		return filepath.Join(v, ".android")
	}
	return filepath.Join(platform.Home(), ".android")
}

// Home é a pasta onde ficam os AVDs.
func Home() string {
	if v := os.Getenv("ANDROID_AVD_HOME"); v != "" {
		return v
	}
	return filepath.Join(UserHome(), "avd")
}

// AVD é um dispositivo virtual.
type AVD struct {
	Name        string `json:"name"`
	DisplayName string `json:"displayName"`
	Dir         string `json:"dir"`
	IniPath     string `json:"iniPath"`
	Target      string `json:"target"`
	API         string `json:"api"`
	APIName     string `json:"apiName,omitempty"`
	Tag         string `json:"tag"`
	TagDisplay  string `json:"tagDisplay"`
	ABI         string `json:"abi"`
	PlayStore   bool   `json:"playStore"`
	DeviceID    string `json:"deviceId"`
	DeviceName  string `json:"deviceName"`
	Category    string `json:"category"`
	Width       int    `json:"width"`
	Height      int    `json:"height"`
	Density     int    `json:"density"`
	RAMMB       int    `json:"ramMB"`
	ImagePkg    string `json:"imagePkg"`
	ImageOK     bool   `json:"imageInstalled"`
	SizeBytes   int64  `json:"sizeBytes"`
	LastUsed    int64  `json:"lastUsed,omitempty"` // epoch segundos
	Problem     string `json:"problem,omitempty"`
}

var nameRe = regexp.MustCompile(`^[A-Za-z0-9._-]+$`)

// ValidName informa se name serve como identificador de AVD.
func ValidName(name string) bool {
	return nameRe.MatchString(name) && !strings.HasPrefix(name, ".") && len(name) <= 100
}

// SanitizeName converte um nome livre ("Pixel 9 API 36") em identificador.
func SanitizeName(s string) string {
	s = strings.TrimSpace(s)
	var b strings.Builder
	for _, r := range s {
		switch {
		case r >= 'a' && r <= 'z', r >= 'A' && r <= 'Z', r >= '0' && r <= '9', r == '.', r == '-', r == '_':
			b.WriteRune(r)
		case r == ' ':
			b.WriteByte('_')
		}
	}
	return strings.TrimLeft(b.String(), ".")
}

// ImagePkgFromSysdir converte "system-images/android-36/google_apis/x86_64/"
// em "system-images;android-36;google_apis;x86_64".
func ImagePkgFromSysdir(sysdir string) string {
	sysdir = strings.Trim(filepath.ToSlash(sysdir), "/")
	if sysdir == "" {
		return ""
	}
	return strings.ReplaceAll(sysdir, "/", ";")
}

// APIFromTarget extrai o número de API de "android-36" / "android-36.1".
func APIFromTarget(target string) string {
	return strings.TrimPrefix(target, "android-")
}

// ParseMB converte "2G", "2048M", "2048 MB", "2048" em megabytes.
func ParseMB(s string) int {
	s = strings.ToUpper(strings.TrimSpace(s))
	if s == "" {
		return 0
	}
	mult := 1.0
	switch {
	case strings.HasSuffix(s, "GB"):
		mult, s = 1024, strings.TrimSuffix(s, "GB")
	case strings.HasSuffix(s, "G"):
		mult, s = 1024, strings.TrimSuffix(s, "G")
	case strings.HasSuffix(s, "MB"):
		s = strings.TrimSuffix(s, "MB")
	case strings.HasSuffix(s, "M"):
		s = strings.TrimSuffix(s, "M")
	case strings.HasSuffix(s, "KB"):
		mult, s = 1.0/1024, strings.TrimSuffix(s, "KB")
	case strings.HasSuffix(s, "K"):
		mult, s = 1.0/1024, strings.TrimSuffix(s, "K")
	}
	f, err := strconv.ParseFloat(strings.TrimSpace(s), 64)
	if err != nil {
		return 0
	}
	return int(f * mult)
}

// List devolve todos os AVDs do usuário, ordenados pelo nome de exibição.
func List(s sdk.SDK) []AVD {
	home := Home()
	entries, err := os.ReadDir(home)
	if err != nil {
		return nil
	}
	var names []string
	for _, e := range entries {
		if !e.IsDir() && strings.HasSuffix(e.Name(), ".ini") {
			names = append(names, strings.TrimSuffix(e.Name(), ".ini"))
		}
	}
	out := make([]AVD, len(names))
	var wg sync.WaitGroup
	for i, n := range names {
		wg.Add(1)
		go func(i int, n string) {
			defer wg.Done()
			a, _ := Load(s, n)
			out[i] = a
		}(i, n)
	}
	wg.Wait()
	sort.Slice(out, func(i, j int) bool {
		return strings.ToLower(out[i].DisplayName) < strings.ToLower(out[j].DisplayName)
	})
	return out
}

// dirOf resolve o diretório .avd de um AVD a partir do <nome>.ini.
func dirOf(name string) (dir string, ini *Ini, err error) {
	iniPath := filepath.Join(Home(), name+".ini")
	ini, err = ReadIni(iniPath)
	if err != nil {
		return "", nil, err
	}
	dir = ini.Get("path")
	if dir == "" || !platform.DirExists(dir) {
		if rel := ini.Get("path.rel"); rel != "" {
			if alt := filepath.Join(UserHome(), filepath.FromSlash(rel)); platform.DirExists(alt) {
				dir = alt
			}
		}
	}
	if dir == "" {
		dir = filepath.Join(Home(), name+".avd")
	}
	return dir, ini, nil
}

// Load lê um AVD pelo nome (sempre devolve algo preenchível, mesmo com erro).
func Load(s sdk.SDK, name string) (AVD, error) {
	a := AVD{Name: name, DisplayName: strings.ReplaceAll(name, "_", " "), IniPath: filepath.Join(Home(), name+".ini")}
	dir, ini, err := dirOf(name)
	if err != nil {
		a.Problem = platform.Tr("arquivo .ini ilegível", "unreadable .ini file")
		return a, err
	}
	a.Dir = dir
	a.Target = ini.Get("target")
	cfg, err := ReadIni(filepath.Join(dir, "config.ini"))
	if err != nil {
		a.Problem = platform.Tr("config.ini não encontrado", "config.ini not found")
		a.API = APIFromTarget(a.Target)
		return a, err
	}
	if v := cfg.Get("avd.ini.displayname"); v != "" {
		a.DisplayName = v
	}
	sysdir := cfg.Get("image.sysdir.1")
	a.ImagePkg = ImagePkgFromSysdir(sysdir)
	if parts := strings.Split(a.ImagePkg, ";"); len(parts) == 4 {
		a.API = APIFromTarget(parts[1])
		a.Tag = parts[2]
		a.ABI = parts[3]
	}
	if a.API == "" {
		a.API = APIFromTarget(a.Target)
	}
	a.APIName = sdk.APIName(a.API, "")
	if v := cfg.Get("tag.id"); v != "" {
		a.Tag = v
	}
	a.TagDisplay = cfg.Get("tag.display")
	if a.TagDisplay == "" {
		a.TagDisplay = a.Tag
	}
	if v := cfg.Get("abi.type"); v != "" {
		a.ABI = v
	}
	a.PlayStore = strings.EqualFold(cfg.Get("PlayStore.enabled"), "true") || strings.EqualFold(cfg.Get("PlayStore.enabled"), "yes")
	a.DeviceID = cfg.Get("hw.device.name")
	a.DeviceName = a.DeviceID
	a.Category = "phone"
	if d, ok := devices.Get(a.DeviceID); ok {
		a.DeviceName = d.Name
		a.Category = d.Category
	} else if strings.Contains(a.Tag, "wear") {
		a.Category = "wear"
	} else if strings.Contains(a.Tag, "tv") {
		a.Category = "tv"
	} else if strings.Contains(a.Tag, "automotive") {
		a.Category = "automotive"
	}
	a.Width, _ = strconv.Atoi(cfg.Get("hw.lcd.width"))
	a.Height, _ = strconv.Atoi(cfg.Get("hw.lcd.height"))
	a.Density, _ = strconv.Atoi(cfg.Get("hw.lcd.density"))
	a.RAMMB = ParseMB(cfg.Get("hw.ramSize"))
	if sysdir != "" {
		a.ImageOK = platform.DirExists(filepath.Join(s.Root, filepath.FromSlash(sysdir)))
		if !a.ImageOK {
			a.Problem = platform.Trf("a imagem de sistema %s não está instalada", "system image %s is not installed", a.ImagePkg)
		}
	} else {
		a.Problem = platform.Tr("o AVD não aponta para nenhuma imagem de sistema", "the AVD does not point to any system image")
	}
	a.SizeBytes = DiskUsage(dir)
	if st, err := os.Stat(filepath.Join(dir, "userdata-qemu.img")); err == nil {
		a.LastUsed = st.ModTime().Unix()
	} else if st, err := os.Stat(filepath.Join(dir, "config.ini")); err == nil {
		a.LastUsed = st.ModTime().Unix()
	}
	return a, nil
}

// DiskUsage soma o espaço realmente ocupado em disco (arquivos esparsos como o
// userdata-qemu.img contam só os blocos usados).
func DiskUsage(dir string) int64 {
	var total int64
	if r, err := filepath.EvalSymlinks(dir); err == nil {
		dir = r
	}
	_ = filepath.WalkDir(dir, func(p string, d fs.DirEntry, err error) error {
		if err != nil || d.IsDir() {
			return nil
		}
		info, err := d.Info()
		if err != nil {
			return nil
		}
		if st, ok := info.Sys().(*syscall.Stat_t); ok {
			total += int64(st.Blocks) * 512
		} else {
			total += info.Size()
		}
		return nil
	})
	return total
}

// Config devolve o config.ini completo do AVD.
func Config(name string) (*Ini, string, error) {
	dir, _, err := dirOf(name)
	if err != nil {
		return nil, "", err
	}
	p := filepath.Join(dir, "config.ini")
	c, err := ReadIni(p)
	return c, p, err
}

func avdDir(name string) (string, error) {
	if !ValidName(name) {
		return "", platform.Errorf("nome de AVD inválido: %q", "invalid AVD name: %q", name)
	}
	dir, _, err := dirOf(name)
	if err != nil {
		return "", platform.Errorf("o AVD %q não existe", "AVD %q does not exist", name)
	}
	return dir, nil
}

// Delete apaga o AVD (pasta e .ini).
func Delete(name string) error {
	dir, err := avdDir(name)
	if err != nil {
		return err
	}
	if !strings.HasSuffix(dir, ".avd") || !platform.FileExists(filepath.Join(dir, "config.ini")) {
		return platform.Errorf("recusando apagar %s: não parece uma pasta de AVD", "refusing to delete %s: it does not look like an AVD folder", dir)
	}
	if err := os.RemoveAll(dir); err != nil {
		return err
	}
	return os.Remove(filepath.Join(Home(), name+".ini"))
}

// WipeData apaga os dados do usuário (como "Wipe Data" do Device Manager): o
// próximo boot parte de uma instalação limpa. Preserva o cartão SD.
func WipeData(name string) error {
	dir, err := avdDir(name)
	if err != nil {
		return err
	}
	for _, f := range []string{
		"userdata-qemu.img", "userdata-qemu.img.qcow2", "userdata.img", "cache.img", "cache.img.qcow2",
		"encryptionkey.img", "encryptionkey.img.qcow2", "multiinstance.lock", "hardware-qemu.ini",
	} {
		_ = os.Remove(filepath.Join(dir, f))
	}
	return os.RemoveAll(filepath.Join(dir, "snapshots"))
}

// Duplicate cria uma cópia do AVD com outro nome.
func Duplicate(s sdk.SDK, name, newName, newDisplay string) (AVD, error) {
	if !ValidName(newName) {
		return AVD{}, platform.Errorf("nome inválido: use letras, números, ponto, hífen e sublinhado", "invalid name: use letters, digits, dot, dash and underscore")
	}
	src, err := avdDir(name)
	if err != nil {
		return AVD{}, err
	}
	if _, err := os.Stat(filepath.Join(Home(), newName+".ini")); err == nil {
		return AVD{}, platform.Errorf("já existe um AVD chamado %q", "an AVD named %q already exists", newName)
	}
	dst := filepath.Join(Home(), newName+".avd")
	if _, err := os.Stat(dst); err == nil {
		return AVD{}, platform.Errorf("a pasta %s já existe", "the folder %s already exists", dst)
	}
	if err := copyTree(src, dst); err != nil {
		_ = os.RemoveAll(dst)
		return AVD{}, err
	}
	for _, junk := range []string{"snapshots", "multiinstance.lock", "hardware-qemu.ini", "hardware-qemu.ini.lock", "emu-launch-params.txt", "tmpAdbCmds"} {
		_ = os.RemoveAll(filepath.Join(dst, junk))
	}
	cfgPath := filepath.Join(dst, "config.ini")
	cfg, err := ReadIni(cfgPath)
	if err != nil {
		_ = os.RemoveAll(dst)
		return AVD{}, err
	}
	if newDisplay == "" {
		newDisplay = strings.ReplaceAll(newName, "_", " ")
	}
	cfg.Set("avd.ini.displayname", newDisplay)
	if cfg.Has("AvdId") {
		cfg.Set("AvdId", newName)
	}
	if err := os.WriteFile(cfgPath, cfg.Bytes(), 0o644); err != nil {
		return AVD{}, err
	}
	srcIni, _ := ReadIni(filepath.Join(Home(), name+".ini"))
	target := ""
	if srcIni != nil {
		target = srcIni.Get("target")
	}
	if err := writeAVDIni(newName, dst, target); err != nil {
		_ = os.RemoveAll(dst)
		return AVD{}, err
	}
	return Load(s, newName)
}

func writeAVDIni(name, dir, target string) error {
	ini := NewIni()
	ini.Set("avd.ini.encoding", "UTF-8")
	ini.Set("path", dir)
	if rel, err := filepath.Rel(UserHome(), dir); err == nil && !strings.HasPrefix(rel, "..") {
		ini.Set("path.rel", filepath.ToSlash(rel))
	}
	if target != "" {
		ini.Set("target", target)
	}
	return os.WriteFile(filepath.Join(Home(), name+".ini"), ini.Bytes(), 0o644)
}

// copyTree copia um diretório preservando arquivos esparsos (imagens de disco).
func copyTree(src, dst string) error {
	if err := os.MkdirAll(filepath.Dir(dst), 0o755); err != nil {
		return err
	}
	var cmd *exec.Cmd
	if runtime.GOOS == "darwin" {
		cmd = exec.Command("cp", "-Rc", src, dst) // clone APFS
		if out, err := cmd.CombinedOutput(); err != nil {
			_ = os.RemoveAll(dst)
			cmd = exec.Command("cp", "-R", src, dst)
			if out2, err2 := cmd.CombinedOutput(); err2 != nil {
				return fmt.Errorf("cp: %s %s", strings.TrimSpace(string(out)), strings.TrimSpace(string(out2)))
			}
		}
		return nil
	}
	cmd = exec.Command("cp", "-a", "--reflink=auto", "--sparse=always", src, dst)
	if out, err := cmd.CombinedOutput(); err != nil {
		return fmt.Errorf("cp: %s", strings.TrimSpace(string(out)))
	}
	return nil
}
