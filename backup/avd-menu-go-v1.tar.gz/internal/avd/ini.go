package avd

import (
	"bufio"
	"bytes"
	"os"
	"sort"
	"strings"
)

// Ini é um arquivo chave=valor (config.ini / <nome>.ini do AVD) que preserva a
// ordem original ao editar — o emulador reescreve esses arquivos e não
// queremos embaralhar o que o usuário ou o Android Studio escreveram.
type Ini struct {
	lines []string // linhas originais (comentários/vazias incluídas)
	vals  map[string]string
}

// NewIni cria um Ini vazio.
func NewIni() *Ini { return &Ini{vals: map[string]string{}} }

// ParseIni lê o conteúdo de um .ini.
func ParseIni(b []byte) *Ini {
	ini := NewIni()
	sc := bufio.NewScanner(bytes.NewReader(b))
	sc.Buffer(make([]byte, 1<<20), 1<<20)
	for sc.Scan() {
		line := strings.TrimRight(sc.Text(), "\r")
		ini.lines = append(ini.lines, line)
		t := strings.TrimSpace(line)
		if t == "" || t[0] == '#' || t[0] == ';' {
			continue
		}
		if i := strings.IndexByte(t, '='); i > 0 {
			ini.vals[strings.TrimSpace(t[:i])] = strings.TrimSpace(t[i+1:])
		}
	}
	return ini
}

// ReadIni lê um arquivo .ini do disco.
func ReadIni(path string) (*Ini, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	return ParseIni(b), nil
}

// Get devolve o valor da chave ("" se ausente).
func (i *Ini) Get(k string) string { return i.vals[k] }

// Has informa se a chave existe.
func (i *Ini) Has(k string) bool { _, ok := i.vals[k]; return ok }

// Map devolve uma cópia dos pares.
func (i *Ini) Map() map[string]string {
	m := make(map[string]string, len(i.vals))
	for k, v := range i.vals {
		m[k] = v
	}
	return m
}

// Set define a chave, mantendo a posição se ela já existia.
func (i *Ini) Set(k, v string) {
	if _, ok := i.vals[k]; ok {
		for n, line := range i.lines {
			if keyOf(line) == k {
				i.lines[n] = k + "=" + v
				i.vals[k] = v
				return
			}
		}
	}
	i.vals[k] = v
	i.lines = append(i.lines, k+"="+v)
}

// Delete remove a chave.
func (i *Ini) Delete(k string) {
	if _, ok := i.vals[k]; !ok {
		return
	}
	delete(i.vals, k)
	out := i.lines[:0]
	for _, line := range i.lines {
		if keyOf(line) != k {
			out = append(out, line)
		}
	}
	i.lines = out
}

func keyOf(line string) string {
	t := strings.TrimSpace(line)
	if t == "" || t[0] == '#' || t[0] == ';' {
		return ""
	}
	if n := strings.IndexByte(t, '='); n > 0 {
		return strings.TrimSpace(t[:n])
	}
	return ""
}

// Bytes serializa mantendo a ordem original.
func (i *Ini) Bytes() []byte {
	var b bytes.Buffer
	for _, l := range i.lines {
		b.WriteString(l)
		b.WriteByte('\n')
	}
	return b.Bytes()
}

// SortedBytes serializa com as chaves em ordem alfabética (como o avdmanager).
func (i *Ini) SortedBytes() []byte {
	keys := make([]string, 0, len(i.vals))
	for k := range i.vals {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	var b bytes.Buffer
	for _, k := range keys {
		b.WriteString(k + "=" + i.vals[k] + "\n")
	}
	return b.Bytes()
}
