package avd

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"avdmenu/internal/sdk"
)

// fakeSDK cria um SDK mínimo com uma imagem de sistema instalada.
func fakeSDK(t *testing.T) sdk.SDK {
	t.Helper()
	root := t.TempDir()
	dir := filepath.Join(root, "system-images", "android-36", "google_apis_playstore", "x86_64")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		t.Fatal(err)
	}
	props := "AndroidVersion.ApiLevel=36\nSystemImage.Abi=x86_64\nSystemImage.TagId=google_apis_playstore\nSystemImage.TagDisplay=Google Play\n"
	_ = os.WriteFile(filepath.Join(dir, "source.properties"), []byte(props), 0o644)
	t.Setenv("ANDROID_AVD_HOME", filepath.Join(t.TempDir(), "avd"))
	return sdk.SDK{Root: root}
}

func TestParseMB(t *testing.T) {
	for in, want := range map[string]int{"2G": 2048, "2048": 2048, "512 MB": 512, "512M": 512, "1.5G": 1536, "": 0, "x": 0, "2048K": 2} {
		if got := ParseMB(in); got != want {
			t.Errorf("ParseMB(%q) = %d, quer %d", in, got, want)
		}
	}
}

func TestIniPreservesOrderAndComments(t *testing.T) {
	ini := ParseIni([]byte("# comentário\nb=1\na=2\n\nc = 3\n"))
	ini.Set("a", "9")
	ini.Set("novo", "x")
	ini.Delete("b")
	want := "# comentário\na=9\n\nc = 3\nnovo=x\n"
	if got := string(ini.Bytes()); got != want {
		t.Errorf("got %q want %q", got, want)
	}
	if ini.Get("c") != "3" || ini.Has("b") {
		t.Errorf("leitura inconsistente: %v", ini.Map())
	}
	if got := string(ini.SortedBytes()); got != "a=9\nc=3\nnovo=x\n" {
		t.Errorf("SortedBytes = %q", got)
	}
}

func TestNames(t *testing.T) {
	for _, ok := range []string{"Pixel_9_API_36", "a.b-c", "X"} {
		if !ValidName(ok) {
			t.Errorf("%q deveria ser válido", ok)
		}
	}
	for _, bad := range []string{"", "a b", "../x", ".hidden", "a/b", "ação"} {
		if ValidName(bad) {
			t.Errorf("%q deveria ser inválido", bad)
		}
	}
	if got := SanitizeName("Pixel 9 Pro (API 36)"); got != "Pixel_9_Pro_API_36" {
		t.Errorf("SanitizeName = %q", got)
	}
}

func TestCreateListUpdateDuplicateDelete(t *testing.T) {
	s := fakeSDK(t)
	img := "system-images;android-36;google_apis_playstore;x86_64"
	ram, cores := 4096, 6
	disp := "Meu Pixel"
	a, err := Create(s, CreateSpec{Name: "Meu_Pixel", DeviceID: "pixel_9", ImagePkg: img, Settings: Settings{DisplayName: &disp, RAMMB: &ram, Cores: &cores}})
	if err != nil {
		t.Fatal(err)
	}
	if a.DisplayName != "Meu Pixel" || a.API != "36" || a.ABI != "x86_64" || a.Tag != "google_apis_playstore" || !a.PlayStore || !a.ImageOK {
		t.Errorf("AVD criado: %+v", a)
	}
	if a.Width != 1080 || a.Height != 2424 || a.Density != 420 || a.RAMMB != 4096 || a.DeviceName != "Pixel 9" || a.APIName != "Android 16" {
		t.Errorf("hardware do AVD: %+v", a)
	}
	cfg, _, err := Config("Meu_Pixel")
	if err != nil {
		t.Fatal(err)
	}
	for k, want := range map[string]string{
		"image.sysdir.1": "system-images/android-36/google_apis_playstore/x86_64/", "hw.cpu.ncore": "6", "hw.ramSize": "4096",
		"abi.type": "x86_64", "hw.cpu.arch": "x86_64", "hw.device.name": "pixel_9", "tag.id": "google_apis_playstore",
		"hw.camera.back": "virtualscene", "hw.camera.front": "emulated", "AvdId": "Meu_Pixel", "target": "android-36",
	} {
		if got := cfg.Get(k); got != want {
			t.Errorf("config %s = %q, quer %q", k, got, want)
		}
	}
	ini, _ := os.ReadFile(filepath.Join(Home(), "Meu_Pixel.ini"))
	if !strings.Contains(string(ini), "target=android-36") || !strings.Contains(string(ini), "path="+a.Dir) {
		t.Errorf(".ini = %s", ini)
	}
	if _, err := Create(s, CreateSpec{Name: "Meu_Pixel", DeviceID: "pixel_9", ImagePkg: img}); err == nil {
		t.Error("não deveria recriar um AVD existente")
	}
	if _, err := Create(s, CreateSpec{Name: "x", DeviceID: "pixel_9", ImagePkg: "system-images;android-1;default;x86"}); err == nil {
		t.Error("não deveria aceitar imagem não instalada")
	}
	if _, err := Create(s, CreateSpec{Name: "w", DeviceID: "wearos_small_round", ImagePkg: img}); err == nil {
		t.Error("imagem de celular não serve para Wear OS")
	}
	if _, err := Create(s, CreateSpec{Name: "bad name", DeviceID: "pixel_9", ImagePkg: img}); err == nil {
		t.Error("nome com espaço deveria ser recusado")
	}

	// edição
	gpu, boot, kb, sd := "host", "cold", true, 1024
	if err := Update("Meu_Pixel", Settings{GPUMode: &gpu, BootMode: &boot, Keyboard: &kb, SDCardMB: &sd}); err != nil {
		t.Fatal(err)
	}
	v := func() View { c, _, _ := Config("Meu_Pixel"); return ViewOf(c, "Meu_Pixel") }()
	if v.GPUMode != "host" || v.BootMode != "cold" || !v.Keyboard || v.SDCardMB != 1024 || v.RAMMB != 4096 || v.Cores != 6 {
		t.Errorf("view após editar: %+v", v)
	}
	bad := "banana"
	if err := Update("Meu_Pixel", Settings{GPUMode: &bad}); err == nil {
		t.Error("modo gráfico inválido deveria falhar")
	}
	zero := 0
	if err := Update("Meu_Pixel", Settings{SDCardMB: &zero}); err != nil {
		t.Fatal(err)
	}
	c, _, _ := Config("Meu_Pixel")
	if c.Get("hw.sdCard") != "no" || c.Has("sdcard.size") {
		t.Errorf("sem SD: hw.sdCard=%q sdcard.size=%q", c.Get("hw.sdCard"), c.Get("sdcard.size"))
	}

	// dados de usuário + snapshots
	_ = os.WriteFile(filepath.Join(a.Dir, "userdata-qemu.img"), []byte("dados"), 0o644)
	_ = os.MkdirAll(filepath.Join(a.Dir, "snapshots", "default_boot"), 0o755)
	_ = os.WriteFile(filepath.Join(a.Dir, "snapshots", "default_boot", "ram.bin"), []byte("x"), 0o644)
	_ = os.WriteFile(filepath.Join(a.Dir, "multiinstance.lock"), []byte("1"), 0o644)

	dup, err := Duplicate(s, "Meu_Pixel", "Copia", "Cópia")
	if err != nil {
		t.Fatal(err)
	}
	if dup.DisplayName != "Cópia" || dup.Width != 1080 {
		t.Errorf("duplicata: %+v", dup)
	}
	if _, err := os.Stat(filepath.Join(dup.Dir, "userdata-qemu.img")); err != nil {
		t.Error("a cópia deveria levar os dados do usuário")
	}
	for _, junk := range []string{"snapshots", "multiinstance.lock"} {
		if _, err := os.Stat(filepath.Join(dup.Dir, junk)); err == nil {
			t.Errorf("a cópia não deveria levar %s", junk)
		}
	}
	if cc, _, _ := Config("Copia"); cc.Get("AvdId") != "Copia" {
		t.Errorf("AvdId da cópia = %q", cc.Get("AvdId"))
	}
	if _, err := Duplicate(s, "Meu_Pixel", "Copia", ""); err == nil {
		t.Error("duplicar para nome existente deveria falhar")
	}

	if got := len(List(s)); got != 2 {
		t.Errorf("List = %d AVDs", got)
	}

	if err := WipeData("Meu_Pixel"); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(a.Dir, "userdata-qemu.img")); err == nil {
		t.Error("userdata deveria ter sido apagado")
	}
	if _, err := os.Stat(filepath.Join(a.Dir, "config.ini")); err != nil {
		t.Error("config.ini deve permanecer após o wipe")
	}

	if err := Delete("Copia"); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(dup.Dir); err == nil {
		t.Error("pasta da cópia deveria ter sumido")
	}
	if got := len(List(s)); got != 1 {
		t.Errorf("List após apagar = %d", got)
	}
	if err := Delete("../Meu_Pixel"); err == nil {
		t.Error("nome com .. deveria ser recusado")
	}
}

func TestMissingImageIsReported(t *testing.T) {
	s := fakeSDK(t)
	a, err := Create(s, CreateSpec{Name: "A", DeviceID: "pixel_9", ImagePkg: "system-images;android-36;google_apis_playstore;x86_64"})
	if err != nil {
		t.Fatal(err)
	}
	_ = os.RemoveAll(filepath.Join(s.Root, "system-images"))
	got, _ := Load(s, a.Name)
	if got.ImageOK || got.Problem == "" {
		t.Errorf("deveria apontar imagem ausente: %+v", got)
	}
}

func TestWriteRawConfigKeepsBackup(t *testing.T) {
	s := fakeSDK(t)
	a, _ := Create(s, CreateSpec{Name: "A", DeviceID: "pixel_9", ImagePkg: "system-images;android-36;google_apis_playstore;x86_64"})
	if err := WriteRawConfig("A", "hw.ramSize=1024\n"); err == nil {
		t.Error("sem image.sysdir.1 deveria falhar")
	}
	cfg, _, _ := Config("A")
	cfg.Set("hw.ramSize", "1234")
	if err := WriteRawConfig("A", string(cfg.Bytes())); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(a.Dir, "config.ini.bak")); err != nil {
		t.Error("deveria criar config.ini.bak")
	}
	if c, _, _ := Config("A"); c.Get("hw.ramSize") != "1234" {
		t.Error("alteração não gravada")
	}
}
